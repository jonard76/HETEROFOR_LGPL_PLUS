/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.gui;

import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetTrueThinningFileLoader;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextField;

import jeeb.lib.util.Check;
import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.IconLoader;
import jeeb.lib.util.JWidthLabel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.Question;
import jeeb.lib.util.Settings;
import jeeb.lib.util.Translator;
import capsis.commongui.EvolutionDialog;
import capsis.commongui.util.Helper;
import jeeb.lib.util.PathManager;
import capsis.kernel.Step;

/**
 * HetEvolutionDialog is a dialog to set up evolution parameters in Heterofor.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetEvolutionDialog extends EvolutionDialog implements ActionListener {

	private JTextField numberOfYears;

	// Optional, can stay blank if unused, fc+mj-27.4.2015
	public JTextField trueThinningFileName;
	public JButton browse;

	private JButton ok;
	private JButton cancel;
	private JButton help;

	/**
	 * True if user decides to launch evolution, false otherwise.
	 */
	private boolean userWantsToLaunchEvolution;

	/**
	 * The date of the step from which the evolution is launched.
	 */
	private int date;

	/**
	 * The initial parameters.
	 */
	private HetInitialParameters ip;

	/**
	 * Constructor.
	 */
	public HetEvolutionDialog(Step fromStep) {
		super();

		date = fromStep.getScene().getDate();
		ip = (HetInitialParameters) fromStep.getProject().getModel().getSettings();

		createUI();

		pack();
		setVisible(true);
	}

	/**
	 * Action on Ok.
	 */
	private void okAction() {

		// Classic checks...
		if (!Check.isInt(numberOfYears.getText().trim())) {
			MessageDialog.print(this, Translator.swap("HetEvolutionDialog.numberOfYearsMustBeAPositiveInteger"));
			return;
		}

		int age = Check.intValue(numberOfYears.getText().trim());
		if (age <= 0) {
			MessageDialog.print(this, Translator.swap("HetEvolutionDialog.numberOfYearsMustBeAPositiveInteger"));
			return;
		}

		String fileName = trueThinningFileName.getText().trim();
		if (fileName.length() > 0) { // a file name was given

			try {

				// Check the file
				HetTrueThinningFileLoader loader = new HetTrueThinningFileLoader();
				loader.load(fileName);

			} catch (Exception e) {
				MessageDialog.print(this, Translator.swap("HetEvolutionDialog.couldNotLoadTrueThinningFile"), e);
				return;
			}

			// fc-6.12.2017 no more report in FileLoader

//			String loaderReport = loader.load(fileName);
//			// In case of trouble, tell user
//			if (!loader.succeeded()) {
//				MessageDialog.print(this, Translator.swap("HetEvolutionDialog.couldNotLoadTrueThinningFile") + " :\n"
//						+ loaderReport);
//				return;
//			}

		}

		// Opens a dialog box in the case of a target year that is strictly greater than the last year of meteo data
		// available in the meteo file: some meteo data will be duplicated for the missing data.

		// fc-11.4.2018 added the test below to prevent an error if no meteo file
		if (ip.meteoFileNameProvided) {

			int lastYearInMeteoFile = ip.meteorology.getLastYearInMeteoFile();
			int targetYear = date+age;

			userWantsToLaunchEvolution = true;

			if (targetYear > lastYearInMeteoFile) {

				String question = Translator.swap("HetEvolutionDialog.targetYear") + ": " + targetYear + "\n"
									+ Translator.swap("HetEvolutionDialog.isStrictlyGreaterThanLastYearInMeteoFile") + ": " + lastYearInMeteoFile + "\n\n"
									+ Translator.swap("HetEvolutionDialog.meteoDataWillBeDuplicatedIfNeeded")
									+ Translator.swap("HetEvolutionDialog.doYouWantToContinue");

				userWantsToLaunchEvolution = Question.ask(this, Translator.swap("HetEvolutionDialog.meteoDataDuplicationTitle"), question,
												Translator.swap("HetEvolutionDialog.meteoDataDuplicationYesResponse"),
												Translator.swap("HetEvolutionDialog.meteoDataDuplicationNoResponse"));
			}

			if (!userWantsToLaunchEvolution) // fc-11.4.2018
				return;

		}

//		if (userWantsToLaunchEvolution) { // fc-11.4.2018

		setEvolutionParameters(new HetEvolutionParameters(age, fileName));
		setValidDialog(true);

//		}

	}

	/**
	 * Actions on buttons
	 */
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource().equals(browse)) {
			String s = getExternalFileName();
			if (s == null)
				s = ""; // if user cancelled
			trueThinningFileName.setText(s);

		} else if (evt.getSource().equals(ok)) {
			okAction();

		} else if (evt.getSource().equals(cancel)) {
			setValidDialog(false);

		} else if (evt.getSource().equals(help)) {
			Helper.helpFor(this);
		}
	}

	/**
	 * Action on browse, returns a file name or null if user cancelled.
	 */
	private String getExternalFileName() {
		JFileChooser chooser = new JFileChooser(Settings.getProperty("heterofor.trueThinningFile.path",
				PathManager.getDir("data")));

		int returnVal = chooser.showOpenDialog(this);

		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String fileName = chooser.getSelectedFile().toString();
			Settings.setProperty("heterofor.trueThinningFile.path", fileName);
			return fileName;
		}

		return null; // user cancelled
	}

	/**
	 * Creates the GUI.
	 */
	private void createUI() {

		ColumnPanel c1 = new ColumnPanel();

		LinePanel l1 = new LinePanel();
		l1.add(new JWidthLabel(Translator.swap("HetEvolutionDialog.numberOfYears") + " :", 120));
		numberOfYears = new JTextField(5);
		l1.add(numberOfYears);
		l1.addStrut0();

		c1.add(l1);

		// The trueThinningFileName option (leave blank if unused)
		ColumnPanel c2 = new ColumnPanel(Translator.swap("HetEvolutionDialog.trueThinningFileNameTitle"));
		c1.add(c2);

		LinePanel l2 = new LinePanel();
		l2.add(new JWidthLabel(Translator.swap("HetEvolutionDialog.trueThinningFileName") + " :", 120));
		trueThinningFileName = new JTextField(30);
		l2.add(trueThinningFileName);
		browse = new JButton(Translator.swap("Shared.browse"));
		browse.addActionListener(this);
		l2.add(browse);
		l2.addStrut0();

		c2.add(l2);
		c2.addStrut0();

		c1.addStrut0();

		// Control panel
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		ok = new JButton(Translator.swap("Shared.ok"));
		ok.addActionListener(this);
		ImageIcon icon = IconLoader.getIcon("ok_16.png");
		ok.setIcon(icon);

		cancel = new JButton(Translator.swap("Shared.cancel"));
		cancel.addActionListener(this);
		icon = IconLoader.getIcon("cancel_16.png");
		cancel.setIcon(icon);

		help = new JButton(Translator.swap("Shared.help"));
		help.addActionListener(this);
		icon = IconLoader.getIcon("help_16.png");
		help.setIcon(icon);

		controlPanel.add(ok);
		controlPanel.add(cancel);
		controlPanel.add(help);

		// Sets ok as default
		setDefaultButton(ok);

		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(c1, BorderLayout.NORTH);
		getContentPane().add(controlPanel, BorderLayout.SOUTH);

		setTitle(Translator.swap("HetEvolutionDialog.evolutionParameters"));
		setModal(true);
	}

}
