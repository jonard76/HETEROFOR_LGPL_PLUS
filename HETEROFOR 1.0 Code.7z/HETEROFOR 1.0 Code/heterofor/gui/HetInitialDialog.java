/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.gui;

import heterofor.model.HetAtmosphericCO2ConcentrationFileLoader;
import heterofor.model.HetFructificationFileLoader;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetInventoryLoader;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetSpeciesFileLoader;
import heterofor.model.meteorology.HetMeteorologyFileLoader;
import heterofor.model.soil.HetSoilHorizonsFileLoader;
import heterofor.model.soilchemistry.HetSoilChemistryFileLoader;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import jeeb.lib.util.Check;
import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.IconLoader;
import jeeb.lib.util.JWidthLabel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.PathManager;
import jeeb.lib.util.Settings;
import jeeb.lib.util.Translator;
import jeeb.lib.util.fileloader.CheckingFileChooser;
import capsis.commongui.InitialDialog;
import capsis.commongui.util.Helper;
import capsis.kernel.GModel;
import capsis.lib.castanea2018march.FmSettings;
import capsis.lib.castanea2018march.FmSpeciesReader;
import capsis.lib.samsaralight.SLSettingsLoader;
import capsis.util.Fit2018Date;

/**
 * The initial dialog for the Heterofor model
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetInitialDialog extends InitialDialog implements ActionListener {

	static {
		Translator.addBundle("heterofor.HetLabels");
	}

	private JTextField speciesFileName; // mj+fc-29.4.2015 not needed if Quergus
										// inventory
	private JButton speciesBrowse;

	// fc-hd+mj+fa-20.1.2017
	private JTextField castaneaFileName;
	private JButton castaneaBrowse;

	private JTextField inventoryFileName;
	private JButton browse;

	private JTextField samsaraLightFileName;
	private JButton samsaraLightBrowse;

	// fc+mj-8.9.2016 Soil horizons file is optional
	private JTextField soilHorizonsFileName;
	private JButton soilHorizonsBrowse;

	// fc+mj-27.10.2015 Soil chemistry file is optional
	// If given, requires soil horizons file to be also given
	private JTextField soilChemistryFileName;
	private JButton soilChemistryBrowse;

	// fc+mj-8.9.2016 Meteorology file is optional
	// If given, requires soil horizons file to be also given
	private JTextField meteorologyFileName;
	private JButton meteorologyBrowse;

	private JTextField fructificationFileName;
	private JButton fructificationBrowse;

	private JTextField radiationCalculationTimeStep;

	// fc+mj-12.9.2017 constantNppToGppRatio = !maintenanceRespirationActivated
	// private JCheckBox constantNppToGppRatio;
	private JCheckBox maintenanceRespirationActivated;

	private JCheckBox competitionAccountedForCrownGrowth;

	private JCheckBox mortalityActivated;

	private JCheckBox generalNutrientLimitation; // fc+mj-8.12.2016
	private JCheckBox nLimitation; // fc+mj-9.12.2016

	private JCheckBox phenologyActivated; // nb+lw+fa-19.01.2017
	private JCheckBox castaneaPhotosynthesisActivated; // fc-27.1.2017

	private JCheckBox waterBalanceActivated; // fc+mj-13.9.2017
	public JCheckBox waterBalance_treeLevelTranspiration; // fc+mj-13.9.2017

	private JCheckBox mineralHorizonsTemperatureCalculationActivated; // nb+lw-25.04.2017
	private JTextField discretisationSpaceStep; // nb+lw-28.04.2017

	private JCheckBox fineResolutionRadiativeBalanceActivated; // fc+fa-28.4.2017

	// fc+mj-30.4.2015 LAD and T options now in species
	// private JRadioButton meanLAD;
	// private JRadioButton meanSLA;
	// private JRadioButton SLAmodel;
	// private JRadioButton quergusLAD; // fc-30.5.2013
	// private ButtonGroup group1;
	//
	// private JRadioButton meanT; // fc-30.5.2013
	// private JRadioButton quergusT; // fc-30.5.2013
	// private ButtonGroup group2; // fc-30.5.2013

	// Atmospheric CO2 concentration. nb-14.03.2018
	private JTextField fixedAtmCO2TextField;
	private JTextField atmCO2FileNameTextField;
	private JButton atmCO2FileBrowse;
	private JRadioButton fixedAtmCO2Button;
	private JRadioButton variableAtmCO2Button;
	private ButtonGroup atmCO2Group;

	private JRadioButton iprfw; // fc+mj-29.4.2015
	private JRadioButton baileuxSite; // fc+mj-29.4.2015
	private JRadioButton potentialModifiers; // fc+mj-29.4.2015
	private ButtonGroup group3; // fc+mj-29.4.2015

	private JTextField cuttingDiameter; // fc+mj-9.5.2016

	private JButton ok;
	private JButton cancel;
	private JButton help;

	private HetModel model;
	private HetInitialParameters ip;

	/**
	 * Constructor
	 */
	public HetInitialDialog(GModel model) throws Exception {
		super();
		try {
			this.model = (HetModel) model;
			this.ip = (HetInitialParameters) model.getSettings();

			createUI();
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetInitialDialog.c ()", "Could not create initial dialog", e);
			throw e;
		}
	}

	// /**
	// * Action on lightSLSettings button.
	// */
	// private void lightSLSettingsAction() {
	// SLModel mod = model.getSLModel();
	// SLSettings slSet = mod.getSettings();
	// SLSettingsDialog ed = new SLSettingsDialog(this, slSet);
	//
	// }

	// private void preloadAction () {
	//
	// speciesEditors = new ArrayList<SLSpeciesSettingsEditor> ();
	// JTabbedPane tabs = new JTabbedPane ();
	// for (Iterator i = model.getSettings ().speciesMap.values ().iterator ();
	// i.hasNext ();) {
	// HetSpecies species = (HetSpecies) i.next ();
	// SLSpeciesSettingsEditor ed = new SLSpeciesSettingsEditor (species.getName
	// (),
	// species.getSLSpeciesSettings());
	// speciesEditors.add (ed);
	//
	// tabs.addTab (species.getName (), ed);
	// }
	// tabsPanel.removeAll ();
	// tabsPanel.add (tabs);
	//
	//
	// }

	/**
	 * Load the file, update the tabs
	 */
	private void preloadAction() {

		// // CHECKS
		// if (!Check.isFile(inventoryFileName.getText().trim())) {
		// MessageDialog.print(this,
		// Translator.swap("HetInitialDialog.fileDoesNotExist"));
		// return;
		// }
		//
		// // init params
		// HetInitialParameters ip = model.getSettings();
		// try {
		// ip.inventoryFileName = inventoryFileName.getText().trim();
		//
		// ip.buildInitScene(model);
		//
		// setInitialParameters(ip);
		//
		// // Light params for the species -> create the tabs
		// JTabbedPane tabs = new JTabbedPane ();
		// for (Iterator i = model.getSettings ().speciesMap.values ().iterator
		// (); i.hasNext ();) {
		// HetSpecies species = (HetSpecies) i.next ();
		// // SLSpeciesSettingsEditor ed = new SLSpeciesSettingsEditor
		// (species.getName (),
		// species.getSLSpeciesSettings());
		// // speciesEditors.add (ed);
		//
		// // tabs.addTab (species.getName (), new JScrollPane (ed));
		// }
		//
		// // tabsPanel.removeAll ();
		// // tabsPanel.add (tabs);
		//
		// // tabsPanel.revalidate ();
		//
		// pack ();
		//
		// preloadWasDone = true;
		//
		// } catch (Exception e) {
		// Log.println(Log.ERROR, "HetInitialDialog",
		// "Error while create init parameters", e);
		// MessageDialog.print(this,
		// Translator.swap("HetInitialDialog.errorInPreloadCheckLog"), e);
		// return;
		// }

	}

	/**
	 * Check parameters and validate the Dialog
	 */
	private void okAction() {

		// Check user entries

		// mj+fc-29.4.2015 species file is not needed if Quergus inventory
		if (speciesFileName.getText().trim().length() > 0) {
			if (!Check.isFile(speciesFileName.getText().trim())) {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.speciesFileDoesNotExist"));
				return;
			}
		}

		boolean castaneaFileNameProvided = false; // fc-27.1.2017
		if (castaneaFileName.getText().trim().length() > 0) {
			if (!Check.isFile(castaneaFileName.getText().trim())) {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.castaneaFileDoesNotExist"));
				return;
			}
			castaneaFileNameProvided = true;
		}

		if (!Check.isFile(inventoryFileName.getText().trim())) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.inventoryFileDoesNotExist"));
			return;
		}

		if (!Check.isFile(samsaraLightFileName.getText().trim())) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.samsaraLightFileDoesNotExist"));
			return;
		}

		// fc+mj-8.9.2016
		boolean soilHorizonsProvided = false;
		if (soilHorizonsFileName.getText().trim().length() > 0) {
			if (Check.isFile(soilHorizonsFileName.getText().trim())) {
				soilHorizonsProvided = true;
			} else {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.soilHorizonsFileDoesNotExist"));
				return;
			}
		}

		// fc+mj-27.10.2015
		boolean soilChemistryProvided = false;
		if (soilChemistryFileName.getText().trim().length() > 0) {
			if (Check.isFile(soilChemistryFileName.getText().trim())) {
				soilChemistryProvided = true;
			} else {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.soilChemistryFileDoesNotExist"));
				return;
			}
		}

		// fc+mj+lw-8.9.2016
		boolean meteorologyProvided = false;
		if (meteorologyFileName.getText().trim().length() > 0) {
			if (Check.isFile(meteorologyFileName.getText().trim())) {
				meteorologyProvided = true;
			} else {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.meteorologyFileDoesNotExist"));
				return;
			}
		}

		boolean fructificationProvided = false;
		if (fructificationFileName.getText().trim().length() > 0) {
			if (Check.isFile(fructificationFileName.getText().trim())) {
				fructificationProvided = true;
			} else {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.fructificationFileDoesNotExist"));
				return;
			}
		}

		if (soilChemistryProvided && !soilHorizonsProvided) {
			MessageDialog.print(this,
					Translator.swap("HetInitialDialog.soilChemistryNeedsSoilHorizonsFileToBeProvided"));
			return;
		}

		if (meteorologyProvided && !soilHorizonsProvided) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.meteorologyNeedsSoilHorizonsFileToBeProvided"));
			return;
		}

		if (!Check.isInt(radiationCalculationTimeStep.getText().trim())) {
			MessageDialog.print(this,
					Translator.swap("HetInitialDialog.radiationCalculationTimeStepMustBeAPositiveInt"));
			return;
		}
		int v = Check.intValue(radiationCalculationTimeStep.getText().trim());
		if (v <= 0) {
			MessageDialog.print(this,
					Translator.swap("HetInitialDialog.radiationCalculationTimeStepMustBeAPositiveInt"));
			return;
		}

		// nb+lw+fa-19.01.2017
		if (phenologyActivated.isSelected() && !meteorologyProvided) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.phenologyModuleNeedsMeteorologicalFile"));
			return;
		}

		// fc-27.1.2017
		if (castaneaPhotosynthesisActivated.isSelected() && !castaneaFileNameProvided) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.castaneaPhotosynthesisNeedsCastaneaFile"));
			return;
		}

		if (mineralHorizonsTemperatureCalculationActivated.isSelected()
				&& (!meteorologyProvided || !soilHorizonsProvided)) {
			MessageDialog
					.print(this,
							Translator
									.swap("HetInitialDialog.mineralHorizonsTemperatureCalculationNeedsMeteorologicalAndSoilHorizonsFiles"));
			return;
		}

		// fc+fa-28.4.2017
		if (fineResolutionRadiativeBalanceActivated.isSelected() && !meteorologyProvided) {
			MessageDialog
					.print(this,
							Translator
									.swap("HetInitialDialog.ifFineResolutionRadiativeBalanceActivatedIsCheckedMeteorologyFileNameMustBeProvided"));
			return;
		}

		if (fineResolutionRadiativeBalanceActivated.isSelected() && !phenologyActivated.isSelected()) {
			MessageDialog.print(this, Translator
					.swap("HetInitialDialog.ifFineResolutionRadiativeBalanceActivatedIsCheckedPhenologyMustBeChecked"));
			return;
		}

		if (mineralHorizonsTemperatureCalculationActivated.isSelected()) {

			if (!Check.isDouble(discretisationSpaceStep.getText().trim())) {
				MessageDialog.print(this,
						Translator.swap("HetInitialDialog.discretisationSpaceStepMustBeAPositiveDouble"));
				return;
			}

			double dz = Check.doubleValue(discretisationSpaceStep.getText().trim());
			if (dz <= 0.0) {
				MessageDialog.print(this,
						Translator.swap("HetInitialDialog.discretisationSpaceStepMustBeAPositiveDouble"));
				return;
			}
		}

		// Atmospheric CO2 concentration. nb-14.03.2018
		if (fixedAtmCO2Button.isSelected()) {
			if (!Check.isDouble(fixedAtmCO2TextField.getText().trim())) {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.atmosphericCO2ConcentrationMustBeAPositiveNumber"));
				return;
			}
			double atmCO2Conc = Check.doubleValue(fixedAtmCO2TextField.getText().trim());
			if (atmCO2Conc < 0.0) {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.atmosphericCO2ConcentrationMustBeAPositiveNumber"));
				return;
			}
		}
		if (variableAtmCO2Button.isSelected()) {
			if (!Check.isFile(atmCO2FileNameTextField.getText().trim())) {
				MessageDialog.print(this, Translator.swap("HetInitialDialog.atmosphericCO2ConcentrationsFileDoesNotExist"));
				return;
			}
		}

		if (!Check.isDouble(cuttingDiameter.getText().trim())) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.cuttingDiameterMustBeAPositiveNumber"));
			return;
		}
		double cd = Check.doubleValue(cuttingDiameter.getText().trim());
		if (cd < 0) {
			MessageDialog.print(this, Translator.swap("HetInitialDialog.cuttingDiameterMustBeAPositiveNumber"));
			return;
		}

		// Prepare SLSettings load
		// SLModel mod = model.getSLModel();
		// SLSettings slSettings = mod.getSettings();
		// slSettings.fileName = samsaraLightFileName.getText().trim();

		// Build init scene
		try {
			ip.speciesFileName = speciesFileName.getText().trim();

			ip.castaneaFileName = castaneaFileName.getText().trim();

			ip.inventoryFileName = inventoryFileName.getText().trim();
			ip.samsaraLightFileName = samsaraLightFileName.getText().trim();

			// fc+mj-27.10.2015
			ip.soilHorizonsFileName = soilHorizonsFileName.getText().trim();

			// fc+mj-27.10.2015
			ip.soilChemistryFileName = soilChemistryFileName.getText().trim();

			// fc+mj+lw-8.9.2016
			ip.meteorologyFileName = meteorologyFileName.getText().trim();

			ip.fructificationFileName = fructificationFileName.getText().trim();

			ip.radiationCalculationTimeStep = v;

			ip.constantNppToGppRatio = !maintenanceRespirationActivated.isSelected();
			// ip.constantNppToGppRatio = constantNppToGppRatio.isSelected();

			ip.competitionAccountedForCrownGrowth = competitionAccountedForCrownGrowth.isSelected();
			ip.mortalityActivated = mortalityActivated.isSelected();
			ip.generalNutrientLimitation = generalNutrientLimitation.isSelected();
			ip.nLimitation = nLimitation.isSelected();
			ip.phenologyActivated = phenologyActivated.isSelected();
			ip.waterBalanceActivated = waterBalanceActivated.isSelected();
			ip.waterBalance_treeLevelTranspiration = waterBalance_treeLevelTranspiration.isSelected();
			ip.castaneaPhotosynthesisActivated = castaneaPhotosynthesisActivated.isSelected();
			ip.mineralHorizonsTemperatureCalculationActivated = mineralHorizonsTemperatureCalculationActivated
					.isSelected();
			ip.fineResolutionRadiativeBalanceActivated = fineResolutionRadiativeBalanceActivated.isSelected();
			ip.discretisationSpaceStep = Check.doubleValue(discretisationSpaceStep.getText().trim());
			ip.cuttingDiameter = cd;

			// Memo user values for next opening
			Settings.setProperty("heterofor.radiationCalculationTimeStep", v);

			Settings.setProperty("heterofor.maintenanceRespirationActivated", !ip.constantNppToGppRatio);

			Settings.setProperty("heterofor.competitionAccountedForCrownGrowth", ip.competitionAccountedForCrownGrowth);
			Settings.setProperty("heterofor.mortalityActivated", ip.mortalityActivated);
			Settings.setProperty("heterofor.generalNutrientLimitation", ip.generalNutrientLimitation);
			Settings.setProperty("heterofor.nLimitation", ip.nLimitation);
			Settings.setProperty("heterofor.phenologyActivated", ip.phenologyActivated);
			Settings.setProperty("heterofor.waterBalanceActivated", ip.waterBalanceActivated);
			Settings.setProperty("heterofor.waterBalance_treeLevelTranspiration",
					ip.waterBalance_treeLevelTranspiration);
			Settings.setProperty("heterofor.castaneaPhotosynthesisActivated", ip.castaneaPhotosynthesisActivated);
			Settings.setProperty("heterofor.mineralHorizonsTemperatureCalculationActivated",
					ip.mineralHorizonsTemperatureCalculationActivated);
			Settings.setProperty("heterofor.fineResolutionRadiativeBalanceActivated",
					ip.fineResolutionRadiativeBalanceActivated);
			Settings.setProperty("heterofor.discretisationSpaceStep", ip.discretisationSpaceStep);
			Settings.setProperty("heterofor.species.path", ip.speciesFileName);
			Settings.setProperty("heterofor.castaneaFileName.path", ip.castaneaFileName);
			Settings.setProperty("heterofor.inventory.path", ip.inventoryFileName);
			Settings.setProperty("heterofor.samsaraLightPath", ip.samsaraLightFileName);
			Settings.setProperty("heterofor.soilHorizonsPath", ip.soilHorizonsFileName);
			Settings.setProperty("heterofor.soilChemistryPath", ip.soilChemistryFileName);
			Settings.setProperty("heterofor.meteorologyPath", ip.meteorologyFileName);
			Settings.setProperty("heterofor.fructificationPath", ip.fructificationFileName);

			// fc+mj-30.4.2015 LAD and T options now in species
			// if (meanLAD.isSelected()) {
			// ip.LADoption = HetInitialParameters.MEAN_LAD;
			// } else if (meanSLA.isSelected()) {
			// ip.LADoption = HetInitialParameters.MEAN_SLA;
			// } else if (SLAmodel.isSelected()) {
			// ip.LADoption = HetInitialParameters.SLA_MODEL;
			// } else {
			// ip.LADoption = HetInitialParameters.QUERGUS_LAD;
			// }
			// Settings.setProperty("heterofor.LADoption", ip.LADoption);

			// // fc-30.5.2013
			// if (meanT.isSelected()) {
			// ip.Toption = HetInitialParameters.MEAN_T;
			// } else {
			// ip.Toption = HetInitialParameters.QUERGUS_T;
			// }
			// Settings.setProperty("heterofor.Toption", ip.Toption);

			// Atmospheric CO2 concentration. nb-14.03.2018
			if (fixedAtmCO2Button.isSelected()) {
				ip.variableAtmCO2ConcentrationOverTime = false;
				ip.Ca = Double.valueOf(fixedAtmCO2TextField.getText().trim());
				Settings.setProperty("heterofor.fixedAtmCO2Concentration", ip.Ca);
				Settings.setProperty("heterofor.atmCO2Option", HetInitialParameters.FIXED_ATMOSPHERIC_CO2_CONCENTRATION);
			} else if (variableAtmCO2Button.isSelected()) {
				ip.variableAtmCO2ConcentrationOverTime = true;
				ip.atmCO2ConcentrationsFileName = atmCO2FileNameTextField.getText().trim();
				Settings.setProperty("heterofor.atmCO2FilePath", ip.atmCO2ConcentrationsFileName);
				Settings.setProperty("heterofor.atmCO2Option", HetInitialParameters.VARIABLE_ATMOSPHERIC_CO2_CONCENTRATION);
			} else {
				Log.println(Log.ERROR, "HetInitialDialog.okAction()",
								"Error: undefined option for the atmospheric CO2 concentration's management");
				MessageDialog.print(this, "Error in HetInitialDialog.okAction(): "
										+ Translator.swap("HetInitialDialog.undefinedOptionForAtmosphericCO2ConcentrationManagementSeeTheLog"));
				return;
			}

			// fc-29.4.2015
			if (iprfw.isSelected()) {
				ip.heightGrowthOption = HetInitialParameters.IPRFW;
			} else if (baileuxSite.isSelected()) {
				ip.heightGrowthOption = HetInitialParameters.BAILEUX_SITE;
			} else if (potentialModifiers.isSelected()) {
				ip.heightGrowthOption = HetInitialParameters.POTENTIAL_MODIFIERS_HEIGHT_GROWTH;
			}
			Settings.setProperty("heterofor.heightGrowthOption", ip.heightGrowthOption);

			Settings.setProperty("heterofor.cuttingDiameter", ip.cuttingDiameter);

			ip.buildInitScene(model);

			setInitialParameters(ip);

			pack();

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetInitialDialog", "Error while create init parameters", e);
			MessageDialog.print(this, Translator.swap("HetInitialDialog.errorDuringInitialisationPleaseCheckLog"), e);
			return;
		}

		setValidDialog(true);

	}

	/**
	 * Show a file chooser and set the file field.
	 */
	private void speciesBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.species.path",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = CheckingFileChooser.getInstance(
				Settings.getProperty("heterofor.species.path", PathManager.getDir("data") + File.separator
						+ "heterofor"), HetSpeciesFileLoader.class);

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			speciesFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Show a file chooser and set the file field.
	 */
	private void castaneaBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.castaneaFileName.path",
		// PathManager.getDir("data") + File.separator + "heterofor" ));

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = new CheckingFileChooser(Settings.getProperty("heterofor.castaneaFileName.path",
				PathManager.getDir("data") + File.separator + "heterofor")) {

			/**
			 * Throws an  if the file is not correct.
			 */
			public void check(File file) throws Exception {
				// Note: FmSpeciesReader needs extra parameters: we need to
				// redefine
				// check ()

				// Just checks if the loader loads, do not check until Plot
				// creation (would need other files)
				new FmSpeciesReader(file.getAbsolutePath(), new FmSettings());

				// file seems ok
			}
		};

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			castaneaFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Show a file chooser and set the file field.
	 */
	private void browseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.inventory.path",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = CheckingFileChooser.getInstance(
				Settings.getProperty("heterofor.inventory.path", PathManager.getDir("data") + File.separator
						+ "heterofor"), HetInventoryLoader.class);

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			inventoryFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Get a SamsaraLight parameter file with a file chooser.
	 */
	private void samsaraLightBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.samsaraLightPath",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = CheckingFileChooser.getInstance(
				Settings.getProperty("heterofor.samsaraLightPath", PathManager.getDir("data") + File.separator
						+ "heterofor"), SLSettingsLoader.class);

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			samsaraLightFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Open a file chooser to get the requested file name
	 */
	private void soilHorizonsBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.soilHorizonsPath",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc+nb-8.12.2017 optional file path determination strategy
		String path = soilHorizonsFileName.getText().trim();
		if (!new File(path).exists()) {
			path = Settings.getProperty("heterofor.soilHorizonsPath", "");
			if (!new File(path).exists())
				path = PathManager.getDir("data") + File.separator + "heterofor";
		}

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = CheckingFileChooser.getInstance(path, HetSoilHorizonsFileLoader.class);

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			soilHorizonsFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Open a file chooser to get the requested file name
	 */
	private void soilChemistryBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.soilChemistryPath",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc+nb-8.12.2017 optional file path determination strategy
		String path = soilChemistryFileName.getText().trim();
		if (!new File(path).exists()) {
			path = Settings.getProperty("heterofor.soilChemistryPath", "");
			if (!new File(path).exists())
				path = PathManager.getDir("data") + File.separator + "heterofor";
		}

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = new CheckingFileChooser(path) {

			/**
			 * Throws an exception if the file is not correct.
			 */
			@Override
			public void check(File file) throws Exception {
				// Note: we need to call HetSoilChemistryFileLoader.load ()

				// Check if the loader loads ant interprets the file
				HetSoilChemistryFileLoader loader = new HetSoilChemistryFileLoader();

				// Fake object for test time
				HetModel modelFake = new HetModel();
				HetInitialParameters ipFake = modelFake.getSettings();
				HetScene sceneFake = new HetScene();

				loader.load(file.getAbsolutePath(), ipFake, modelFake, sceneFake);

				// file seems ok
			}
		};

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			soilChemistryFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Open a file chooser to get the requested file name
	 */
	private void meteorologyBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.meteorologyPath",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc+nb-8.12.2017 optional file path determination strategy
		String path = meteorologyFileName.getText().trim();
		if (!new File(path).exists()) {
			path = Settings.getProperty("heterofor.meteorologyPath", "");
			if (!new File(path).exists())
				path = PathManager.getDir("data") + File.separator + "heterofor";
		}

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = new CheckingFileChooser(path) {

			@Override
			public void check(File f) throws Exception {

				HetMeteorologyFileLoader loader = new HetMeteorologyFileLoader();
				loader.load(f.getAbsolutePath());
			}
		};

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			meteorologyFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Opens a file chooser to get the requested fructification's observations
	 * file.
	 */
	private void fructificationBrowseAction() {

		// JFileChooser chooser = new
		// JFileChooser(Settings.getProperty("heterofor.fructificationPath",
		// PathManager.getDir("data") + File.separator + "heterofor"));

		// fc+nb-8.12.2017 optional file path determination strategy
		String path = fructificationFileName.getText().trim();
		if (!new File(path).exists()) {
			path = Settings.getProperty("heterofor.fructificationPath", "");
			if (!new File(path).exists())
				path = PathManager.getDir("data") + File.separator + "heterofor";
		}

		// fc-8.11.2017 CheckingFileChooser tells user which files are supposed
		// to be correct
		JFileChooser chooser = CheckingFileChooser.getInstance(path, HetFructificationFileLoader.class);

		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton
														// text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			fructificationFileName.setText(chooser.getSelectedFile().getPath());

	}

	/**
	 * Enable or disable the discretisation space step textfield
	 */
	private void mineralHorizonsTemperatureCalculationAction() {

		discretisationSpaceStep.setEnabled(mineralHorizonsTemperatureCalculationActivated.isSelected());
	}

	/**
	 * Opens a file chooser to get the atmospheric CO2 concentrations file. Checks also if the format of the file is valid.
	 */
	private void atmCO2ConcentrationBrowseAction() {

		String path = Settings.getProperty("heterofor.atmCO2FilePath", PathManager.getDir("data") + File.separator + "heterofor" + File.separator + "atmosphericCO2Concentration");

		// CheckingFileChooser tells user which files are supposed to be correct.
		JFileChooser chooser = CheckingFileChooser.getInstance(path, HetAtmosphericCO2ConcentrationFileLoader.class);
		chooser.setDialogTitle(Translator.swap("HetInitialDialog.fileChooser"));

		int returnVal = chooser.showDialog(this, null); // null: approveButton text was already set

		if (returnVal == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile().exists())
			atmCO2FileNameTextField.setText(chooser.getSelectedFile().getPath());
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource().equals(speciesBrowse)) {
			speciesBrowseAction();
		} else if (e.getSource().equals(castaneaBrowse)) {
			castaneaBrowseAction();
		} else if (e.getSource().equals(browse)) {
			browseAction();
		} else if (e.getSource().equals(samsaraLightBrowse)) {
			samsaraLightBrowseAction();
		} else if (e.getSource().equals(soilHorizonsBrowse)) {
			soilHorizonsBrowseAction();
		} else if (e.getSource().equals(soilChemistryBrowse)) {
			soilChemistryBrowseAction();
		} else if (e.getSource().equals(meteorologyBrowse)) {
			meteorologyBrowseAction();
		} else if (e.getSource().equals(fructificationBrowse)) {
			fructificationBrowseAction();
		} else if (e.getSource().equals(waterBalanceActivated)) {
			synchro();
		} else if (e.getSource().equals(mineralHorizonsTemperatureCalculationActivated)) {
			mineralHorizonsTemperatureCalculationAction();
		} else if (e.getSource().equals(fixedAtmCO2Button)) {
			atmCO2GroupAction();
		} else if (e.getSource().equals(variableAtmCO2Button)) {
			atmCO2GroupAction();
		} else if (e.getSource().equals(atmCO2FileBrowse)) {
			atmCO2ConcentrationBrowseAction();
		} else if (e.getSource().equals(ok)) {
			okAction();
		} else if (e.getSource().equals(cancel)) {
			setValidDialog(false);
		} else if (e.getSource().equals(help)) {
			Helper.helpFor(this);
		}
	}

	private void synchro() {
		waterBalance_treeLevelTranspiration.setEnabled(waterBalanceActivated.isSelected());
	}

	private void atmCO2GroupAction() {

		fixedAtmCO2TextField.setEnabled(fixedAtmCO2Button.isSelected());
		atmCO2FileNameTextField.setEnabled(variableAtmCO2Button.isSelected());
		atmCO2FileBrowse.setEnabled(variableAtmCO2Button.isSelected());
	}

	/**
	 * Create the GUI
	 */
	private void createUI() {

		// existing file for inventory data
		ColumnPanel main = new ColumnPanel();

		// Input files
		ColumnPanel c5 = new ColumnPanel(Translator.swap("HetInitialDialog.inputFiles"));
		main.add(c5);

		// Separated species file (not needed if Quergus inventory)
		LinePanel l0 = new LinePanel();
		l0.add(new JWidthLabel(Translator.swap("HetInitialDialog.speciesFileName") + " :", 250));
		speciesFileName = new JTextField(30);
		speciesFileName.setText(Settings.getProperty("heterofor.species.path", PathManager.getDir("data")
				+ File.separator + "heterofor"));
		l0.add(speciesFileName);
		speciesBrowse = new JButton(Translator.swap("Shared.browse"));
		speciesBrowse.addActionListener(this);
		l0.add(speciesBrowse);
		l0.addStrut0();
		c5.add(l0);

		// Castanea species file
		LinePanel l0a = new LinePanel();
		l0a.add(new JWidthLabel(Translator.swap("HetInitialDialog.castaneaFileName") + " :", 250));
		castaneaFileName = new JTextField(30);
		castaneaFileName.setText(Settings.getProperty("heterofor.castaneaFileName.path", PathManager.getDir("data")
				+ File.separator + "heterofor"));
		l0a.add(castaneaFileName);
		castaneaBrowse = new JButton(Translator.swap("Shared.browse"));
		castaneaBrowse.addActionListener(this);
		l0a.add(castaneaBrowse);
		l0a.addStrut0();
		c5.add(l0a);

		// Inventory file (Heterofor or Quergus formats)
		LinePanel l1 = new LinePanel();
		l1.add(new JWidthLabel(Translator.swap("HetInitialDialog.inventoryFileName") + " :", 250));
		inventoryFileName = new JTextField(30);
		inventoryFileName.setText(Settings.getProperty("heterofor.inventory.path", PathManager.getDir("data")
				+ File.separator + "heterofor"));
		l1.add(inventoryFileName);
		browse = new JButton(Translator.swap("Shared.browse"));
		browse.addActionListener(this);
		l1.add(browse);
		l1.addStrut0();
		c5.add(l1);

		// General light settings (from SLSettings)
		LinePanel l2 = new LinePanel();
		l2.add(new JWidthLabel(Translator.swap("HetInitialDialog.samsaraLightFileName") + " :", 250));
		samsaraLightFileName = new JTextField(30);
		samsaraLightFileName.setText(Settings.getProperty("heterofor.samsaraLightPath", PathManager.getDir("data")
				+ File.separator + "heterofor"));
		l2.add(samsaraLightFileName);
		samsaraLightBrowse = new JButton(Translator.swap("HetInitialDialog.samsaraLightBrowse"));
		samsaraLightBrowse.addActionListener(this);
		l2.add(samsaraLightBrowse);
		l2.addStrut0();
		c5.add(l2);

		// Soil horizons file name (optional)
		LinePanel l2h = new LinePanel();
		l2h.add(new JWidthLabel(Translator.swap("HetInitialDialog.soilHorizonsFileName") + " :", 250));
		soilHorizonsFileName = new JTextField(30);
		soilHorizonsFileName.setText(Settings.getProperty("heterofor.soilHorizonsPath", ""));
		l2h.add(soilHorizonsFileName);
		soilHorizonsBrowse = new JButton(Translator.swap("HetInitialDialog.soilHorizonsBrowse"));
		soilHorizonsBrowse.addActionListener(this);
		l2h.add(soilHorizonsBrowse);
		l2h.addStrut0();
		c5.add(l2h);

		// Soil chemistry file name (optional)
		// If given, requires soil horizons to be provided
		LinePanel l2e = new LinePanel();
		l2e.add(new JWidthLabel(Translator.swap("HetInitialDialog.soilChemistryFileName") + " :", 250));
		soilChemistryFileName = new JTextField(30);
		soilChemistryFileName.setText(Settings.getProperty("heterofor.soilChemistryPath", ""));
		l2e.add(soilChemistryFileName);
		soilChemistryBrowse = new JButton(Translator.swap("HetInitialDialog.soilChemistryBrowse"));
		soilChemistryBrowse.addActionListener(this);
		l2e.add(soilChemistryBrowse);
		l2e.addStrut0();
		c5.add(l2e);

		// Meteorology file name (optional)
		// If given, requires soil horizons to be provided
		LinePanel l2f = new LinePanel();
		l2f.add(new JWidthLabel(Translator.swap("HetInitialDialog.meteorologyFileName") + " :", 250));
		meteorologyFileName = new JTextField(30);
		meteorologyFileName.setText(Settings.getProperty("heterofor.meteorologyPath", ""));
		l2f.add(meteorologyFileName);
		meteorologyBrowse = new JButton(Translator.swap("HetInitialDialog.meteorologyBrowse"));
		meteorologyBrowse.addActionListener(this);
		l2f.add(meteorologyBrowse);
		l2f.addStrut0();
		c5.add(l2f);

		// Fructification observations file name
		LinePanel l2g = new LinePanel();
		l2g.add(new JWidthLabel(Translator.swap("HetInitialDialog.fructificationFileName") + " :", 250));
		fructificationFileName = new JTextField(30);
		fructificationFileName.setText(Settings.getProperty("heterofor.fructificationPath", ""));
		l2g.add(fructificationFileName);
		fructificationBrowse = new JButton(Translator.swap("HetInitialDialog.fructificationBrowse"));
		fructificationBrowse.addActionListener(this);
		l2g.add(fructificationBrowse);
		l2g.addStrut0();
		c5.add(l2g);

		// Radiative budget
		ColumnPanel c2 = new ColumnPanel(Translator.swap("HetInitialDialog.radiativeBudget"));
		main.add(c2);

		// fc+fa-28.4.2017
		LinePanel l2m = new LinePanel();
		fineResolutionRadiativeBalanceActivated = new JCheckBox(
				Translator.swap("HetInitialDialog.fineResolutionRadiativeBalanceActivated"));
		fineResolutionRadiativeBalanceActivated.setSelected(Settings.getProperty(
				"heterofor.fineResolutionRadiativeBalanceActivated", ip.fineResolutionRadiativeBalanceActivated));
		l2m.add(fineResolutionRadiativeBalanceActivated);
		l2m.addGlue();
		c2.add(l2m);

		// fc+mj-21.11.2013
		LinePanel l2a = new LinePanel();
		l2a.add(new JWidthLabel(Translator.swap("HetInitialDialog.radiationCalculationTimeStep") + " :", 100));
		radiationCalculationTimeStep = new JTextField(30);
		radiationCalculationTimeStep
				.setText(""
						+ Settings.getProperty("heterofor.radiationCalculationTimeStep",
								ip.radiationCalculationTimeStep));
		l2a.add(radiationCalculationTimeStep);
		l2a.addStrut0();
		c2.add(l2a);

		// Modules
		ColumnPanel c6 = new ColumnPanel(Translator.swap("HetInitialDialog.modules"));
		main.add(c6);

		// Activate the phenology module
		// nb+lw+fa-19.01.17
		LinePanel l2j = new LinePanel();
		phenologyActivated = new JCheckBox(Translator.swap("HetInitialDialog.activatePhenology"));
		phenologyActivated.setSelected(Settings
				.getProperty("heterofor.phenologyActivated", ip.phenologyActivated));
		l2j.add(phenologyActivated);
		l2j.addGlue();
		c6.add(l2j);

		// fc+mj-13.9.2017
		LinePanel l2o = new LinePanel();
		waterBalanceActivated = new JCheckBox(Translator.swap("HetInitialDialog.waterBalanceActivated"));
		waterBalanceActivated.setSelected(Settings.getProperty("heterofor.waterBalanceActivated",
				ip.waterBalanceActivated));
		waterBalanceActivated.addActionListener(this);
		l2o.add(waterBalanceActivated);

		waterBalance_treeLevelTranspiration = new JCheckBox(
				Translator.swap("HetInitialDialog.waterBalance_treeLevelTranspiration"));
		waterBalance_treeLevelTranspiration.setSelected(Settings.getProperty(
				"heterofor.waterBalance_treeLevelTranspiration", ip.waterBalance_treeLevelTranspiration));
		l2o.add(waterBalance_treeLevelTranspiration);

		l2o.addGlue();
		c6.add(l2o);

		// fc-27.1.2017
		LinePanel l2k = new LinePanel();
		castaneaPhotosynthesisActivated = new JCheckBox(
				Translator.swap("HetInitialDialog.castaneaPhotosynthesisActivated"));
		castaneaPhotosynthesisActivated.setSelected(Settings.getProperty("heterofor.castaneaPhotosynthesisActivated",
				ip.castaneaPhotosynthesisActivated));
		l2k.add(castaneaPhotosynthesisActivated);
		l2k.addGlue();
		c6.add(l2k);

		LinePanel l2b = new LinePanel();

		maintenanceRespirationActivated = new JCheckBox(
				Translator.swap("HetInitialDialog.maintenanceRespirationActivated"));
		maintenanceRespirationActivated.setSelected(Settings.getProperty("heterofor.maintenanceRespirationActivated",
				!ip.constantNppToGppRatio));
		l2b.add(maintenanceRespirationActivated);
		l2b.addGlue();
		c6.add(l2b);

		// nb+lw-25.04.2017
		LinePanel l2l = new LinePanel();
		mineralHorizonsTemperatureCalculationActivated = new JCheckBox(
				Translator.swap("HetInitialDialog.mineralHorizonsTemperatureCalculationActivated"));
		mineralHorizonsTemperatureCalculationActivated.setSelected(Settings.getProperty(
				"heterofor.mineralHorizonsTemperatureCalculationActivated",
				ip.mineralHorizonsTemperatureCalculationActivated));
		mineralHorizonsTemperatureCalculationActivated.addActionListener(this);
		l2l.add(mineralHorizonsTemperatureCalculationActivated);
		l2l.addStrut(50);
		l2l.add(new JWidthLabel(Translator.swap("HetInitialDialog.discretisationSpaceStep") + " :", 100));
		discretisationSpaceStep = new JTextField(10);
		discretisationSpaceStep.setText(""
				+ Settings.getProperty("heterofor.discretisationSpaceStep", ip.discretisationSpaceStep));
		discretisationSpaceStep.setEnabled(mineralHorizonsTemperatureCalculationActivated.isSelected()); // useful
																											// when
																											// building
																											// user
																											// interface
		l2l.add(discretisationSpaceStep);
		l2l.addGlue();
		c6.add(l2l);

		LinePanel l2c = new LinePanel();
		competitionAccountedForCrownGrowth = new JCheckBox(
				Translator.swap("HetInitialDialog.competitionAccountedForCrownGrowth"));
		competitionAccountedForCrownGrowth.setSelected(Settings.getProperty(
				"heterofor.competitionAccountedForCrownGrowth", ip.competitionAccountedForCrownGrowth));
		l2c.add(competitionAccountedForCrownGrowth);
		l2c.addGlue();
		c6.add(l2c);

		// Nutrient limitation
		LinePanel nutrientLimitationLinePanel = new LinePanel(Translator.swap("HetInitialDialog.nutrientLimitation"));
		generalNutrientLimitation = new JCheckBox(Translator.swap("HetInitialDialog.generalNutrientLimitation"));
		generalNutrientLimitation.setSelected(Settings.getProperty("heterofor.generalNutrientLimitation",
				ip.generalNutrientLimitation));
		nutrientLimitationLinePanel.add(generalNutrientLimitation);
		nLimitation = new JCheckBox(Translator.swap("HetInitialDialog.nLimitation"));
		nLimitation.setSelected(Settings.getProperty("heterofor.nLimitation", ip.nLimitation));
		nutrientLimitationLinePanel.add(nLimitation);
		nutrientLimitationLinePanel.addGlue();
		main.add(nutrientLimitationLinePanel);

		// LinePanel l2a = new LinePanel();
		// l2a.add(new
		// JWidthLabel(Translator.swap("HetInitialDialog.radiationCalculationTimeStep")
		// + " :", 100));
		// radiationCalculationTimeStep = new JTextField(30);
		// radiationCalculationTimeStep
		// .setText(""
		// + Settings.getProperty("heterofor.radiationCalculationTimeStep",
		// settings.radiationCalculationTimeStep));
		// l2a.add(radiationCalculationTimeStep);
		// l2a.addStrut0();
		// main.add(l2a);

		// fc+mj-30.4.2015 LAD and T options now in species
		// // LAD option
		// ColumnPanel c1 = new
		// ColumnPanel(Translator.swap("HetInitialDialog.LADoption"));
		//
		// LinePanel l3 = new LinePanel();
		// meanLAD = new
		// JRadioButton(Translator.swap("HetInitialDialog.meanLAD"));
		// l3.add(meanLAD);
		// l3.addGlue();
		// c1.add(l3);
		//
		// LinePanel l4 = new LinePanel();
		// meanSLA = new
		// JRadioButton(Translator.swap("HetInitialDialog.meanSLA"));
		// l4.add(meanSLA);
		// l4.addGlue();
		// c1.add(l4);
		//
		// LinePanel l5 = new LinePanel();
		// SLAmodel = new
		// JRadioButton(Translator.swap("HetInitialDialog.SLAmodel"));
		// l5.add(SLAmodel);
		// l5.addGlue();
		// c1.add(l5);
		//
		// LinePanel l6 = new LinePanel();
		// quergusLAD = new
		// JRadioButton(Translator.swap("HetInitialDialog.quergusLAD"));
		// l6.add(quergusLAD);
		// l6.addGlue();
		// c1.add(l6);
		//
		// group1 = new ButtonGroup();
		// group1.add(meanLAD);
		// group1.add(meanSLA);
		// group1.add(SLAmodel);
		// group1.add(quergusLAD);
		//
		// int option = Settings.getProperty("heterofor.LADoption",
		// HetInitialParameters.MEAN_LAD);
		// if (option == HetInitialParameters.MEAN_LAD) {
		// meanLAD.setSelected(true);
		// } else if (option == HetInitialParameters.MEAN_SLA) {
		// meanSLA.setSelected(true);
		// } else if (option == HetInitialParameters.SLA_MODEL) {
		// SLAmodel.setSelected(true);
		// } else {
		// quergusLAD.setSelected(true);
		// }
		//
		// main.add(c1);

		// // Toption fc-30.5.2013
		// ColumnPanel c2 = new
		// ColumnPanel(Translator.swap("HetInitialDialog.Toption"));
		//
		// LinePanel l8 = new LinePanel();
		// meanT = new JRadioButton(Translator.swap("HetInitialDialog.meanT"));
		// l8.add(meanT);
		// l8.addGlue();
		// c2.add(l8);
		//
		// LinePanel l9 = new LinePanel();
		// quergusT = new
		// JRadioButton(Translator.swap("HetInitialDialog.quergusT"));
		// l9.add(quergusT);
		// l9.addGlue();
		// c2.add(l9);
		//
		// group2 = new ButtonGroup();
		// group2.add(meanT);
		// group2.add(quergusT);
		//
		// option = Settings.getProperty("heterofor.Toption",
		// HetInitialParameters.MEAN_T);
		// if (option == HetInitialParameters.MEAN_T) {
		// meanT.setSelected(true);
		// } else { // HetInitialParameters.QUERGUS_T
		// quergusT.setSelected(true);
		// }
		//
		// main.add(c2);

		// Atmospheric CO2 concentration. nb-14.03.2018
		ColumnPanel atmCO2ColumnPanel = new ColumnPanel(Translator.swap("HetInitialDialog.atmCO2Concentration"));

		LinePanel fixedAtmCO2LinePanel = new LinePanel();
		fixedAtmCO2Button = new JRadioButton(Translator.swap("HetInitialDialog.fixedAtmCO2"));
		fixedAtmCO2LinePanel.add(fixedAtmCO2Button);
		fixedAtmCO2LinePanel.addStrut(50);
		fixedAtmCO2LinePanel.add(new JWidthLabel(Translator.swap("HetInitialDialog.fixedAtmCO2Value") + " :", 100));
		fixedAtmCO2TextField = new JTextField(30);
		fixedAtmCO2TextField.setText("" + Settings.getProperty("heterofor.fixedAtmCO2Concentration", ip.Ca));
		fixedAtmCO2LinePanel.add(fixedAtmCO2TextField);
		fixedAtmCO2LinePanel.addStrut0();

		LinePanel variableAtmCO2LinePanel = new LinePanel();
		variableAtmCO2Button = new JRadioButton(Translator.swap("HetInitialDialog.variableAtmCO2"));
		variableAtmCO2LinePanel.add(variableAtmCO2Button);
		variableAtmCO2LinePanel.addStrut(20);
		variableAtmCO2LinePanel.add(new JWidthLabel(Translator.swap("HetInitialDialog.variableAtmCO2FileName") + " :", 5));
		atmCO2FileNameTextField = new JTextField(30);
		atmCO2FileNameTextField.setText(Settings.getProperty("heterofor.atmCO2FilePath", PathManager.getDir("data")
				+ File.separator + "heterofor" + File.separator + "atmosphericCO2Concentration"));
		variableAtmCO2LinePanel.add(atmCO2FileNameTextField);
		atmCO2FileBrowse = new JButton(Translator.swap("Shared.browse"));
		atmCO2FileBrowse.addActionListener(this);
		variableAtmCO2LinePanel.add(atmCO2FileBrowse);
		variableAtmCO2LinePanel.addStrut0();

		atmCO2ColumnPanel.add(fixedAtmCO2LinePanel);
		atmCO2ColumnPanel.add(variableAtmCO2LinePanel);
		main.add(atmCO2ColumnPanel);

		atmCO2Group = new ButtonGroup();
		atmCO2Group.add(fixedAtmCO2Button);
		atmCO2Group.add(variableAtmCO2Button);

		fixedAtmCO2Button.addActionListener(this);
		variableAtmCO2Button.addActionListener(this);

		String atmCO2Option = Settings.getProperty("heterofor.atmCO2Option", HetInitialParameters.FIXED_ATMOSPHERIC_CO2_CONCENTRATION);
		if (atmCO2Option.equals(HetInitialParameters.FIXED_ATMOSPHERIC_CO2_CONCENTRATION)) {
			fixedAtmCO2Button.setSelected(true);
		} else if (atmCO2Option.equals(HetInitialParameters.VARIABLE_ATMOSPHERIC_CO2_CONCENTRATION)) {
			variableAtmCO2Button.setSelected(true);
		} else {
			Log.println(Log.ERROR, "HetInitialDialog.createUI()",
							"Error: undefined option for the atmospheric CO2 concentration's management");
			MessageDialog.print(this, Translator.swap("HetInitialDialog.undefinedOptionForAtmosphericCO2ConcentrationManagementSeeTheLog"));
			return;
		}

		// Height growth options fc+mj-29.4.2015
		LinePanel heightGrowthOptionsLinePanel = new LinePanel(Translator.swap("HetInitialDialog.heightGrowthOption"));

		iprfw = new JRadioButton(Translator.swap("HetInitialDialog.iprfw"));
		heightGrowthOptionsLinePanel.add(iprfw);

		baileuxSite = new JRadioButton(Translator.swap("HetInitialDialog.baileuxSite"));
		heightGrowthOptionsLinePanel.add(baileuxSite);

		// fc+mj-6.12.2016
		potentialModifiers = new JRadioButton(Translator.swap("HetInitialDialog.potentialModifiers"));
		heightGrowthOptionsLinePanel.add(potentialModifiers);
		heightGrowthOptionsLinePanel.addGlue();

		main.add(heightGrowthOptionsLinePanel);

		group3 = new ButtonGroup();
		group3.add(iprfw);
		group3.add(baileuxSite);
		group3.add(potentialModifiers);

		String option = Settings.getProperty("heterofor.heightGrowthOption", HetInitialParameters.IPRFW);
		if (option.equals(HetInitialParameters.BAILEUX_SITE)) {
			baileuxSite.setSelected(true);
		} else if (option.equals(HetInitialParameters.POTENTIAL_MODIFIERS_HEIGHT_GROWTH)) {
			potentialModifiers.setSelected(true);
		} else {
			iprfw.setSelected(true);
		}

		// Management and mortality options
		ColumnPanel c4 = new ColumnPanel(Translator.swap("HetInitialDialog.managementAndMortality"));
		main.add(c4);

		LinePanel l2d = new LinePanel();
		mortalityActivated = new JCheckBox(Translator.swap("HetInitialDialog.mortalityActivated"));
		mortalityActivated.setSelected(Settings
				.getProperty("heterofor.mortalityActivated", ip.mortalityActivated));
		l2d.add(mortalityActivated);
		l2d.addGlue();
		c4.add(l2d);

		// fc+mj-9.5.2016
		LinePanel l12 = new LinePanel();
		l12.add(new JWidthLabel(Translator.swap("HetInitialDialog.cuttingDiameter") + " :", 250));
		cuttingDiameter = new JTextField();
		cuttingDiameter.setText("" + Settings.getProperty("heterofor.cuttingDiameter", ip.cuttingDiameter));
		l12.add(cuttingDiameter);
		l12.addGlue();
		c4.add(l12);
		// heightGrowthOption // fc+mj-29.4.2015

		main.addStrut1();

		synchro();
		atmCO2GroupAction();

		// Control panel buttons
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		ok = new JButton(Translator.swap("Shared.ok"));
		ok.addActionListener(this);
		ImageIcon icon = IconLoader.getIcon("ok_16.png");
		ok.setIcon(icon);

		cancel = new JButton(Translator.swap("Shared.cancel"));
		cancel.addActionListener(this);
		icon = IconLoader.getIcon("cancel_16.png");
		cancel.setIcon(icon);

		help = new JButton(Translator.swap("Shared.help"));
		help.addActionListener(this);
		icon = IconLoader.getIcon("help_16.png");
		help.setIcon(icon);

		controlPanel.add(ok);
		controlPanel.add(cancel);
		controlPanel.add(help);

		// Sets ok as default
		setDefaultButton(ok);

		// fc-12.9.2017 add space around the main panel
		LinePanel aux = new LinePanel(5, 5);
		aux.add(main);
		aux.addStrut0();

		getContentPane().add(aux, BorderLayout.NORTH);
		getContentPane().add(controlPanel, BorderLayout.SOUTH);

		this.setModal(true);
		setTitle(Translator.swap("HetInitialDialog.title"));
		this.pack();
		this.setVisible(true);
	}
}
