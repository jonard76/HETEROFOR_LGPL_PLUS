/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.dataextractor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import capsis.extension.dataextractor.format.DFListOfXYSeries;
import capsis.extension.dataextractor.superclass.AbstractDataExtractor;
import capsis.kernel.GModel;
import capsis.kernel.Step;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.phenology.HetPhenology;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import jeeb.lib.util.XYSeries;

/**
 * Evolution of lad proportion and green proportion over time per species.
 *
 * @author N. Beudez - June 2017
 */
public class HetTimeFoliageState extends AbstractDataExtractor implements DFListOfXYSeries {

	static {
		Translator.addBundle("heterofor.extension.dataextractor.DELabels");
	}

	// nb-13.08.2018
	//public static final String NAME = Translator.swap("HetTimeFoliageState");
	//public static final String DESCRIPTION = Translator.swap("HetTimeFoliageState.description");
	//public static final String AUTHOR = "N. Beudez";
	//public static final String VERSION = "1.0";

	protected List<XYSeries> listOfXYSeries;

	private String greenProp;
	private String ladProp;

	/**
	 * Constructor.
	 */
	public HetTimeFoliageState() {

		greenProp = "o-block1-1-1-greenProp";
		ladProp = "o-block1-2-1-ladProp";
	}

	@Override
	public void init(GModel m, Step s) throws Exception {
		super.init(m, s);

		try {
			// Nothing more, no configuration at this time
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTimeFoliageState.init()", "Exception", e);
			throw e;
		}
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		return referent instanceof HetModel;
	}

	/**
	 * All extractors must be able to return their name. The caller can try to
	 * translate it with Translator.swap (name) if necessary (ex: gui renderer
	 * translates, file writer does not).
	 */
	public String getName() {
		return getNamePrefix() + Translator.swap("HetTimeFoliageState.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetTimeFoliageState.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	// nb-14.01.2019
	@Override
	public String getDefaultDataRendererClassName() {
		return "capsis.extension.datarenderer.drgraph.DRGraph";
	}

	/**
	 * This method is called by superclass DataExtractor constructor. If
	 * previous config was saved in a file, this method may not be called. See
	 * etc/extensions.settings file
	 */
	@Override
	public void setConfigProperties() {

		// 1-1: line 1, column 1
		// 2-1: line 2, column 1
		addBooleanProperty(greenProp, true);
		addBooleanProperty(ladProp, true);

		HetInitialParameters ip = (HetInitialParameters) step.getProject().getModel().getSettings();

		Properties additionalTranslations = new Properties();

		for (int speciesId : ip.speciesMap.keySet()) {
			String speciesNiceName = ip.speciesMap.get(speciesId).niceName;

			String key = makeSpeciesKey(speciesId, speciesNiceName);
			addBooleanProperty(key, true);

			// The technical key is there for layout, it will be translated into
			// species nice name
			additionalTranslations.setProperty(key, speciesNiceName);
		}

		Translator.getMainLexicon().loadBundle(additionalTranslations);

	}

	/**
	 * Builds a key for the given species, related to config properties fine layout.
	 */
	private String makeSpeciesKey (int speciesId, String speciesNiceName) {
		return "o-block2-" + speciesId + "-1-" + speciesNiceName;
	}

	/**
	 * From DataExtractor SuperClass.
	 *
	 * Computes the data series. This is the real output building. It refers to
	 * a reference Step.
	 *
	 * Return false if trouble while extracting.
	 */
	public boolean doExtraction() {

		if (upToDate)
			return true;

		if (step == null)
			return false;

		try {
			HetInitialParameters ip = (HetInitialParameters) step.getProject().getModel().getSettings();

			// Map for green proportion coefficient with key: species id, value:
			// the corresponding xy serie
			Map<Integer, XYSeries> speciesIdGreenPropXYSerieMap = new HashMap<Integer, XYSeries>();

			// Map for lad proportion coefficient with key: species id, value:
			// the corresponding xy serie
			Map<Integer, XYSeries> speciesIdLadPropXYSerieMap = new HashMap<Integer, XYSeries>();

			listOfXYSeries = new ArrayList<XYSeries>();

			if (isSet(greenProp)) {

				for (int speciesId : ip.speciesMap.keySet()) {

					String speciesNiceName = ip.speciesMap.get(speciesId).niceName;

					String option = makeSpeciesKey(speciesId, speciesNiceName);
					if (isSet(option)) {

						XYSeries xySerie = new XYSeries(speciesNiceName + "-greenProp", ip.speciesMap.get(speciesId).color);
						speciesIdGreenPropXYSerieMap.put(speciesId, xySerie);
						listOfXYSeries.add(xySerie);
					}

				}
			}

			if (isSet(ladProp)) {

				for (int speciesId : ip.speciesMap.keySet()) {

					String speciesNiceName = ip.speciesMap.get(speciesId).niceName;

					String option = makeSpeciesKey(speciesId, speciesNiceName);
					if (isSet(option)) {
						XYSeries xySerie = new XYSeries(ip.speciesMap.get(speciesId).niceName + "-ladProp",
								ip.speciesMap.get(speciesId).color);
						speciesIdLadPropXYSerieMap.put(speciesId, xySerie);
						listOfXYSeries.add(xySerie);
					}
				}
			}

			// Retrieve Steps from root to reference step
			Vector steps = step.getProject().getStepsFromRoot(step);

			int numberOfDays = 0;

			// Loop on steps
			Iterator iterator = steps.iterator();
			while (iterator.hasNext()) {

				Step step = (Step) iterator.next();
				HetScene scene = (HetScene) step.getScene();

				HashMap<Integer, HetPhenology> phenologyMap = scene.getPhenologyMap();

				int nbOfDaysOfYear = 0;

				for (int speciesId : ip.speciesMap.keySet()) {

					String option = makeSpeciesKey(speciesId, ip.speciesMap.get(speciesId).niceName);
					if (isSet(option)) {

						HetPhenology phenology = phenologyMap.get(speciesId);

						HashMap<Integer, Double> doyGreenPropMap = phenology.getDoyGreenPropMap();
						HashMap<Integer, Double> doyLadPropMap = phenology.getDoyLadPropMap();

						nbOfDaysOfYear = doyGreenPropMap.keySet().size();

						if (isSet(greenProp)) {

							XYSeries greenPropXYSerie = speciesIdGreenPropXYSerieMap.get(speciesId);
							for (int dayOfYear : doyGreenPropMap.keySet()) {
								greenPropXYSerie.addPoint(numberOfDays + dayOfYear, doyGreenPropMap.get(dayOfYear));
							}
						}

						if (isSet(ladProp)) {

							XYSeries ladPropXYSerie = speciesIdLadPropXYSerieMap.get(speciesId);
							for (int dayOfYear : doyLadPropMap.keySet()) {
								ladPropXYSerie.addPoint(numberOfDays + dayOfYear, doyLadPropMap.get(dayOfYear));
							}
						}
					}
				}

				numberOfDays += nbOfDaysOfYear;
			}
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTimeFoliageState.doExtraction()", "Exception", e);
			return false;
		}

		upToDate = true;
		return true;
	}

	/**
	 * Returns x and y axes names in this order for a graph where all the
	 * xySeries can be drawn together.
	 */
	public List<String> getAxesNames() {
		Vector v = new Vector();
		v.add(Translator.swap("HetTimeFoliageState.xLabel"));
		v.add(Translator.swap("HetTimeFoliageState.yLabel"));
		return v;
	}

	/**
	 * Returns the list of XYSeries.
	 */
	public List<XYSeries> getListOfXYSeries() {
		return listOfXYSeries;
	}

}
