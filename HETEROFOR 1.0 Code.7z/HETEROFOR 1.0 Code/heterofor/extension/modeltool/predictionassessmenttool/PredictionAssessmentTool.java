/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.predictionassessmenttool;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;

import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.PathManager;
import jeeb.lib.util.Question;
import jeeb.lib.util.Settings;
import jeeb.lib.util.Translator;
import capsis.app.C4Script;
import capsis.commongui.util.Helper;
import capsis.extension.DialogModelTool;
import capsis.gui.MainFrame;
import capsis.kernel.GModel;
import capsis.kernel.Project;
import capsis.kernel.Step;

/**
 * A tool to assess the quality of the Heterofor predictions
 *
 * @author M. Jonard, F. de Coligny - April 2015
 */
public class PredictionAssessmentTool extends DialogModelTool implements ActionListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.predictionassessmenttool.PredictionAssessmentTool");
	}

	// nb-13.08.2018
	//static public final String AUTHOR = "M. Jonard, F. de Coligny";
	//static public final String VERSION = "1.0";

	private static final int INITIAL_WIDTH = 700;
	private static final int INITIAL_HEIGHT = 600;

	private Step refStep;
	private Project refProject;

	private HetScene initScene;
	private HetScene refScene;
	private HetScene obsScene;

	private int date1;
	private int date2;

	private JTextField observationFileName;
	private JButton browse;
	private boolean observationIsLoaded;

	private double bufferWidth = 15; // m
	private Rectangle.Double innerZone;

	private JScrollPane scroll;

	private LinePanel controlPanel;
	private JLabel status; // fc-4.5.2015
	private JButton close; // after confirmation
	private JButton help;

	/**
	 * Constructor.
	 */
	public PredictionAssessmentTool() {
		super();
	}

	/**
	 * Inits the tool on the given Step.
	 */
	@Override
	public void init(GModel m, Step s) {

		try {
			refStep = s;
			refProject = s.getProject();

			initScene = (HetScene) refStep.getProject().getRoot().getScene();
			refScene = (HetScene) refStep.getScene();

			date1 = initScene.getDate();
			date2 = refScene.getDate();

			setTitle(getName () + " - " + refStep.getCaption());

			createUI();

			printMessage(Translator.swap("PredictionAssessmentTool.pleaseLoadAnObservationFile") + "...");

			setSize(INITIAL_WIDTH, INITIAL_HEIGHT);
			setModal(false);
			setVisible(true);

		} catch (Exception e) {
			Log.println(Log.ERROR, "PredictionAssessmentTool.c ()", "Exception in init ()", e);
		}

	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("PredictionAssessmentTool.name");
	}

	@Override
	public String getAuthor() {
		return "M. Jonard, F. de Coligny";
	}

	@Override
	public String getDescription() {
		return Translator.swap("PredictionAssessmentTool.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Action on browse, returns a file name or null if user cancelled.
	 */
	private String getExternalFileName() {
		JFileChooser chooser = new JFileChooser(
				Settings.getProperty("heterofor.predictionAssessmentToll.path", PathManager.getDir("data")));

		int returnVal = chooser.showOpenDialog(this);

		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String fileName = chooser.getSelectedFile().toString();
			Settings.setProperty("heterofor.predictionAssessmentToll.path", fileName);
			return fileName;
		}

		return null; // user cancelled
	}

	private void printMessage(final String message) {
		final JLabel st = status;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				st.setText(message);
				st.revalidate();
				st.repaint();
			}
		});
	}

	/**
	 * Load the observation file, check its date, must be equal to date2.
	 */
	public void browseAction() {

		if (observationIsLoaded) {
			boolean yep = Question.ask(this, Translator.swap("PredictionAssessmentTool.confirm"),
					Translator.swap("PredictionAssessmentTool.doYouWantToLoadANewObservationFile"));
			if (!yep)
				return;
		}

		String obsFileName = getExternalFileName();
		if (obsFileName == null)
			return; // user cancelled

		observationFileName.setText(obsFileName);

		launchChartTask(obsFileName);

	}

	/**
	 * We consider only the trees in innerZone
	 */
	protected void prepareInnerZone (HetScene scene) throws Exception{

		double x0 = scene.getOrigin().x;
		double y0 = scene.getOrigin().y;
		double w = scene.getXSize();
		double h = scene.getYSize();

		innerZone = new Rectangle.Double (x0 + bufferWidth, y0 + bufferWidth, w - 2 * bufferWidth, h - 2 * bufferWidth);

		System.out.println("PredictionAssessmentTool innerZone: "+innerZone);

	}

	public Rectangle.Double getInnerZone() {
		return innerZone;
	}

	public double getBufferWidth() {
		return bufferWidth;
	}

	private void launchChartTask(final String obsFileName) {

		printMessage(Translator.swap("PredictionAssessmentTool.loadingObservationFile") + "...");

		class ChartWorker extends SwingWorker<Object, Object> {

			private PredictionAssessmentTool pat;

			public ChartWorker(PredictionAssessmentTool pat) {
				super ();
				this.pat = pat;
			}

			@Override
			public Object doInBackground() {

				try {
					C4Script s = createObsProject(obsFileName);

					obsScene = (HetScene) s.getRoot().getScene();

					try {
						// fc+mj: rely on initScene, obsScene may be bigger
						pat.prepareInnerZone (initScene);
					} catch (Exception e) {
						throw new Exception ("Could not create innerZone, please check bufferWidth value ("+bufferWidth+")");
					}

					s.closeProject();

					int obsDate = obsScene.getDate();
					if (obsDate != date2)
						throw new Exception("Wrong date in observation file: " + obsDate + ", should be: " + date2);

					observationIsLoaded = true;
					System.out.println("PredictionAssessmentTool: observation file correctly loaded");

				} catch (Exception e) {
					Log.println(Log.ERROR, "PredictionAssessmentTool.browseAction ()",
							"Trouble while loading the observation file: " + obsFileName, e);
					MessageDialog.print(this,
							Translator.swap("PredictionAssessmentTool.TroubleWhileLoadingTheObservationFileSeeLog")
									+ "\n" + obsFileName + "\n-> " + e.getMessage(),
							e);
					printMessage("");
					return null;
				}

				printMessage(Translator.swap("PredictionAssessmentTool.preparingCharts") + "...");
				return printCharts(pat);
			}

			@Override
			protected void done() {
				try {
					// If error, return
					if (get() == null) {
						printMessage("");
						return;
					}

					LinePanel chartLine = (LinePanel) get();

					scroll.getViewport().setView(chartLine);

					scroll.revalidate();
					scroll.repaint();

					printMessage("");

				} catch (Exception e) {
					Log.println(Log.ERROR, "PredictionAssessmentTool.launchChartTask ()", "Could not print the charts",
							e);
					printMessage(Translator.swap("PredictionAssessmentTool.anErrorOccurred"));
				}
			}
		}

		new ChartWorker(this).execute();

	}

	/**
	 * This long method is called in a separated thread to let the gui
	 * responsive.
	 *
	 * @return a line with all the charts inside.
	 */
	private LinePanel printCharts(PredictionAssessmentTool pat) {
		LinePanel chartLine = new LinePanel();

		HetInitialParameters ip = (HetInitialParameters) initScene.getStep().getProject().getModel().getSettings();

		// meanPredictedAndObservedGirthIncrement histo
		chartLine.add(new HistoSpecies(pat,
				Translator.swap("meanPredictedAndObservedGirthIncrement.title"),
				Translator.swap("meanGirthIncrement"), initScene, refScene, obsScene) {
			protected double getYValue(HetTree tree) {
				return tree.getGirth(); // cm
			}
		});

		// meanPredictedAndObservedBasalAreaIncrement histo
		chartLine.add(new HistoSpecies(pat, Translator.swap("meanPredictedAndObservedBasalAreaIncrement.title"),
				Translator.swap("meanBasalAreaIncrement"), initScene, refScene, obsScene) {
			protected double getYValue(HetTree tree) {
				return tree.getBasalArea() * 10000; // cm2
			}
		});

		// meanPredictedAndObservedMeanHeightIncrement histo
		chartLine.add(new HistoSpecies(pat, Translator.swap("meanPredictedAndObservedMeanHeightIncrement.title"),
				Translator.swap("meanMeanHeightIncrement"), initScene, refScene, obsScene) {
			protected double getYValue(HetTree tree) {
				return tree.getHeight(); // m
			}
		});

		// meanPredictedAndObservedHcbtIncrement histo
		chartLine.add(new HistoSpecies(pat, Translator.swap("meanPredictedAndObservedHcbtIncrement.title"),
				Translator.swap("meanMeanHcbIncrement"), initScene, refScene, obsScene) {
			protected double getYValue(HetTree tree) {
				return tree.getHcb(); // m
			}
		});

		// meanPredictedAndObservedHlcetIncrement histo
		chartLine.add(new HistoSpecies(pat, Translator.swap("meanPredictedAndObservedHlcetIncrement.title"),
				Translator.swap("meanMeanHlceIncrement"), initScene, refScene, obsScene) {
			protected double getYValue(HetTree tree) {
				return tree.getHlce(); // m
			}
		});

		// meanPredictedAndObservedCrownRadiusIncrement histo
		chartLine.add(new HistoSpecies(pat, Translator.swap("meanPredictedAndObservedCrownRadiusIncrement.title"),
				Translator.swap("meanMeanCrownRadiusIncrement"), initScene, refScene, obsScene) {
			protected double getYValue(HetTree tree) {
				return tree.getCrownRadius(); // m
			}
		});

		// initialHeightVsdeltaHeight
		chartLine.add(new XYPlot(pat, Translator.swap("initialHeightVsdeltaHeight.title"), initScene, refScene, obsScene,
				Translator.swap("initialHeight"), Translator.swap("deltaHeight")) {
			protected double getXValue(HetTree tree) {
				return tree.getHeight(); // m
			}

			protected double getYValue(HetTree tree) {
				return tree.getHeight(); // m
			}

			protected int getSpeciesCode() {
				return -1; // all species
			}
		});

		for (int spCode : ip.speciesMap.keySet()) {
			final int speciesCode = spCode;

			chartLine.add(new XYPlot(pat, Translator.swap("initialHeightVsdeltaHeight.title"), initScene, refScene, obsScene,
					Translator.swap("initialHeight"), Translator.swap("deltaHeight")) {
				protected double getXValue(HetTree tree) {
					return tree.getHeight(); // m
				}

				protected double getYValue(HetTree tree) {
					return tree.getHeight(); // m
				}

				protected int getSpeciesCode() {
					return speciesCode; // a given species
				}
			});

		}

		// initialGirthVsdeltaG
		chartLine.add(new XYPlot(pat, Translator.swap("initialGirthVsdeltaG.title"), initScene, refScene, obsScene,
				Translator.swap("initialGirth"), Translator.swap("deltaG")) {
			protected double getXValue(HetTree tree) {
				return tree.getGirth(); // cm
			}

			protected double getYValue(HetTree tree) {
				return tree.getBasalArea() * 10000; // cm2
			}

			protected int getSpeciesCode() {
				return -1; // all species
			}
		});

		for (int spCode : ip.speciesMap.keySet()) {
			final int speciesCode = spCode;

			chartLine.add(new XYPlot(pat, Translator.swap("initialGirthVsdeltaG.title"), initScene, refScene, obsScene,
					Translator.swap("initialGirth"), Translator.swap("deltaG")) {
				protected double getXValue(HetTree tree) {
					return tree.getGirth(); // cm
				}

				protected double getYValue(HetTree tree) {
					return tree.getBasalArea() * 10000; // cm2
				}

				protected int getSpeciesCode() {
					return speciesCode; // a given species
				}
			});

		}

		// Average girth increase. A value per (species, girth class) pair: it is the mean of the girth increases
		// of the trees which belong to the given girth class for the given species.
		chartLine.add(new PVOClassInc(pat, Translator.swap("PVOClassIncGirth.title"), initScene, refScene, obsScene, false,
				Translator.swap("PVOClassIncGirth.meanOfObservedValues"), Translator.swap("PVOClassIncGirth.meanOfSimulatedValues"),
				Translator.swap("PVOClassIncGirth.standardErrorOfObservedValues"), Translator.swap("PVOClassIncGirth.standardErrorOfSimulatedValues")) {

			protected double getValue(HetTree tree) {
				return tree.getGirth(); // unit: cm
			}
		});

		// Average basal area increase. A value per (species, girth class) pair: it is the mean of the basal area increases
		// of the trees which belong to the given girth class for the given species.
		chartLine.add(new PVOClassInc(pat, Translator.swap("PVOClassIncBasalArea.title"), initScene, refScene, obsScene, false,
				Translator.swap("PVOClassIncBasalArea.meanOfObservedValues"), Translator.swap("PVOClassIncBasalArea.meanOfSimulatedValues"),
				Translator.swap("PVOClassIncBasalArea.standardErrorOfObservedValues"), Translator.swap("PVOClassIncBasalArea.standardErrorOfSimulatedValues")) {

			protected double getValue(HetTree tree) {
				return tree.getBasalArea()*1e4; // unit: cm2
			}
		});

		// Average height increase. A value per (species, girth class) pair: it is the mean of the height increases
		// of the trees which belong to the given girth class for the given species.
		chartLine.add(new PVOClassInc(pat, Translator.swap("PVOClassIncHeight.title"), initScene, refScene, obsScene, false,
				Translator.swap("PVOClassIncHeight.meanOfObservedValues"), Translator.swap("PVOClassIncHeight.meanOfSimulatedValues"),
				Translator.swap("PVOClassIncHeight.standardErrorOfObservedValues"), Translator.swap("PVOClassIncHeight.standardErrorOfSimulatedValues")) {

			protected double getValue(HetTree tree) {
				return tree.getHeight(); // unit: m
			}
		});

		// PVOIncGirth, etc.
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncGirth.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return tree.getGirth();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncGirth.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return tree.getGirth();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncHeight.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return tree.getHeight();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncHeight.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return tree.getHeight();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncHlce.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getHlce()) : tree.getHlce();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncHlce.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getHlce()) : tree.getHlce();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncHcb.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getHcb()) : tree.getHcb();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncHcb.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getHcb()) : tree.getHcb();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncRnorth.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getRnorth()) : tree.getRnorth();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncRnorth.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getRnorth()) : tree.getRnorth();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncReast.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getReast()) : tree.getReast();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncReast.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getReast()) : tree.getReast();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncRsouth.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getRsouth()) : tree.getRsouth();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncRsouth.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getRsouth()) : tree.getRsouth();
			}
		});

		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncRwest.title"), initScene, refScene, obsScene, false) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getRwest()) : tree.getRwest();
			}
		});
		chartLine.add(new PVOInc(pat, Translator.swap("PVOIncRwest.title"), initScene, refScene, obsScene, true) {
			protected double getValue(HetTree tree) {
				return logMode ? Math.log10(tree.getRwest()) : tree.getRwest();
			}
		});

		return chartLine;

	}

	private C4Script createObsProject(String obsFileName) throws Exception {
		// Load the file in a script / new project
		// to avoid any interferences with the simulated project
		C4Script s = new C4Script("heterofor");

		// Find the species and samsara file names used in the simulation
		HetInitialParameters ip0 = (HetInitialParameters) refProject.getModel().getSettings();

		// fc+mj-12.9.2017 Better copy of HetInitialParameters

		// 1. Make a copy of ip
		HetInitialParameters ip1 = new HetInitialParameters(ip0);

		// 2. Change inventory file
		ip1.inventoryFileName = obsFileName;

//		String refSpeciesFileName = ip0.speciesFileName;
//		String refSamsaraLightFileName = ip0.samsaraLightFileName;
//
//		// fc-26.11.2013 changed the inventory file name to use the new nov
//		// 2013 file format
//		HetInitialParameters ip1 = new HetInitialParameters(refSpeciesFileName, obsFileName, refSamsaraLightFileName);
//
//		// Copy all the information the user may have changed at init time on the HetInitialDialog
//		ip1.soilChemistryFileName = ip0.soilChemistryFileName;
//		ip1.radiationCalculationTimeStep = ip0.radiationCalculationTimeStep; // This was formerly forgotten
//		ip1.constantNppToGppRatio = ip0.constantNppToGppRatio;
//		ip1.competitionAccountedForCrownGrowth = ip0.competitionAccountedForCrownGrowth;
//		ip1.heightGrowthOption = ip0.heightGrowthOption;
//
//		// fc-2.5.2017 was missing
//		ip1.castaneaPhotosynthesisActivated = ip0.castaneaPhotosynthesisActivated;
//
//		// fc+mj+fa-29.6.2017
//		ip1.meteorologyFileName = ip0.meteorologyFileName;
//		ip1.soilHorizonsFileName = ip0.soilHorizonsFileName;
//		ip1.castaneaFileName = ip0.castaneaFileName;

		s.init(ip1);

		return s;
	}

	/**
	 * ActionListener interface. Buttons management.
	 */
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource().equals(close)) {
			escapePressed();

		} else if (evt.getSource().equals(browse)) {
			browseAction();

		} else if (evt.getSource().equals(help)) {
			Helper.helpFor(this);
		}
	}

	/**
	 * Called on Escape. Redefinition of method in AmapDialog : ask for user
	 * confirmation.
	 */
	protected void escapePressed() {
		if (Question.ask(MainFrame.getInstance(), Translator.swap("PredictionAssessmentTool.confirm"),
				Translator.swap("PredictionAssessmentTool.confirmClose"))) {
			dispose();
		}
	}

	/**
	 * User interface definition
	 */
	private void createUI() {

		//
		ColumnPanel top = new ColumnPanel();

		LinePanel l1 = new LinePanel(
				Translator.swap("PredictionAssessmentTool.observationFileForDate") + " : " + date2);
		l1.add(new JLabel(Translator.swap("PredictionAssessmentTool.observationFileName") + " : "));
		observationFileName = new JTextField();
		l1.add(observationFileName);
		browse = new JButton(Translator.swap("Shared.browse"));
		browse.addActionListener(this);
		l1.add(browse);
		l1.addStrut0();
		top.add(l1);

		scroll = new JScrollPane();
		getContentPane().add(scroll, BorderLayout.CENTER);

		// Control panel at the bottom: Close / Help
		controlPanel = new LinePanel();
		controlPanel.addStrut0();

		// fc-4.5.2015 add a status to talk to user
		status = new JLabel();
		controlPanel.add(status);
		controlPanel.addGlue();

		close = new JButton(Translator.swap("Shared.close"));
		close.addActionListener(this);
		help = new JButton(Translator.swap("Shared.help"));
		help.addActionListener(this);
		controlPanel.add(close);
		controlPanel.add(help);
		controlPanel.addStrut0();

		setDefaultButton(close);

		// // layout parts
		// JSplitPane mainPanel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		// mainPanel.setLeftComponent(part1);
		// mainPanel.setRightComponent(part2);
		// mainPanel.setOneTouchExpandable(true);
		// mainPanel.setDividerLocation(INITIAL_WIDTH / 2);

		getContentPane().add(top, BorderLayout.NORTH);
		getContentPane().add(controlPanel, BorderLayout.SOUTH);
	}

}
