/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.extension.modeltool.predictionassessmenttool;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.Translator;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public abstract class PVOInc extends PredVsObsIncrement {

	/**
	 * Constructor with or without logMode.
	 */
	public PVOInc(PredictionAssessmentTool pat, String title, HetScene initScene, HetScene refScene, HetScene obsScene, boolean logMode) {
		super(pat, title, initScene, refScene, obsScene, Translator.swap("PVOI.predictions"), Translator.swap("PVOI.measurements"), logMode);
	}

	/**
	 * Create the data set to be plot, called by superclass. This method is
	 * responsible for creating a dataSet with at least one dataSeries and
	 * setting min and maxValues;
	 */
	protected XYDataset createDataSet(HetScene initScene, HetScene refScene, HetScene obsScene) {
		HetInitialParameters ip = (HetInitialParameters) initScene.getStep().getProject().getModel().getSettings();

		XYSeriesCollection dataSet = new XYSeriesCollection();

		// Map: one series per species (key = species value)
		Map<Integer, XYSeries> seriesMap = new HashMap<Integer, XYSeries>();
		List<Integer> list = new ArrayList<Integer>(ip.speciesMap.keySet());
		Collections.sort(list);
		for (int i : list) {
			HetSpecies sp = ip.speciesMap.get(i);
			XYSeries series = new XYSeries(sp.niceName);
			seriesColors.add(sp.color);
			dataSet.addSeries(series);
			seriesMap.put(i, series);
		}

		int period = refScene.getDate() - initScene.getDate();

		// Enrich chart title
		String logLabel = logMode ? "Log10 " : "";
		title = logLabel + title + "\n" + ip.plotName + " " + initScene.getDate() + "-" + refScene.getDate();

		minValue = Double.MAX_VALUE;
		maxValue = -Double.MAX_VALUE;

		for (Object o : initScene.getTrees()) {

			HetTree initTree = (HetTree) o;
			if (initTree.isVirtual())
				continue;

			int treeId = initTree.getId();

			HetTree refTree = (HetTree) refScene.getTree(treeId);
			HetTree obsTree = (HetTree) obsScene.getTree(treeId);

			if (refTree == null || obsTree == null)
				continue;

			// fc+mj-10.5.2016
			if (!pat.getInnerZone().contains(initTree.getX(), initTree.getY()))
				continue;

			double initV = getValue(initTree);
			double refV = getValue(refTree);
			double obsV = getValue(obsTree);

			double x = (refV - initV) / period;
			double y = (obsV - initV) / period;

			double mx = x;
			double my = y;
			try {
				if (logMode) {
					x = Math.log10(x);
					y = Math.log10(y);
				}
				if (Double.isNaN(x) || Double.isNaN(y) || Double.isInfinite(x) || Double.isInfinite(y))
					throw new Exception("Log10 of Negative value, ignored");
			} catch (Exception e) {
//				System.out.println("PVOInc logMode exception: mx: " + mx + " my: " + my + " : " + e);
//				e.printStackTrace(System.out);
				// in case of log10(negative number), ignore the point
				continue;
			}

			minValue = Math.min(minValue, x);
			minValue = Math.min(minValue, y);
			maxValue = Math.max(maxValue, x);
			maxValue = Math.max(maxValue, y);

			// if (y < 0 || y > 3) {
			// System.out.println("Trouble: treeId: " + treeId + " iniV: " +
			// initV + " refV: " + refV + " obsV: "
			// + obsV + " period: " + period);
			// }

			XYSeries series = seriesMap.get(initTree.getSpecies().getValue());
			series.add(x, y);
		}

		System.out.println("PVOInc minValue: " + minValue + " maxValue: " + maxValue);

		return dataSet;
	}

	abstract protected double getValue(HetTree tree);

	// protected double getValue(HetTree tree) {
	// return logMode ? Math.log10(tree.getGirth()) : tree.getGirth();
	// }

}
