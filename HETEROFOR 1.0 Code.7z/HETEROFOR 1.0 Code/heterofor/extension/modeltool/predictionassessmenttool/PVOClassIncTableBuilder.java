/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.predictionassessmenttool;

import heterofor.model.HetSpecies;

import java.util.Map;

import jeeb.lib.util.Classifier;
import jeeb.lib.util.Translator;

/**
 * This class allows to build a table containing the data stored in the {@link PVOClassInc#dataSetMap} map.
 *
 * @author N. Beudez - November 2017
 */
public class PVOClassIncTableBuilder {

	static {
		Translator.addBundle("heterofor.extension.modeltool.predictionassessmenttool.PredictionAssessmentTool");
	}

	private final String separator = "\t";
	private final String newLine = "\n";

	/**
	 * Number of lines of the dataMatrix 2-dimensional array.
	 */
	private int numberOfLines;

	/**
	 * Number of columns of the dataMatrix 2-dimensional array.
	 */
	private int numberOfColumns;

	/**
	 * Columns names (header of the table).
	 */
	private String columnsNames[];

	/**
	 * 2-dimensional array containing the data of the {@link PVOClassInc#dataSetMap} map.
	 */
	private String dataMatrix[][];

	/**
	 * Builds the table composed of the {@link #columnsNames} array (header of the table) and the
	 * {@link #dataMatrix} 2-dimensional array (the data of the table).
	 *
	 * @param dataSetMap The map containg the data.
	 * @param classifier The classifier that has generated the girth classes.
	 * @param speciesMap The map with key: species id, value: species name.
	 * @param titleOfObservedMeanColumn The title used in the floating table for the column containing the means of observed values.
	 * @param titleOfSimulatedMeanColumn The title used in the floating table for the column containing the means of simulated values.
	 * @param titleOfObservedStandardErrorColumn The title used in the floating table for the column containing the standard errors on
	 * the observed values.
	 * @param titleOfSimulatedStandardErrorColumn The title used in the floating table for the column containing the standard errors on
	 * the simulated values.
	 * @throws Exception
	 */
	public PVOClassIncTableBuilder(Map<Integer, Map<Integer, PVOClassIncStore>> dataSetMap, Classifier classifier,
			Map<Integer, HetSpecies> speciesMap, String titleOfObservedMeanColumn, String titleOfSimulatedMeanColumn,
			String titleOfObservedStandardErrorColumn, String titleOfSimulatedStandardErrorColumn) throws Exception {

		// Number of species.
		int numberOfSpecies = dataSetMap.keySet().size();

		// Number of girth classes.
		int numberOfClasses = classifier.getN();

		// Defines the number of lines.
		numberOfLines = numberOfSpecies*numberOfClasses;

		// Defines the number of columns.
		// Column 1: species name
		// Column 2: girth class of initial trees
		// Column 3: average observed value
		// Column 4: average simulated value
		// Column 5: observed standard error
		// Column 6: simulated standard error
		// Column 7: number of trees in the girth class
		numberOfColumns = 7;

		// Creates arrays.
		columnsNames = new String[numberOfColumns];
		dataMatrix = new String[numberOfLines][numberOfColumns];

		// Fills in the columns names.
		columnsNames[0] = Translator.swap("PVOClassIncTableBuilder.species");
		columnsNames[1] = Translator.swap("PVOClassIncTableBuilder.girthClassOfInitialTrees");
		columnsNames[2] = titleOfObservedMeanColumn;
		columnsNames[3] = titleOfSimulatedMeanColumn;
		columnsNames[4] = titleOfObservedStandardErrorColumn;
		columnsNames[5] = titleOfSimulatedStandardErrorColumn;
		columnsNames[6] = Translator.swap("PVOClassIncTableBuilder.numberOfTrees");

		// Array containing the lower bounds of the girth classes.
		double lowerBounds[] = classifier.getMins();

		// Array containing the upper bounds of the girth classes.
		double upperBounds[] = classifier.getMaxs();

		// String representation of the classes.
		String classRepresentation[] = new String[numberOfClasses];
		for (int i=0 ; i<numberOfClasses ; ++i) {
			classRepresentation[i] = "[" + lowerBounds[i] + ", " + upperBounds[i] + "[";
		}

		// Fills in the dataMatrix 2-dimensional array.

		int seriesCpt = 0;

		for (int speciesId : dataSetMap.keySet()) {

			String speciesName = speciesMap.get(speciesId).niceName;

			for (int i=0 ; i<numberOfClasses ; ++i) {

				// Species name.
				dataMatrix[seriesCpt*numberOfClasses+i][0] = speciesName;

				// Girth class.
				dataMatrix[seriesCpt*numberOfClasses+i][1] = classRepresentation[i];

				Map<Integer, PVOClassIncStore> girthClassIdStoreMap = dataSetMap.get(speciesId);
				PVOClassIncStore store = girthClassIdStoreMap.get(i);

				int numberOfTrees = store.getNumberOfElements();

				// Average observed increases.
				if (numberOfTrees > 0) {
					dataMatrix[seriesCpt*numberOfClasses+i][2] = Double.toString(store.getMeanOfObservedValues());
				} else {
					dataMatrix[seriesCpt*numberOfClasses+i][2] = "NA";
				}

				// Average simulated increases.
				if (numberOfTrees > 0) {
					dataMatrix[seriesCpt*numberOfClasses+i][3] = Double.toString(store.getMeanOfSimulatedValues());
				} else {
					dataMatrix[seriesCpt*numberOfClasses+i][3] = "NA";
				}

				// Observed standard error.
				if (numberOfTrees > 0) {
					dataMatrix[seriesCpt*numberOfClasses+i][4] = Double.toString(store.getStandardErrorOfObservedValues());
				} else {
					dataMatrix[seriesCpt*numberOfClasses+i][4] = "NA";
				}

				// Simulated standard error.
				if (numberOfTrees > 0) {
					dataMatrix[seriesCpt*numberOfClasses+i][5] = Double.toString(store.getStandardErrorOfSimulatedValues());
				} else {
					dataMatrix[seriesCpt*numberOfClasses+i][5] = "NA";
				}

				// Number of trees in girth class used for making calculations.
				dataMatrix[seriesCpt*numberOfClasses+i][6] = Double.toString(numberOfTrees);
			}

			++seriesCpt;
		}
	}

	/**
	 * Returns the whole table in a single string, with tabs between columns and
	 * newline at each end of line.
	 */
	public String getTableInAString() {

		StringBuffer buffer = new StringBuffer();

		// Column headers.
		for (int j=0 ; j<columnsNames.length ; ++j) {

			buffer.append(columnsNames[j]);
			buffer.append(separator);
		}

		buffer.append(newLine);

		// Matrix content.
		for (int i=0 ; i<dataMatrix.length ; ++i) {

			for (int j=0 ; j<dataMatrix[i].length ; ++j) {

				// str can contains the "NA" string, see PVOClassInc.createDataSet().
				String str = dataMatrix[i][j];

				buffer.append(str);
				buffer.append(separator);
			}

			buffer.append(newLine);
		}

		return buffer.toString();
	}

	/**
	 * Returns the columns separator used for building the table.
	 *
	 * @return The columns separator of the built table.
	 */
	public String getSeparator() {

		return separator;
	}
}
