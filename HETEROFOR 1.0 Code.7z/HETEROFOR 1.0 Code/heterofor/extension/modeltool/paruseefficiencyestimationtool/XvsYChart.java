/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.paruseefficiencyestimationtool;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import jeeb.lib.util.IconLoader;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import jeeb.lib.util.csvfileviewer.CsvFileViewer;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;

import capsis.extension.datarenderer.drcurves.DRTableBuilder;
import capsis.gui.MainFrame;

/**
 * A chart tool
 *
 * @author M. Jonard - March 2016
 */
public class XvsYChart extends JPanel implements ActionListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.predictionassessmenttool.PredictionAssessmentTool");
		IconLoader.addPath("jeeb/lib/util/image");
	}

	protected String title;

	private XYDataset dataSet;

	protected String xLabel;
	protected String yLabel;

//	// These three variables are set in createDataSet ()
//	protected double minValue;
//	protected double maxValue;

	protected List<Color> seriesColors;

	private ChartPanel chartPanel;
	private boolean xAxisTickInteger = false;

	private JMenuItem openInTable; // fc-30.10.2015
	private XYDataset memoDataset;

	/**
	 * Constructor
	 */
	public XvsYChart(String title, XYDataset dataSet, List<Color> seriesColors, String xLabel, String yLabel) {

		System.out.println("XvsYChart: createXYChart ()... title: "+title);

		this.title = title;

		this.dataSet = dataSet;

		this.xLabel = xLabel;
		this.yLabel = yLabel;

		this.seriesColors = seriesColors;

		createUI();

		memoDataset = dataSet; // for csvViewer

		createXYChart();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(openInTable)) {
			// ... CsvFileViewer
			openCsvViewer();

		}
	}

	/**
	 * Open CsvViewer.
	 */
	private void openCsvViewer() {

		try {

			DRTableBuilder builder = new DRTableBuilder(memoDataset);

			Window window = MainFrame.getInstance();
			String name = title;
			String tableContent = builder.getTableInAString();
			String separator = "\t";

			new CsvFileViewer(window, name, tableContent, separator, Color.BLUE);

		} catch (Exception e) {
			Log.println(Log.WARNING, "PredVsObsIncrement.openCsvViewer()", "Could not open CsvFileViewer", e);
		}

	}


	private void createUI() {
		this.setLayout(new BorderLayout());
	}

	private void createXYChart() {
		if (dataSet != null) {

			System.out.println("XvsYChart: createXYChart ()... #series: "+dataSet.getSeriesCount());

			if (chartPanel != null)
				this.remove(chartPanel);

			NumberAxis xAxis = new NumberAxis();
			xAxis.setAutoRangeIncludesZero(false);
//			if (minValue < maxValue)
//				xAxis.setRange(minValue, maxValue);
			xAxis.setLabel(xLabel);

			NumberAxis yAxis = new NumberAxis();
			yAxis.setAutoRangeIncludesZero(false);
//			if (minValue < maxValue)
//				yAxis.setRange(minValue, maxValue);
			yAxis.setLabel(yLabel);

			// Extracted this line from the block below, fc-28.4.2015
			XYLineAndShapeRenderer xylineandshaperenderer = new XYLineAndShapeRenderer(false, true);

			// We create the charts with the factory
			PlotOrientation orientation = PlotOrientation.VERTICAL;
			boolean legend = true;
			boolean tooltips = true;
			boolean urls = false;

			// Use a simple theme fc+mj-30.10.2015
			StandardChartTheme theme = (StandardChartTheme) StandardChartTheme.createLegacyTheme();
			ChartFactory.setChartTheme(theme);

			JFreeChart chart = ChartFactory.createXYLineChart(title, xAxis.getLabel(), yAxis.getLabel(), dataSet,
					orientation, legend, tooltips, urls);

			// Set the custom renderer
			XYPlot plot = (XYPlot) chart.getPlot();
			plot.setRenderer(xylineandshaperenderer);

			// plot.setDomainAxis (1, xAxis);
			// plot.setRangeAxis (1, yAxis);

			// Theme customization fc+mj-30.10.2015
			chart.setBackgroundPaint(Color.WHITE);
			plot.setBackgroundPaint(Color.WHITE);

			// // Set the same background than the other components in the panel
			// chart.setBackgroundPaint(null); // Remove blank background ->
			// // default background for better
			// // integration

			// Change title size (set it a little smaller), see HistogramPanel
			chart.setTitle(new org.jfree.chart.title.TextTitle(title,
					new java.awt.Font("SansSerif", java.awt.Font.ITALIC, 14)));

			// Set the series colors
			int i = 0;
			for (Color c : seriesColors) {
				xylineandshaperenderer.setSeriesPaint(i++, c);
			}

//			// Add a line in the chart...
//			if (minValue < maxValue) {
//				XYSeriesCollection lineDataSet = new XYSeriesCollection();
//
//				XYSeries lineSeries = new XYSeries("1:1 line");
//				lineSeries.add(minValue, minValue);
//				lineSeries.add(maxValue, maxValue);
//				lineDataSet.addSeries(lineSeries);
//
//				int dataSetIndx = plot.getDatasetCount();
//				plot.setDataset(dataSetIndx, lineDataSet);
//
//				XYLineAndShapeRenderer lineRenderer = new XYLineAndShapeRenderer(true, false);
//				// Color for 1:1 line
//				lineRenderer.setSeriesPaint(0, Color.BLACK);
//
//				plot.setRenderer(dataSetIndx, lineRenderer);
//			}
//			// ...end-of-add a line in the chart

			chartPanel = new ChartPanel(chart, false);

			// Complete popupmenu fc-30.10.2015
			JPopupMenu m = chartPanel.getPopupMenu();
			m.addSeparator();
			openInTable = new JMenuItem(Translator.swap("DataRenderer.openInTable"));
			openInTable.setEnabled(true);
			openInTable.addActionListener(this);
			m.add(openInTable);

			this.add(chartPanel, BorderLayout.CENTER);

		}
		this.revalidate();
		this.updateUI();

	}

	public String getTitle() {
		return title;
	}

}
