/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool;

import heterofor.model.HetScene;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.meteorology.HetMeteorology.HetDate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import capsis.kernel.GModel;
import capsis.kernel.Step;

/**
 * Given a file containing hourly or daily observed water content values, this class contains methods allowing
 * to retrieve these values, store them in a map and check their compatibility with the simulation dates and
 * the list of soil's horizons.
 *
 * @author N. Beudez - October 2017
 */
public class HetSoilWaterAssessmentManager {

	// The name of the file containing the observed water content values
	private String observationsFileName;

	// The current step
	private Step step;

	// The model
	private GModel model;

	// Is true if observed water content values are hourly, false if they are daily
	private boolean hourlyData;

	// The smallest date in the observations file
	private String minObservedDate;

	// The biggest date in the observations file
	private String maxObservedDate;

	// List of the horizon ids contained in the observation file
	private List<Integer> observedHorizonIdList;

	// Map containing observed water content values.
	// key: "year_month_day_hour" (case of hourly observations) or "year_month_day" (case of daily observations)
	// value: map with key: horizon's id and value: observed water content
	private Map<String, Map<Integer, Double>> observedWaterContentMap;

	/**
	 * Constructor.
	 *
	 * @param observationsFileName The name of the file containing the observed water content values
	 * @param step The current step
	 * @param model The model
	 * @throws Exception
	 */
	public HetSoilWaterAssessmentManager(String observationsFileName, Step step, GModel model) throws Exception {

		this.observationsFileName = observationsFileName;
		this.step = step;
		this.model = model;

		minObservedDate = null;
		maxObservedDate = null;
		observedHorizonIdList = new ArrayList<Integer>();
		observedWaterContentMap = new HashMap<String, Map<Integer, Double>>();
	}

	/**
	 * Loads the file containing the values of observed hourly or daily water
	 * content and stores them in the {@link observedWaterContentMap} map. Sets
	 * the hourlyData boolean to true in the case of observed hourly water
	 * contents or to false in the case of observed daily water contents.
	 *
	 * @throws Exception
	 */
	public void loadObservedWaterContentValues() throws Exception {

		HetObservedHorizonsWaterContentFileLoader fileLoader = new HetObservedHorizonsWaterContentFileLoader();
		fileLoader.load(observationsFileName);

		// fc-6.12.2017 no more report in FileLoader

//		String loaderReport = fileLoader.load(observationsFileName);
//
//		if (!fileLoader.succeeded()) {
//			throw new Exception(loaderReport);
//		}

		if (fileLoader.horizonHourlyWaterContentList.isEmpty()
				&& fileLoader.horizonDailyWaterContentList.isEmpty()) {

			// Case 1: the observations file contains no hourly data and no daily data

			throw new Exception("Error: the observations file\n\n" + observationsFileName
					+ "\n\ncontains NO hourly water content value and NO daily water content value.\n\nAborted.");

		} else if (!fileLoader.horizonHourlyWaterContentList.isEmpty()
				&& !fileLoader.horizonDailyWaterContentList.isEmpty()) {

			// Case 2: the observations file contains both hourly data and daily data

			throw new Exception("Error: the observations file\n\n" + observationsFileName
					+ "\n\ncontains BOTH hourly water content values and daily water content values.\n"
					+ "The observations file must contain hourly OR (exclusively) daily water content values."
					+ "\n\nAborted.");

		} else if (!fileLoader.horizonHourlyWaterContentList.isEmpty()
				&& fileLoader.horizonDailyWaterContentList.isEmpty()) {

			// Case 3: the observations file contains only hourly observations

			hourlyData = true;

			for (int i=0 ; i<fileLoader.horizonHourlyWaterContentList.size() ; ++i) {

				int year = fileLoader.horizonHourlyWaterContentList.get(i).year;
				int month = fileLoader.horizonHourlyWaterContentList.get(i).month;
				int day = fileLoader.horizonHourlyWaterContentList.get(i).day;
				int hour = fileLoader.horizonHourlyWaterContentList.get(i).hour;

				String date = "" + year + HetMeteorology.SEP + month + HetMeteorology.SEP + day + HetMeteorology.SEP + hour;

				if (minObservedDate == null) {
					minObservedDate = date;
				}

				if (maxObservedDate == null) {
					maxObservedDate = date;
				}

				// date < minObservedDate
				if (HetDate.compare(date, minObservedDate, hourlyData) == -1) {
					minObservedDate = date;
				}

				// date > maxObservedDate
				if (HetDate.compare(date, maxObservedDate, hourlyData) == 1) {
					maxObservedDate = date;
				}

				int horizonId = fileLoader.horizonHourlyWaterContentList.get(i).horizonId;
				double waterContent = fileLoader.horizonHourlyWaterContentList.get(i).waterContent;

				// Fills in the list of observed horizons ids
				if (!observedHorizonIdList.contains(horizonId)) {
					observedHorizonIdList.add(horizonId);
				}

				// Fills in the observedWaterContentMap map
				if (!observedWaterContentMap.containsKey(date)) {
					Map<Integer, Double> horizonIdWaterContentMap = new HashMap<Integer, Double>();
					horizonIdWaterContentMap.put(horizonId, waterContent);
					observedWaterContentMap.put(date, horizonIdWaterContentMap);
				} else {
					observedWaterContentMap.get(date).put(horizonId, waterContent);
				}
			}

		} else {

			// Case 4: the observations file contains only daily observations.
			// It is the following case:
			// fileLoader.horizonHourlyWaterContentList is empty and
			// fileLoader.horizonDailyWaterContentList is not empty

			hourlyData = false;

			for (int i=0 ; i<fileLoader.horizonDailyWaterContentList.size() ; ++i) {

				int year = fileLoader.horizonDailyWaterContentList.get(i).year;
				int month = fileLoader.horizonDailyWaterContentList.get(i).month;
				int day = fileLoader.horizonDailyWaterContentList.get(i).day;

				String date = "" + year + HetMeteorology.SEP + month + HetMeteorology.SEP + day;

				if (minObservedDate == null) {
					minObservedDate = date;
				}

				if (maxObservedDate == null) {
					maxObservedDate = date;
				}

				// date < minObservedDate
				if (HetDate.compare(date, minObservedDate, hourlyData) == -1) {
					minObservedDate = date;
				}

				// date > maxObservedDate
				if (HetDate.compare(date, maxObservedDate, hourlyData) == 1) {
					maxObservedDate = date;
				}

				int horizonId = fileLoader.horizonDailyWaterContentList.get(i).horizonId;
				double waterContent = fileLoader.horizonDailyWaterContentList.get(i).waterContent;

				// Fills in the list of observed horizons ids
				if (!observedHorizonIdList.contains(horizonId)) {
					observedHorizonIdList.add(horizonId);
				}

				// Fills in the observedWaterContentMap map
				if (!observedWaterContentMap.containsKey(date)) {
					Map<Integer, Double> horizonIdWaterContentMap = new HashMap<Integer, Double>();
					horizonIdWaterContentMap.put(horizonId, waterContent);
					observedWaterContentMap.put(date, horizonIdWaterContentMap);
				} else {
					observedWaterContentMap.get(date).put(horizonId, waterContent);
				}
			}

		}
	}

	/**
	 * Checks if at least one date of the observations file is simulated until the current
	 * step (see {@link step}). It means that the intersection between the interval of
	 * observations dates and the interval of simulated dates until the current step
	 * (see {@link step}) must be non empty. If not, a message dialog box appears and the
	 * process is aborted.
	 *
	 * @throws Exception
	 */
	public void checkObservedDatesCompatibility() throws Exception {

		String minSimulatedDate = null;
		String maxSimulatedDate = null; // be careful: until current step (it can be lower than the
										// greatest date of the full simulation)

		// A check that current scene is not the initial scene has already been
		// done in the HetSoilWaterAssessmentTool.init() method.

		// Calculates minSimulatedDate: it is the first simulated date of the step following
		// the initial step (initial step is index 0 in the listOfSteps).
		// Example: if initial step is step with year 2001, the first simulated date is:
		// - "2002_1_1_0" in the case of hourly observed data ("year_month_day_hour" format)
		// - "2002_1_1" in the case of daily observed data ("year_month_day" format)

		Vector<Step> listOfSteps = model.getProject().getStepsFromRoot(step);

		if (hourlyData) { // hourly observed data
			minSimulatedDate = "" + String.valueOf(listOfSteps.get(1).getScene().getDate())
					+ HetMeteorology.SEP + "1" + HetMeteorology.SEP + "1" + HetMeteorology.SEP + "0";
		} else { // daily observed data
			minSimulatedDate = "" + String.valueOf(listOfSteps.get(1).getScene().getDate())
					+ HetMeteorology.SEP + "1" + HetMeteorology.SEP + "1";
		}

		// Calculates maxSimulatedDate (until current step)
		if (hourlyData) {
			maxSimulatedDate = "" + String.valueOf(step.getScene().getDate()) + HetMeteorology.SEP + "12"
					+ HetMeteorology.SEP + "31" + HetMeteorology.SEP + "23";
		} else {
			maxSimulatedDate = "" + String.valueOf(step.getScene().getDate()) + HetMeteorology.SEP + "12"
					+ HetMeteorology.SEP + "31";
		}

		// If maxObservedDate < minSimulatedDate or minObservedDate > maxSimulatedDate
		if ((HetDate.compare(maxObservedDate, minSimulatedDate, hourlyData) == -1)
				|| (HetDate.compare(minObservedDate, maxSimulatedDate, hourlyData) == 1)) {

			String errorMessage = "Impossible to compare simulated/observed data: no simulated "
					+ "date exists for the given observations dates.\n" + "Simulated interval time: ["
					+ minSimulatedDate + " , " + maxSimulatedDate + "]\n" + "Observed interval time: ["
					+ minObservedDate + " , " + maxObservedDate + "]" + "\n\nAborted.";

			throw new Exception(errorMessage);
		}

	}

	/**
	 * Checks the compatibility of the horizons ids contained in the observations
	 * file: they all must be included in the list of horizons ids of the
	 * simulated soil. If not, a message dialog box appears and the process is
	 * aborted.
	 *
	 * @throws Exception
	 */
	public void checkObservedHorizonIdListCompatibility() throws Exception {

		HetScene scene = (HetScene) step.getScene();
		Set<Integer> simulatedHorizonIdSet = scene.getSoil().getHorizonMap().keySet();

		for (int horizonId : observedHorizonIdList) {
			if (!simulatedHorizonIdSet.contains(horizonId)) {
				String errorMessage = "Error: horizon with id " + horizonId + " in file\n\n" + observationsFileName
						+ "\n\ndoes not match with any horizon of the simulated soil.\n\nAborted.";
				throw new Exception(errorMessage);
			}
		}
	}

	/**
	 * Returns true if observed data are hourly, false if they are daily.
	 */
	public boolean areHourlyData() {

		return hourlyData;
	}

	/**
	 * Returns the list of the horizon ids contained in the observation file
	 */
	public List<Integer> getObservedHorizonIdList() {

		return observedHorizonIdList;
	}

	/**
	 * Returns the map containing observed water content values.
	 * Key: "year_month_day_hour" (case of hourly observations) or "year_month_day"
	 * (case of daily observations)
	 * Value: map with key: horizon's id and value: observed water content
	 */
	public Map<String, Map<Integer, Double>> getObservedWaterContentMap() {

		return observedWaterContentMap;
	}
}
