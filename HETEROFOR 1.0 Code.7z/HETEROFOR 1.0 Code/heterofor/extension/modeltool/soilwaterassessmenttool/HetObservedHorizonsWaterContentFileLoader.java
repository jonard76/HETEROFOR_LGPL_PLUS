/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool;

import java.util.List;

import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A loader for a file containing hourly or daily water content records for different soil horizons.
 *
 * @author N. Beudez - October 2017
 */
public class HetObservedHorizonsWaterContentFileLoader extends FileLoader {

	public List<HorizonHourlyWaterContentRecord> horizonHourlyWaterContentList;
	public List<HorizonDailyWaterContentRecord> horizonDailyWaterContentList;

	/**
	 * A hourly water content record for an horizon.
	 *
	 * @author N. Beudez - September 2017
	 */
	static public class HorizonHourlyWaterContentRecord extends Record {

		public int horizonId;
		public int year;
		public int month;
		public int day;
		public int hour;
		public double waterContent;

		/**
		 * Constructor
		 */
		public HorizonHourlyWaterContentRecord(String line) throws Exception {

			super(line);
		}
	}

	/**
	 * A daily water content record for an horizon.
	 *
	 * @author N. Beudez - September 2017
	 */
	static public class HorizonDailyWaterContentRecord extends Record {

		public int horizonId;
		public int year;
		public int month;
		public int day;
		public double waterContent;

		/**
		 * Constructor
		 */
		public HorizonDailyWaterContentRecord(String line) throws Exception {

			super(line);
		}
	}

	/**
	 * Constructor
	 */
	public HetObservedHorizonsWaterContentFileLoader() throws Exception {
		super ();
	}


	@Override
	protected void checks() throws Exception {
		// TODO FP Auto-generated method stub

	}

}
