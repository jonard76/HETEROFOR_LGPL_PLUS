/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetElementState;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.GTreeIdComparator;
import capsis.util.StandRecordSet;

/**
 * HetNutrientStatusExport exports tree nutrient status.
 *
 * @author F. de Coligny, N. Beudez, M. Jonard - December 2016
 */
public class HetNutrientStatusExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetNutrientStatusExport");
	//static public String AUTHOR = "F. de Coligny, N. Beudez, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetNutrientStatusExport.description");

	public final static String TAB = "\t";

	private boolean wroteHeader;

	/**
	 * Constructor
	 */
	public HetNutrientStatusExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			return referent instanceof HetModel;

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetNutrientStatusExport.matchWith ()",
					"Error in matchWith () (returned false)", e);
			return false;
		}
	}

	@Override
	public String getName() {
		return Translator.swap("HetNutrientStatusExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, N. Beudez, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetNutrientStatusExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// For each step in the scenario from the root, write all trees
		Step step = scene.getStep();
		Project project = step.getProject();
		for (Step stp : project.getStepsFromRoot(step)) {

			if (!wroteHeader)
				writeHeader(stp);

			writeLines((HetScene) stp.getScene());

		}

	}

	private void writeHeader(Step step) throws Exception {

		if (wroteHeader)
			return;

		// 1. Custom headers
		add(new CommentRecord(
				"Heterofor Tree Nutrient Status Export (HetNutrientStatusExport) at "
						+ new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Trees"));

		StringBuffer h = new StringBuffer();
		h.append("date" + TAB + "id" + TAB + "speciesName" + TAB
				+ "livingStatus");

		for (String eName : HetTreeElement.elementNames) {
			h.append(TAB + eName + "[0,1]");
		}

		h.append(TAB + "fineRootToFoliageRatio" + TAB + "nppToGppRatio");

		add(new CommentRecord(h.toString()));

		wroteHeader = true;

	}

	private void writeLines(HetScene scene) {

		// Sort the trees on their ids
		Set sortedTrees = new TreeSet(new GTreeIdComparator());
		sortedTrees.addAll(scene.getTrees());

		// Alive trees
		for (Iterator i = sortedTrees.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			writeLine(scene, t, "alive");
		}

		// Cut trees
		Collection cutTrees = scene.getTrees("cut");
		if (cutTrees != null && !cutTrees.isEmpty()) {
			sortedTrees = new TreeSet(new GTreeIdComparator());
			sortedTrees.addAll(cutTrees);
			for (Iterator i = sortedTrees.iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();
				writeLine(scene, t, "cut");
			}
		}

	}

	// Write a line for the given tree
	private void writeLine(HetScene scene, HetTree t, String livingStatus) {

		// Write a line for the given tree
		StringBuffer l = new StringBuffer();

		l.append(scene.getDate());
		l.append(TAB + t.getId());
		l.append(TAB + t.getSpecies().getName());
		l.append(TAB + livingStatus);

		HetElementState nutrientStatus = t.getNutrientStatusMap();

		for (String eName : HetTreeElement.elementNames) {

			Double ns = nutrientStatus.getValue(eName);
			l.append(TAB + (ns == null ? "" : ns));

		}

		l.append(TAB + t.getFineRootToFoliageRatio());

		l.append(TAB + t.getNppToGppRatio());

		add(new FreeRecord(l.toString()));

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}