/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetWaterBalance;
import heterofor.model.soil.HetHorizon;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * Exports water balance at an hourly time step
 *
 * @author F. de Coligny, M. Jonard - March 2017
 */
public class HetWaterBalanceHourlyExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetWaterBalanceHourlyExport");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetWaterBalanceHourlyExport.description");

	// A line in the file
	@Import
	static public class Line extends Record {

		public Line() {
			super();
		}

		public Line(String line) throws Exception {
			super(line);
		}

		public int year;
		public int month;
		public int day;
		public int hour;

		public double rainfall; // mm
		public double stemflow; // mm
		public double throughfall; // mm
		public double interception; // mm
		public double transpiration; // mm

		// fc+mj-13.9.2017
		public double standLevel_transpiration; // mm
		public double treeLevel_transpiration; // mm
		public double groundVegetationTranspiration; // mm

		public double barkEvaporation; // mm // fc+mj+lw-19.10.2016
		public double foliageEvaporation; // mm // fc+mj+lw-19.10.2016
		public double vegetationEvaporation; // mm
		public double soilEvaporation; // mm
		public double deepDrainage; // mm

		public double relativeExtractableWater; // mm/mm
		public double forestFloorRelativeExtractableWater; // mm/mm
		public String horizonWaterContents; // separated by tabs, m3/m3
		public double waterContentStockVariation; // TODO: unit
		public double waterBalance; // TODO: unit
	}

	static private final String TAB = "\t";

	/**
	 * Constructor
	 */
	public HetWaterBalanceHourlyExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetExport.matchWith()", "Error in matchWith() (returned false)", e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetWaterBalanceHourlyExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetWaterBalanceHourlyExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: create a list of records. In script mode, save (fileName) must be
	 * called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		Set<Integer> horizonIdsSet = scene.getSoil().getHorizonMap().keySet();
		// Sort horizon ids on ascending order
		Set<Integer> sortedHorizonIds = new TreeSet<>(horizonIdsSet);

		// 1. Custom headers
		add(new CommentRecord("Heterofor Water Balance Hourly Export (HetExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Water Balance lines"));
		String columnNames = "year" + TAB + "month" + TAB + "day" + TAB + "hour" + TAB + "rainfall (mm)" + TAB
				+ "stemflow (mm)" + TAB + "throughfall (mm)" + TAB + "interception (mm)" + TAB + "transpiration (mm)" + TAB
				+ "standLevel_transpiration (mm)" + TAB + "treeLevel_transpiration (mm)"  + TAB + "groundVegetationTranspiration (mm)" + TAB
				+ "barkEvaporation (mm)" + TAB + "foliageEvaporation (mm)" + TAB + "vegetationEvaporation (mm)" + TAB
				+ "soilEvaporation (mm)" + TAB + "deepDrainage (mm)" + TAB + "relativeExtractableWater (mm.mm-1)" + TAB
				+ "forestFloorRelativeExtractableWater (mm.mm-1)";
		for (int horizonId : sortedHorizonIds) {
			columnNames += TAB + "horizonWaterContent (m3.m-3) for horizon " + horizonId + " - " + scene.getSoil().getHorizon(horizonId).name;
		}
		columnNames += TAB + "waterContentStockVariation (TODO: unit)" + TAB + "waterBalance (TODO: unit)";
		add(new CommentRecord(columnNames));

		// For each step in the scenario from the root, write all trees

		Step step = scene.getStep();
		Project project = step.getProject();

		// Map with key: horizon's id, value: water content at previous hour
		HashMap<Integer, Double> horizonIdPreviousWaterContentMap = new HashMap<Integer, Double>();

		for (Step st : project.getStepsFromRoot(step)) {

			HetScene sc = (HetScene) st.getScene();

			if (sc.isInitialScene()) {
				for (HetHorizon horizon : scene.getSoil().getHorizons()) {
					horizonIdPreviousWaterContentMap.put(horizon.id, horizon.meanWaterContent);
				}
			}

			// add (new EmptyRecord ());
			writeLines(sc, horizonIdPreviousWaterContentMap);
		}

	}

	/**
	 * Writes the water balance for all hours of the given scene which represents a year of simulation.
	 */
	private void writeLines(HetScene scene, HashMap<Integer, Double> horizonIdPreviousWaterContentMap) {

		System.out.println("writeLines() date: " + scene.getDate() + "  size: " + scene.waterBalanceMap.keySet().size());

		// Remark: waterBalanceMap for initial scene is empty so that the following for () loop is not entered for
		// the initial scene. nb-13.09.2017
		for (Iterator<String> i = scene.waterBalanceMap.keySet().iterator(); i.hasNext();) {

			String key = i.next();
			System.out.println("key: " + key);

			// wb contains water balance data for the current hour (key is year_month_day_hour)
			HetWaterBalance wb = scene.waterBalanceMap.get(key);

			Line line = new Line();

			line.year = wb.year;
			line.month = wb.month;
			line.day = wb.day;
			line.hour = wb.hour;

			System.out.println("year: " + wb.year);
			System.out.println("month: " + wb.month);
			System.out.println("day: " + wb.day);
			System.out.println("hour: " + wb.hour);

			//System.exit(1);

			line.rainfall = wb.rainfall;
			line.stemflow = wb.stemflow;
			line.throughfall = wb.throughfall;
			line.interception = wb.interception;
			line.transpiration = wb.transpiration;

			// fc+mj-13.9.2017
			line.standLevel_transpiration = wb.standLevel_transpiration;
			line.treeLevel_transpiration = wb.treeLevel_transpiration;
			line.groundVegetationTranspiration = wb.groundVegetationTranspiration;

			line.barkEvaporation = wb.barkEvaporation;
			line.foliageEvaporation = wb.foliageEvaporation;
			line.vegetationEvaporation = wb.vegetationEvaporation;
			line.soilEvaporation = wb.soilEvaporation;
			line.deepDrainage = wb.deepDrainage;

			line.relativeExtractableWater = wb.relativeExtractableWater;
			line.forestFloorRelativeExtractableWater = wb.forestFloorRelativeExtractableWater;

			// Last columns contains one value per jorizon, separated by tabs
			// (horizons number may vary)
			// Sort horizon ids on ascending order
			Set<Integer> sortedHIds = new TreeSet<>(wb.horizonWaterContent.keySet());
			StringBuffer b = new StringBuffer();
			for (Iterator<Integer> j = sortedHIds.iterator(); j.hasNext();) {

				int hId = j.next();
				double v = wb.horizonWaterContent.get(hId);

				b.append(v);

				if (j.hasNext())
					b.append(TAB);
			}

			line.horizonWaterContents = b.toString();

			// Calculate water balance. nb-13.09.2017
			double waterContentVariation = 0.0;

			for (int horizonId : sortedHIds) {

				HetHorizon horizon = scene.getSoil().getHorizon(horizonId);

				double waterContent = wb.horizonWaterContent.get(horizonId);
				double previousWaterContent = horizonIdPreviousWaterContentMap.get(horizonId);

				waterContentVariation += (waterContent-previousWaterContent)*horizon.thickness*(1.0-horizon.additionalCoarseFraction)*1000.0;

				// Updates the previous water content for next hour. nb-13.09.2017
				horizonIdPreviousWaterContentMap.put(horizonId, waterContent);
			}
			line.waterContentStockVariation = waterContentVariation;

//			line.waterBalance = line.rainfall - (line.transpiration + line.vegetationEvaporation
//					+ line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation);
			line.waterBalance = line.rainfall - (line.transpiration + line.interception
					+ line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation); // mj+fa-26.09.2017

			add(line);
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}
