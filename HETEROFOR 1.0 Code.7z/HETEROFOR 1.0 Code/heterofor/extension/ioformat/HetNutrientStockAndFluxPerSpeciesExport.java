/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;

import jeeb.lib.util.AdditionMap;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import capsis.defaulttype.Tree;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * HetNutrientStockAndFluxPerSpeciesExport exports nutrient stocks and fluxes
 * per species
 *
 * @author N. Beudez, F. de Coligny, M. Jonard - December 2016
 */
public class HetNutrientStockAndFluxPerSpeciesExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetNutrientStockAndFluxPerSpeciesExport");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetNutrientStockAndFluxPerSpeciesExport.description");

	public final static String TAB = "\t";

	private HetInitialParameters ip;

	private boolean wroteHeader;

	/**
	 * Constructor
	 */
	public HetNutrientStockAndFluxPerSpeciesExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			return referent instanceof HetModel;

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetNutrientStockAndFluxPerSpeciesExport.matchWith ()",
					"Error in matchWith () (returned false)", e);
			return false;
		}
	}

	@Override
	public String getName() {
		return Translator.swap("HetNutrientStockAndFluxPerSpeciesExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetNutrientStockAndFluxPerSpeciesExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// For each step in the scenario from the root, write a section
		Step step = scene.getStep();
		Project project = step.getProject();

		HetModel model = (HetModel) project.getModel();
		ip = model.getSettings();

		for (Step stp : project.getStepsFromRoot(step)) {

			if (!wroteHeader)
				writeHeader(stp);

			writeLines((HetScene) stp.getScene());

		}

	}

	private void writeHeader(Step step) throws Exception {

		if (wroteHeader)
			return;

		// 1. Custom headers
		add(new CommentRecord(
				"Heterofor Stand Nutrient Stock and Flux Export (HetNutrientStockAndFluxPerSpeciesExport) at "
						+ new Date()));
		add(new EmptyRecord());

		StringBuffer h = new StringBuffer();
		h.append("date" + TAB + "species name" + TAB + "type");

		for (String eName : HetTreeElement.elementNames) {
			h.append(TAB + eName);
		}

		add(new CommentRecord(h.toString()));

		wroteHeader = true;

	}

	private void writeLines(HetScene scene) {

		treeLines(scene);

	}

	private void treeLines(HetScene scene) {

		// Key is eName
		AdditionMap aboveGroundTreeStock_map = new AdditionMap();
		AdditionMap belowGroundTreeStock_map = new AdditionMap();
		AdditionMap currentDemand_map = new AdditionMap();
		AdditionMap deficientDemand_map = new AdditionMap();
		AdditionMap optimalDemand_map = new AdditionMap();
		AdditionMap potentialUptake_map = new AdditionMap();
		AdditionMap actualUptake_map = new AdditionMap();
		AdditionMap currentRetranslocation_map = new AdditionMap();
		AdditionMap currentRequirement_map = new AdditionMap();
		AdditionMap aboveGroundLitterProduction_map = new AdditionMap();
		AdditionMap belowGroundLitterProduction_map = new AdditionMap();

		AdditionMap nutrientRemoval_map = new AdditionMap();

		double area_ha = scene.getArea() / 10000d;

		ArrayList<String> speciesNameList = new ArrayList<String>();

		// Alive trees
		for (Iterator i = scene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			String speciesName = t.getSpecies().getName();

			if (!speciesNameList.contains(speciesName)) {
				speciesNameList.add(speciesName);
			}

			// Tree > treeCompartments > elements
			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				// String compartmentName = comp.name;

				for (String eName : HetTreeElement.elementNames) {

					String key = speciesName + "." + eName;

					if (comp.isAboveGround()) {

						try {
							double eStock = comp.getNutrientContent(eName) / area_ha; // kg/ha
							aboveGroundTreeStock_map.addValue(key, eStock);
						} catch (Exception e) {
						} // if exception, nothing added

					} else {

						try {
							double eStock = comp.getNutrientContent(eName) / area_ha; // kg/ha
							belowGroundTreeStock_map.addValue(key, eStock);
						} catch (Exception e) {
						} // if exception, nothing added

					}

				}

			}

			// Tree > litterCompartments > elements
			for (HetLitterCompartment comp : t.getLitterCompartments()) {
				// String compartmentName = comp.name;

				for (String eName : HetTreeElement.elementNames) {

					String key = speciesName + "." + eName;

					if (comp.isAboveGround()) {

						try {
							double aboveGroundLitterProduction = comp.getNutrientFlux(eName) / area_ha;
							aboveGroundLitterProduction_map.addValue(key, aboveGroundLitterProduction);
						} catch (Exception e) {
						} // if exception, nothing added

					} else {

						try {
							double belowGroundLitterProduction = comp.getNutrientFlux(eName) / area_ha;
							belowGroundLitterProduction_map.addValue(key, belowGroundLitterProduction);
						} catch (Exception e) {
						} // if exception, nothing added

					}

				}

			}

			// Tree > elements
			for (String eName : HetTreeElement.elementNames) {

				String key = speciesName + "." + eName;

				try {
					double retranslocation = t.getRetranslocation().getValue(eName) / 1000d / area_ha;// kg/ha
					currentRetranslocation_map.addValue(key, retranslocation);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double demand = t.getDemand().getValue(eName) / 1000d / area_ha; // kg/ha
					currentDemand_map.addValue(key, demand);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double deficientDemand = t.getDeficientDemand().getValue(eName) / 1000d / area_ha; // kg/ha
					deficientDemand_map.addValue(key, deficientDemand);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double optimalDemand = t.getOptimalDemand().getValue(eName) / 1000d / area_ha; // kg/ha
					optimalDemand_map.addValue(key, optimalDemand);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double potentialUptake = t.getPotentialUptake().getValue(eName) / 1000d / area_ha; // kg/ha
					potentialUptake_map.addValue(key, potentialUptake);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double actualUptake = t.getActualUptake().getValue(eName) / 1000d / area_ha; // kg/ha
					actualUptake_map.addValue(key, actualUptake);
				} catch (Exception e) {
				} // if exception, nothing added

			}

		}

		// Cut trees (if any)
		Collection<Tree> cutTrees = scene.getTrees("cut");
		for (Iterator i = cutTrees.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			String speciesName = t.getSpecies().getName();

			if (!speciesNameList.contains(speciesName)) {
				speciesNameList.add(speciesName);
			}

			// Tree > treeCompartments > elements
			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				// String compartmentName = comp.name;

				for (String eName : HetTreeElement.elementNames) {

					String key = speciesName + "." + eName;

					if (comp.isAboveGround()) {

						if (comp.diameter >= ip.cuttingDiameter) {

							try {
								double nutrientRemoval = comp.getNutrientContent(eName) / area_ha; // kg/ha
								nutrientRemoval_map.addValue(key, nutrientRemoval);
							} catch (Exception e) {
							} // if exception, nothing added

						}

					}

				}

			}

		}

		currentRequirement_map = AdditionMap.sum(currentDemand_map, currentRetranslocation_map);

		// Sort species names in alphabetical order
		Collections.sort(speciesNameList);

		// Loop on all the species
		for (String speciesName : speciesNameList) {

			writeLine(scene, speciesName, "aboveGroundTreeStock(kg/ha)", aboveGroundTreeStock_map);
			writeLine(scene, speciesName, "belowGroundTreeStock(kg/ha)", belowGroundTreeStock_map);
			writeLine(scene, speciesName, "currentDemand(kg/ha/year)", currentDemand_map);
			writeLine(scene, speciesName, "deficientDemand(kg/ha/year)", deficientDemand_map);
			writeLine(scene, speciesName, "optimalDemand(kg/ha/year)", optimalDemand_map);
			writeLine(scene, speciesName, "potentialUptake(kg/ha/year)", potentialUptake_map);
			writeLine(scene, speciesName, "actualUptake(kg/ha/year)", actualUptake_map);
			writeLine(scene, speciesName, "currentRetranslocation(kg/ha/year)", currentRetranslocation_map);
			writeLine(scene, speciesName, "currentRequirement(kg/ha/year)", currentRequirement_map);
			writeLine(scene, speciesName, "aboveGroundLitterProduction(kg/ha/year)", aboveGroundLitterProduction_map);
			writeLine(scene, speciesName, "belowGroundLitterProduction(kg/ha/year)", belowGroundLitterProduction_map);
			writeLine(scene, speciesName, "nutrientRemoval(harvesting)(kg/ha/year)", nutrientRemoval_map);
		}

	}

	/**
	 * Writes a line, source is an AdditionMap
	 */
	private void writeLine(HetScene scene, String speciesName, String type, AdditionMap map) {

		int date = scene.getDate();

		StringBuffer line = new StringBuffer();

		line.append("" + date);
		line.append(TAB);
		line.append(speciesName);
		line.append(TAB);
		line.append(type);

		for (String eName : HetTreeElement.elementNames) {

			// AdditionMap.getValue () never returns null
			double value = map.getValue(speciesName + "." + eName); // 0 if not
																	// found

			line.append(TAB);
			line.append("" + value);

		}

		add(new FreeRecord(line.toString()));

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}