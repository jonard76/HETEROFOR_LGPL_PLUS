/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Import;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * Exports the soil temperature at an hourly time step
 *
 * @author N. Beudez, F. de Coligny, M. Jonard - September 2017
 */
public class HetSoilTemperatureHourlyExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetSoilTemperatureHourlyExport");
	//static public String AUTHOR = "N. Beudez, F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetSoilTemperatureHourlyExport.description");

	/**
	 * Represents a line in the export file.
	 */
	@Import
	static public class Line extends Record {

		public Line() {
			super();
		}

		public Line(String line) throws Exception {
			super(line);
		}

		public int horizonId;
		public int year;
		public int month;
		public int day;
		public int hour;
		public String soilTemperature; // unit: degree celsius. Registered as a String because can be "NA": when
									   // soil temperature calculation in mineral horizons is not activated)
	}

	/**
	 * The separator used in generated .csv file
	 */
	static private final String TAB = "\t";

	/**
	 * Constructor
	 */
	public HetSoilTemperatureHourlyExport() {

		super();

		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return (referent instanceof HetModel);
	}

	@Override
	public String getName() {
		return Translator.swap("HetSoilTemperatureHourlyExport.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez, F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetSoilTemperatureHourlyExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: create a list of records. In script mode, save (fileName) must be
	 * called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// Map with:
		//		key: horizon id
		//		value: map with key: year_month_day_hour, value: soil temperature (of type String because can be "NA": when
		//			   soil temperature calculation in mineral horizons is not activated)
		LinkedHashMap<Integer, LinkedHashMap<String, String>> horizonIdHourlySoilTemperatureMap = new LinkedHashMap<Integer, LinkedHashMap<String, String>>();

		// Sort horizon ids on ascending order
		Set<Integer> horizonIdsSet = scene.getSoil().getHorizonMap().keySet();
		Set<Integer> sortedHorizonIds = new TreeSet<>(horizonIdsSet);

		// Fill in horizonIdHourlySoilTemperatureMap map
		for (int horizonId : sortedHorizonIds) {

			// Map with key: year_month_day_hour, value: soil temperature
			LinkedHashMap<String, String> dateSoilTemperatureMap = new LinkedHashMap<String, String>();

			horizonIdHourlySoilTemperatureMap.put(horizonId, dateSoilTemperatureMap);
		}

		String soilTemperature;

		Step step = scene.getStep();
		Project project = step.getProject();
		HetInitialParameters ip = (HetInitialParameters) project.getModel().getSettings();

		// Loop on steps
		for (Step st : project.getStepsFromRoot(step)) {

			HetScene sc = (HetScene) st.getScene();
			HetSoil soil = sc.getSoil();

			for (HetHorizon horizon : sc.getSoil().getHorizons()) {

				int horizonId = horizon.id;
				LinkedHashMap<String, String> dateSoilTemperatureMap = horizonIdHourlySoilTemperatureMap.get(horizonId);

				// Remark: waterBalanceMap for initial scene is empty so that the following "for ()" loop is not entered for
				// the initial scene.
				for (String date : sc.waterBalanceMap.keySet()) {

					// date is "year_month_day_hour" string
					String[] ymdh = date.split(HetMeteorology.SEP);
					int year = Integer.valueOf(ymdh[0]);
					int month = Integer.valueOf(ymdh[1]);
					int day = Integer.valueOf(ymdh[2]);
					int hour = Integer.valueOf(ymdh[3]);

					if (!horizon.isOrganic()) { // mineral horizon

						if (ip.mineralHorizonsTemperatureCalculationActivated) {
							soilTemperature = String.valueOf(horizon.getTimeMineralHorizonTemperatureMap().get(date));
						} else {
							soilTemperature = "NA";
						}
					} else { // organic horizon
						double airTemperature = ip.meteorology.getMeteoLine(year, month, day, hour).airTemperature;
						soilTemperature = String.valueOf((airTemperature+soil.getSoilInterfaceTemperatureMap().get(date))/2.0);
					}

					dateSoilTemperatureMap.put(date, soilTemperature);
				}
			}
		}

		// 1. Custom headers
		add(new CommentRecord("Heterofor soil temperature hourly export (HetSoilTemperatureHourlyExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Soil temperature lines"));
		String columnNames = "horizonId" + TAB + "year" + TAB + "month" + TAB + "day" + TAB
				+ "hour" + TAB + "soilTemperature (degree celsius)";
		add(new CommentRecord(columnNames));

		writeLines(horizonIdHourlySoilTemperatureMap);
	}

	/**
	 * Writes all soil temperatures registered in the given map.
	 */
	private void writeLines(LinkedHashMap<Integer, LinkedHashMap<String, String>> horizonIdHourlySoilTemperatureMap) {

		for (int horizonId : horizonIdHourlySoilTemperatureMap.keySet()) {

			LinkedHashMap<String, String> dateSoilTemperatureMap = horizonIdHourlySoilTemperatureMap.get(horizonId);

			for (String date : dateSoilTemperatureMap.keySet()) {

				// date is "year_month_day_hour" string
				String[] ymdh = date.split(HetMeteorology.SEP);
				int year = Integer.valueOf(ymdh[0]);
				int month = Integer.valueOf(ymdh[1]);
				int day = Integer.valueOf(ymdh[2]);
				int hour = Integer.valueOf(ymdh[3]);

				Line line = new Line();

				line.horizonId = horizonId;
				line.year = year;
				line.month = month;
				line.day = day;
				line.hour = hour;
				line.soilTemperature = dateSoilTemperatureMap.get(date);

				add(line);
			}
		}
	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}
