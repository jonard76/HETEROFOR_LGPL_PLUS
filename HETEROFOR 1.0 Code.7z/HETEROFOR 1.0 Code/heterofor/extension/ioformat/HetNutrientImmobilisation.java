/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.Vector;

import jeeb.lib.util.AdditionMap;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * HetNutrientImmobilisation exports the nutrient immobilisation of the elements
 * of the trees to a file.
 *
 * @author N. Beudez - December 2016
 */
public class HetNutrientImmobilisation extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetNutrientImmobilisation");
	//static public String AUTHOR = "N. Beudez";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetNutrientImmobilisation.description");

	// A tree line in the file
	static public class TreeLine extends Record {

		public TreeLine() {
			super();
		}

		public TreeLine(String line) throws Exception {
			super(line);
		}

		public String speciesName;
		public String elementName;
		public double value;
	}

	/**
	 * Constructor
	 */
	public HetNutrientImmobilisation() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetNutrientImmobilisation.matchWith ()", "Error in matchWith () (returned false)",
					e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetNutrientImmobilisation.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetNutrientImmobilisation.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// Custom headers
		add(new CommentRecord("Heterofor scene export (HetNutrientImmobilisation) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Trees"));
		add(new CommentRecord("speciesName" + "\t" + "elementName" + "\t" + "immobilisation(kg/ha/year)"));

		writeLines((HetScene) s);

	}

	private void writeLines(HetScene scene) throws Exception {

		double area_ha = scene.getArea() / 10000.0;
		HetInitialParameters ip = (HetInitialParameters) scene.getStep().getProject().getModel().getSettings();
		double cuttingDiameter = ip.cuttingDiameter;

		// 1. Compute nutrients stock at root step
		// key: speciesName.elementName, value: stock value for the element with
		// name elementName
		AdditionMap initialNutrientsStockMap = (AdditionMap) new AdditionMap();

		Vector<Step> allSteps = scene.getStep().getProject().getStepsFromRoot(scene.getStep());
		Iterator i = allSteps.iterator();
		Step initialStep = (Step) i.next();
		HetScene initialScene = (HetScene) initialStep.getScene();

		if (!i.hasNext()) {
			throw new Exception(
					"HetNutrientImmobilisation.writeLines() - Impossible to calculate nutrients immobilisation rate : the date of current step must be strictly greater than the date of the initial step, see Log");
		}

		// BE CAREFUL : Uncomment the following 2 lines to calculate the second scene
		// and set the local chosenScene variable to secondScene in order to use the second scene.

		//Step secondStep = (Step) i.next();
		//HetScene secondScene = (HetScene) secondStep.getScene();

		HetScene chosenScene = initialScene;

		int dateOfInitialStep = chosenScene.getDate();
		int dateOfCurrentStep = scene.getDate();

		if (dateOfInitialStep >= dateOfCurrentStep) {
			throw new Exception(
					"HetNutrientImmobilisation.writeLines() - Impossible to calculate nutrients immobilisation rate : date of initial step must be strictly smaller than the date of the current step, see Log");
		}

		int numberOfGrowthYear = dateOfCurrentStep - dateOfInitialStep;

		for (Iterator it = chosenScene.getTrees().iterator(); it.hasNext();) {

			HetTree t = (HetTree) it.next();
			String speciesName = t.getSpecies().getName();

			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				if ( comp.isAboveGround() && (comp.diameter >= cuttingDiameter) ) {
					for (String elementName : HetTreeElement.elementNames) {
						String key = speciesName + "." + elementName;
						double value = comp.getNutrientContent(elementName) / area_ha;
						initialNutrientsStockMap.addValue(key, value);
					}
				}
			}

		}

		// 2. Compute nutrients stock at current step
		// key: speciesName.elementName, value: stock value for the element with
		// name elementName
		AdditionMap currentNutrientsStockMap = (AdditionMap) new AdditionMap();

		for (Iterator it = scene.getTrees().iterator(); it.hasNext();) {

			HetTree t = (HetTree) it.next();
			String speciesName = t.getSpecies().getName();

			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				if ( comp.isAboveGround() && (comp.diameter >= cuttingDiameter) ) {
					for (String elementName : HetTreeElement.elementNames) {
						String key = speciesName + "." + elementName;
						double value = comp.getNutrientContent(elementName) / area_ha;
						currentNutrientsStockMap.addValue(key, value);
					}
				}
			}

		}

		// 3. Compute nutrients stock for thinned trees.
		// key: speciesName.elementName, value: stock value for thinned trees
		AdditionMap nutrientsStockOfThinnedTreesMap = (AdditionMap) new AdditionMap();

		Iterator it = allSteps.iterator();

		while (it.hasNext()) {

			Step s = (Step) it.next();
			HetScene sc = (HetScene) s.getScene();

			for (Iterator it2 = sc.getTrees("cut").iterator(); it2.hasNext();) {

				HetTree t = (HetTree) it2.next();
				String speciesName = t.getSpecies().getName();

				for (HetTreeCompartment comp : t.getTreeCompartments()) {

					if ( comp.isAboveGround() && (comp.diameter >= cuttingDiameter) ) {
						for (String elementName : HetTreeElement.elementNames) {
							String key = speciesName + "." + elementName;
							double value = comp.getNutrientContent(elementName) / area_ha;
							nutrientsStockOfThinnedTreesMap.addValue(key, value);
						}
					}


				}
			}

		}

		// Loop on the sorted keys: "speciesName.elementName"
		for (String key : new TreeSet<>(initialNutrientsStockMap.getKeys())) {

			TreeLine r = new TreeLine();
			StringTokenizer st = new StringTokenizer(key, ".");

			String speciesName = st.nextToken();
			String elementName = st.nextToken();

			double value = (currentNutrientsStockMap.getValue(key) - initialNutrientsStockMap.getValue(key) + nutrientsStockOfThinnedTreesMap
					.getValue(key)) / numberOfGrowthYear;

			r.speciesName = speciesName;
			r.elementName = elementName;
			r.value = value;

			add(r);
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel model) throws Exception {
		return null;
	}

}
