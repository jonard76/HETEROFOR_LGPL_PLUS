/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetElementState;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.treechemistry.HetCompartment;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.GTreeIdComparator;
import capsis.util.StandRecordSet;

/**
 * HetTreeChemistry exports tree chemistry.
 *
 * @author F. de Coligny - September 2016
 */
public class HetTreeChemistry extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetTreeChemistry");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetTreeChemistry.description");

	public final static String TAB = "\t";

	private boolean wroteHeader;

	/**
	 * Constructor
	 */
	public HetTreeChemistry() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			return referent instanceof HetModel;

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTreeChemistry.matchWith ()",
					"Error in matchWith () (returned false)", e);
			return false;
		}

	}

	@Override
	public String getName() {
		return Translator.swap("HetTreeChemistry.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetTreeChemistry.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// For each step in the scenario from the root, write all trees
		Step step = scene.getStep();
		Project project = step.getProject();
		for (Step stp : project.getStepsFromRoot(step)) {

			if (!wroteHeader)
				writeHeader(stp);

			writeLines((HetScene) stp.getScene());

		}

	}

	private void writeHeader(Step step) throws Exception {

		if (wroteHeader)
			return;

		// 1. Custom headers
		add(new CommentRecord(
				"Heterofor Tree Chemistry Export (HetTreeChemistry) at "
						+ new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Trees"));

		StringBuffer h = new StringBuffer();
		h.append("date" + TAB + "id" + TAB + "speciesName" + TAB
				+ "livingStatus" + TAB + "compartmentType" + TAB + "compartmentName"
				+ TAB + "biomass(kgC)");

		for (String eName : HetTreeElement.elementNames) {
			h.append(TAB + eName + "(mg/g)");
		}

		add(new CommentRecord(h.toString()));

		wroteHeader = true;

	}

	private void writeLines(HetScene scene) {

		// Sort the trees on their ids
		Set sortedTrees = new TreeSet(new GTreeIdComparator());
		sortedTrees.addAll(scene.getTrees());

		// Alive trees
		for (Iterator i = sortedTrees.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			writeLines(scene, t, "alive");
		}

		// Cut trees
		Collection cutTrees = scene.getTrees("cut");
		if (cutTrees != null && !cutTrees.isEmpty()) {
			sortedTrees = new TreeSet(new GTreeIdComparator());
			sortedTrees.addAll(cutTrees);
			for (Iterator i = sortedTrees.iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();
				writeLines(scene, t, "cut");
			}
		}

	}

	// Write lines for the given tree
	private void writeLines(HetScene scene, HetTree t, String livingStatus) {


		for (String cName : HetTreeCompartment.compartmentNames) {
			HetTreeCompartment tc = t.getTreeCompartment(cName);
			writeCompartmentLine(scene, t, livingStatus, "tree", cName, tc);
		}
		for (String cName : HetLitterCompartment.compartmentNames) {
			HetLitterCompartment lc = t.getLitterCompartment(cName);
			writeCompartmentLine(scene, t, livingStatus, "litter", cName, lc);
		}

	}

	// Write a line for the given tree or litter compartment
	private void writeCompartmentLine(HetScene scene, HetTree t,
			String livingStatus, String compartmentType, String cName, HetCompartment comp) {

		// Write a line for the given tree
		StringBuffer l = new StringBuffer();

		l.append(scene.getDate());
		l.append(TAB + t.getId());
		l.append(TAB + t.getSpecies().getName());
		l.append(TAB + livingStatus);

		l.append(TAB + compartmentType);
		l.append(TAB + cName);

		// If the compartment is not present in the tree, write "" values
		String biomass = comp == null ? "" : ""+comp.getBiomass();
		l.append(TAB + biomass);

		HetElementState concentrations = null;
		if (comp != null)
			concentrations = comp.getConcentrations();

		for (String eName : HetTreeElement.elementNames) {

			String conc = comp == null ? "" : ""+concentrations.getValue (eName);
			l.append(TAB + conc);

		}

		add(new FreeRecord(l.toString()));

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}