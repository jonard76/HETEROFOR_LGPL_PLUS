/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.standviewer;

import heterofor.model.HetCell;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetSpecies;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Line2D;
import java.util.Collection;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import jeeb.lib.util.ColoredPanel;
import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.RGBManager;
import jeeb.lib.util.RGBManagerClasses;
import jeeb.lib.util.Settings;
import jeeb.lib.util.Translator;
import jeeb.lib.util.Vertex3d;
import capsis.commongui.projectmanager.StepButton;
import capsis.defaulttype.Tree;
import capsis.defaulttype.plotofcells.Cell;
import capsis.defaulttype.plotofcells.RectangularPlot;
import capsis.extension.standviewer.SVSimple;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.lib.samsaralight.SLCompass;


/**
 * SVHeterofor is a cartography simple viewer for trees with coordinates. It draws
 * the trees within the cells. It's based on SVSimple. Compatibility only with the
 * Heterofor model.
 *
 * @author N. Beudez - March 2017
 */
public class SVHeterofor extends SVSimple {

	static {
		Translator.addBundle("heterofor.extension.standviewer.SVHeterofor");
	}

	// nb-13.08.2018
	//static public String NAME = Translator.swap("SVHeterofor");
	//static public String DESCRIPTION = Translator.swap("SVHeterofor.description");
	//static public String AUTHOR = "N. Beudez";
	//static public String VERSION = "1.0";

	// Radiation colors
	public static final Color LIGHT1 = new Color(0, 0, 0); // Color.BLACK
	public static final Color LIGHT2 = new Color(100, 100, 100);
	public static final Color LIGHT3 = new Color(150, 150, 150);
	public static final Color LIGHT4 = new Color(200, 200, 200);
	public static final Color LIGHT5 = new Color(255, 255, 255); // Color.WHITE

	// Crown
	private ButtonGroup crownGroup;
	private JRadioButton crownShowedButton;
	private JRadioButton crownNotShowedButton;

	// Legend
	private JCheckBox showLegendCheckBox;

	// Color manager for the light on Heterofor ground cells
	private RGBManagerClasses<HetCell> lightRGBManager;


	/**
	 * Init method
	 */
	@Override
	public void init(GModel model, Step s, StepButton but) throws Exception {

		super.init(model, s, but);

		lightRGBManager = new RGBManagerClasses<HetCell>(Translator.swap("SVHeterofor.lightLegend")) {

			/**
			 * Add the classes with their associated color and caption with
			 * addClass ().
			 */
			@Override
			public void init() {
				addClass(RGBManager.toRGB(LIGHT1), Translator.swap("SVHeterofor.light1"), -Double.MAX_VALUE, 6.25);
				addClass(RGBManager.toRGB(LIGHT2), Translator.swap("SVHeterofor.light2"), 6.25, 12.5);
				addClass(RGBManager.toRGB(LIGHT3), Translator.swap("SVHeterofor.light3"), 12.5, 25);
				addClass(RGBManager.toRGB(LIGHT4), Translator.swap("SVHeterofor.light4"), 25, 50);
				addClass(RGBManager.toRGB(LIGHT5), Translator.swap("SVHeterofor.light5"), 50, Double.MAX_VALUE);
			}

			@Override
			public double getValue(HetCell e) {
				return e.getLightResult().get_horizontalRelativeEnergy();
			}

		};

		// Create the option panel
		try {
			optionPanel = new ColumnPanel();

			// Crowns
			ColumnPanel crownPanel = new ColumnPanel(Translator.swap("SVHeterofor.crown"));

			crownShowedButton = new JRadioButton(Translator.swap("SVHeterofor.crownShowed"));
			LinePanel crownShowedLine = new LinePanel();
			crownShowedLine.add(crownShowedButton);
			crownShowedLine.addGlue();
			crownPanel.add(crownShowedLine);

			crownNotShowedButton = new JRadioButton(Translator.swap("SVHeterofor.crownNotShowed"));
			LinePanel crownNotShowedLine = new LinePanel();
			crownNotShowedLine.add(crownNotShowedButton);
			crownNotShowedLine.addGlue();
			crownPanel.add(crownNotShowedLine);

			crownPanel.addStrut0();
			optionPanel.add(crownPanel);

			crownGroup = new ButtonGroup();
			crownGroup.add(crownShowedButton);
			crownGroup.add(crownNotShowedButton);

			boolean crownShowed = Settings.getProperty("SVHeterofor.crownShowed", true);
			crownGroup.setSelected(crownShowedButton.getModel(), crownShowed);
			crownGroup.setSelected(crownNotShowedButton.getModel(), !crownShowed);

			// Legend
			showLegendCheckBox = new JCheckBox(Translator.swap("SVHeterofor.showLegend"), Settings.getProperty("SVHeterofor.showLegend", true));
			LinePanel showLegendLine = new LinePanel();
			showLegendLine.add(showLegendCheckBox);
			showLegendLine.addGlue();
			optionPanel.add(showLegendLine);

			((ColumnPanel) optionPanel).addGlue();

			updateLegend();
			revalidate();

		} catch(Exception e) {
			Log.println(Log.ERROR, "SVHeterofor.init()", "Exception", e);
			throw e;
		}
	}


	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return (referent instanceof HetModel);
	}

	@Override
	public String getName() {
		return Translator.swap("SVHeterofor.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez";
	}

	@Override
	public String getDescription() {
		return Translator.swap("SVHeterofor.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Processes options once the option panel edited and closed.
	 */
	protected void optionAction() {

		// Save user's choices in the Options tab
		Settings.setProperty("SVHeterofor.crownShowed", crownShowedButton.isSelected());
		Settings.setProperty("SVHeterofor.showLegend", showLegendCheckBox.isSelected());

		// Save user's choices in the General tab
		super.optionAction();

		updateLegend();
	}

	/**
	 * Method to draw a GCell within this viewer.
	 */
	public void drawCell(Graphics2D g2, Cell gcell, Rectangle.Double r) {

		HetCell cell = (HetCell) gcell;

		// Overwrites the color classes defined in HetModel
		cell.setRGB(lightRGBManager.getRGB(cell));

		super.drawCell(g2, cell, r);
	}


	/**
	 * Method to draw a Spatialized Tree within this viewer.
	 */
	public void drawTree(Graphics2D g2, Tree t, Rectangle.Double r) {

		if ( !crownShowedButton.isSelected() ) {
			return;
		} else {
			super.drawTree(g2, t, r);
		}
	}


	/**
	 * Draw the scale.
	 */
	protected void drawMore(Graphics2D g2, Rectangle.Double r, GScene stand) {

		Vertex3d origin = stand.getOrigin();

		RectangularPlot plot = (RectangularPlot) stand.getPlot();
		double cellWidth = plot.getCellWidth();

		double x = origin.x;
		double y = origin.y+stand.getYSize()+cellWidth/3.0;
		double x1 = x+cellWidth;
		double y1 = y;

		g2.setColor(Color.BLACK);
		Shape scale = new Line2D.Double(x, y, x1, y1);

		double h = cellWidth/10.0;
		double y2 = y+h/2.0;
		double y3 = y-h/2.0;
		Shape border1 = new Line2D.Double(x, y2, x, y3);
		Shape border2 = new Line2D.Double(x1, y2, x1, y3);

		g2.draw(scale);
		g2.draw(border1);
		g2.draw(border2);
		g2.drawString("" + cellWidth + " m", (float) x, (float) (y+h));
	}

	/**
	 * Update the legend.
	 */
	private void updateLegend() {

		if ( !showLegendCheckBox.isSelected() ) {
			setLegend(null);
			return;
		}

		ColumnPanel legend = new ColumnPanel(2, 0);

		// Compass
		HetModel hetModel = (HetModel) stepButton.getStep().getProject().getModel();
		HetInitialParameters ip = hetModel.getSettings ();
//		SLSettings slSettings = hetModel.getSLModel().getSettings();
		SLCompass compass = new SLCompass(ip.samsaFileLoader.getPlotAspect_deg(), ip.samsaFileLoader.getNorthToXAngle_cw_deg());
		legend.add(compass);

		// Crown layers colors
		if ( crownShowedButton.isSelected() ) {

			ColumnPanel crownLegend = new ColumnPanel(Translator.swap("SVHeterofor.crownLegend"), 0, 0);

			crownLegend.setOpaque(true);
			crownLegend.setBackground(Color.WHITE);

//			HetInitialParameters ip = (HetInitialParameters) stepButton.getStep().getProject().getModel().getSettings();
			Collection<HetSpecies> speciesCollection = ip.speciesMap.values();

			for (HetSpecies species : speciesCollection) {
				Color color = species.color;

				LinePanel l0 = new LinePanel();
				l0.setBackground(Color.WHITE);

				ColoredPanel b1 = new ColoredPanel(color);
				l0.add(b1);

				JLabel lab0 = new JLabel(species.niceName);
				l0.add(lab0);

				l0.addGlue();
				crownLegend.add(l0);
			}

			crownLegend.addStrut0();
			legend.add(crownLegend);
		}

		// Light colors
		JComponent p = lightRGBManager.getCaption();
		p.setBackground(Color.WHITE);
		legend.add(p);

		// Configure legend
		legend.addGlue();

		legend.setOpaque(true);
		legend.setBackground(Color.WHITE);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(legend, BorderLayout.NORTH);
		panel.setBackground(Color.WHITE);

		setLegend(panel);
	}

}
