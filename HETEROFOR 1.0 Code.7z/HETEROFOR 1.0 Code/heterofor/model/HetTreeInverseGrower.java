/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.Random;

/**
 * An alternative Heterofor growth process, calculates parUseEfficiency in the
 * end based on given dbh and height increments.
 *
 * @author M. Jonard - March 2016
 */
public class HetTreeInverseGrower extends HetTreeGrower {

	private HetTree refTree;

	private HetTreeRadiationStatus radiationStatus;
	private double parUseEfficiency;
	private double grossPrimaryProduction_kgC;
	private double maintenanceRespiration_kgC;
	private double leafRetranslocation_kgC;
	private double fineRootRetranslocation_kgC;
	private double netPrimaryProduction_kgC;
	private HetFunctionalCompartmentsProduction production;
	private double totalStructuralBiomassToAllocate_kgC;
	private double deltaAboveGroundStructuralBiomass_kgC;
	private double deltaDbh2Height; //fa-31.10.2018, variable exported by calibration script
	private double deltaG; // fa-02.11.2018
	private double deltaHeight;
	private double deltaDbh_cm;

	// fc+mj+fa-14.11.2017
	private HetYearlyTranspirationMemory yearlyTranspirationMemory;

	//mj+fa-04.12.2017
	private double fruitLitterFall_kgC;


	/**
	 * Constructor
	 */
	public HetTreeInverseGrower(HetScene refScene, HetScene newScene, HetInitialParameters ip, Random random, HetTree refTree,
			int year, double deltaDbh, double deltaHeight, double forcedNppToGppRatio,
			HetYearlyTranspirationMemory yearlyTranspirationMemory, double fruitLitterFall_kgC) throws RuntimeException, Exception { // fc-22.6.2017 added Exception

		// fc+mj-12.9.017 added forcedNppToGppRatio, used if > 0

		this.refTree = refTree;
		HetSpecies species = refTree.getSpecies();
		//HetScene refScene = (HetScene) refTree.getScene();

		this.deltaHeight = deltaHeight;
		this.deltaDbh_cm = deltaDbh;

		this.yearlyTranspirationMemory = yearlyTranspirationMemory;

		this.fruitLitterFall_kgC = fruitLitterFall_kgC; //mj+fa-04.12.2017

		double refDbh = refTree.getDbh();
		double refDbh_m = refDbh / 100d;
		double refHeight = refTree.getHeight();

		double newDbh = refDbh + deltaDbh;
		double newDbh_m = newDbh / 100d;
		double newHeight = refHeight + deltaHeight;

		// PHASE 1: light
		radiationStatus = new HetTreeRadiationStatus(refTree);

		// PHASE 2 : inverse growth
//		double deltaDbh2Height = (newDbh_m * newDbh_m * newHeight) - (refDbh_m * refDbh_m * refHeight);
		deltaDbh2Height = (newDbh_m * newDbh_m * newHeight) - (refDbh_m * refDbh_m * refHeight); // fa-31.10.2018
		deltaG = (newDbh_m * newDbh_m * Math.PI / 4) - (refDbh_m * refDbh_m  * Math.PI / 4); // fa-02.11.2018

		if (deltaDbh2Height < 0)
			deltaDbh2Height = 0;

		deltaAboveGroundStructuralBiomass_kgC = deltaDbh2Height
				* (species.aboveBiomassBeta * 0.5 * species.aboveBiomassGamma * Math.pow(refDbh_m * refDbh_m
						* refHeight, species.aboveBiomassGamma - 1d));

		totalStructuralBiomassToAllocate_kgC = (deltaAboveGroundStructuralBiomass_kgC * (1 + species.rootToShootRatio))
				+ refTree.getBranchLitterFall_kgC() + refTree.getRootLitterFall_kgC();

		// Calculation of functional compartments biomass and production
		production = new HetFunctionalCompartmentsProduction(ip, refTree, deltaDbh);

		// production.correction () is not called in inverse growth //
		// fc+mj-10.3.2017

		// Leaf and fineRoot retranslocation
		leafRetranslocation_kgC = species.leafRetranslocationRate * species.leafRelativeLossRate
				* refTree.getLeafBiomass_kgC();
		fineRootRetranslocation_kgC = species.fineRootRetranslocationRate * species.fineRootRelativeLossRate
				* refTree.getFineRootBiomass_kgC();
		double retranslocation_kgC = leafRetranslocation_kgC + fineRootRetranslocation_kgC;

		netPrimaryProduction_kgC = totalStructuralBiomassToAllocate_kgC - retranslocation_kgC
				+ production.newLeafBiomassProduction_kgC + production.newRhizosphereBiomassProduction_kgC + fruitLitterFall_kgC;

		//fa-29.10.2018
		double nppToGppRatio = refTree.getNppToGppRatio();


		// fc+mj-31.7.2017 added the else below
		if (ip.constantNppToGppRatio) {

			//fa-29.10.2018
			boolean constantNppToGppRatio2 = false; // fa-29.10.2018: /!\temporary, to be set in correspondence with value in HetTreeForwardGrower
			if (constantNppToGppRatio2) {
			//fa-29.10.2018

				// fc+mj-12.9.2017 management of forcedNppToGppRatio
//				double nppToGppRatio = forcedNppToGppRatio > 0 ? forcedNppToGppRatio : refTree.getNppToGppRatio ();
				nppToGppRatio = forcedNppToGppRatio > 0 ? forcedNppToGppRatio : refTree.getNppToGppRatio (); //fa-29.10.2018

				grossPrimaryProduction_kgC = netPrimaryProduction_kgC / nppToGppRatio;

			//fa-29.10.2018
			} else {
				double D_d = refTree.getMean2CrownRadius()*2d / (refTree.getDbh()/100d);
				double D_dIndex = D_d / species.crownToStemDiameterEstimation.result(newDbh * Math.PI);
				double nppToGppRatioModel = species.nppToGppRatio_intercept + species.nppToGppRatio_slope*D_dIndex;

				// fa-03.11.2018
				nppToGppRatioModel = Math.max(nppToGppRatioModel, 0.2);
				nppToGppRatioModel = Math.min(nppToGppRatioModel, 0.8);

				grossPrimaryProduction_kgC = netPrimaryProduction_kgC / nppToGppRatioModel;
				refTree.setNppToGppRatioForNextYear(nppToGppRatioModel);
			}

		} else {

			// fc+mj-8.3.2017 added ip and year
			// fc+fa-31.7.2017 added castaneaYearlyLeafRespiration_kgC
			double castaneaYearlyLeafRespiration_kgC = -1; // -1 means not used
			maintenanceRespiration_kgC = HetTreeForwardGrower.calculateMaintenanceRespiration_kgC2(refScene, newScene, refTree, ip, year,
					castaneaYearlyLeafRespiration_kgC);

			grossPrimaryProduction_kgC = netPrimaryProduction_kgC * (1 + ip.compartmentGrowthRespirationFraction)
					+ maintenanceRespiration_kgC + ip.compartmentGrowthRespirationFraction * retranslocation_kgC;

		}

		parUseEfficiency = grossPrimaryProduction_kgC / radiationStatus.interceptedParRadiation;

	}

	@Override
	public HetTree getTree() {
		return refTree;
	}

	@Override
	public HetTreeRadiationStatus getRadiationStatus() {
		return radiationStatus;
	}

	@Override
	public double getParUseEfficiency() {
		return parUseEfficiency;
	}

	@Override
	public double getGrossPrimaryProduction_kgC() {
		return grossPrimaryProduction_kgC;
	}

	@Override
	public double getMaintenanceRespiration_kgC() {
		return maintenanceRespiration_kgC;
	}

	@Override
	public double getLeafRetranslocation_kgC() {
		return leafRetranslocation_kgC;
	}

	@Override
	public double getFineRootRetranslocation_kgC() {
		return fineRootRetranslocation_kgC;
	}

	@Override
	public double getNetPrimaryProduction_kgC() {
		return netPrimaryProduction_kgC;
	}

	@Override
	public HetFunctionalCompartmentsProduction getProduction() {
		return production;
	}

	@Override
	public double getTotalStructuralBiomassToAllocate_kgC() {
		return totalStructuralBiomassToAllocate_kgC;
	}

	@Override
	public double getDeltaAboveGroundStructuralBiomass_kgC() {
		return deltaAboveGroundStructuralBiomass_kgC;
	}

	// fa-31.10.2018
	@Override
	public double getDeltaDbh2Height() {
		return deltaDbh2Height;
	}

	// fa-02.11.2018
	@Override
	public double getDeltaG() {
		return deltaG;
	}

	@Override
	public double getDeltaHeight() {
		return deltaHeight;
	}

	@Override
	public double getDeltaDbh_cm() {
		return deltaDbh_cm;
	}

	public HetYearlyTranspirationMemory getYearlyTranspirationMemory() {
		return yearlyTranspirationMemory;
	}
}
