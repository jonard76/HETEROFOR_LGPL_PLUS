/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * Nutrient growth sensitivity for the main nutrients.
 *
 * @author M. Jonard - February 2016
 */
public class HetNutrientGrowthSensitivity implements Serializable {

	private double sensitivity_N;
	private double sensitivity_P;
	private double sensitivity_S;
	private double sensitivity_Ca;
	private double sensitivity_Mg;
	private double sensitivity_K;

	/**
	 * Constructor.
	 */
	public HetNutrientGrowthSensitivity(String str) throws Exception {
		// format: nutrientGrowthSensitivity (N;P;S;Ca;Mg;K)
		// e.g. nutrientGrowthSensitivity(1;0.8;0.1;0.15;0.25;0.4)

		if (!str.startsWith("nutrientGrowthSensitivity(")) {
			throw new Exception(
					"HetNutrientGrowthSensitivity error, string should start with \"nutrientGrowthSensitivity(\": "
							+ str);
		}
		String s = str.replace("nutrientGrowthSensitivity(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		sensitivity_N = Check.doubleValue(st.nextToken());
		sensitivity_P = Check.doubleValue(st.nextToken());
		sensitivity_S = Check.doubleValue(st.nextToken());
		sensitivity_Ca = Check.doubleValue(st.nextToken());
		sensitivity_Mg = Check.doubleValue(st.nextToken());
		sensitivity_K = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns the sensitivity value for the given element name.
	 */
	public double getValue(String elementName) {

		if (elementName.equals(HetTreeElement.N))
			return sensitivity_N;
		else if (elementName.equals(HetTreeElement.P))
			return sensitivity_P;
		else if (elementName.equals(HetTreeElement.S))
			return sensitivity_S;
		else if (elementName.equals(HetTreeElement.Ca))
			return sensitivity_Ca;
		else if (elementName.equals(HetTreeElement.Mg))
			return sensitivity_Mg;
		else if (elementName.equals(HetTreeElement.K))
			return sensitivity_K;
		else
			return 0;

	}

	public String toString() {
		return "nutrientGrowthSensitivity(" + sensitivity_N + ";" + sensitivity_P + ";" + sensitivity_S + ";"
				+ sensitivity_Ca + ";" + sensitivity_Mg + ";" + sensitivity_K + ")";
	}

}
