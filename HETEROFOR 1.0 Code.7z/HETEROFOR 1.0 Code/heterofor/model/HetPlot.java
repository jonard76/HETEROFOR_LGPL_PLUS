/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.ArrayList;
import java.util.Collection;

import capsis.kernel.GScene;
import capsis.lib.regeneration.RGPlot;
import jeeb.lib.util.Vertex3d;
import jeeb.lib.util.heightmap.HeightMap;

/**
 * A description of the plot : a rectangular plot.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetPlot extends RGPlot {

	private double slope_deg; // GL 17/05/2013 needed to compute z coordinates during cell creation
	private double aspect_deg; // GL 17/05/2013 needed to compute z coordinates during cell creation

	private HeightMap heightMap; // fc-14.6.2013

	/**
	 * Constructor
	 */
	public HetPlot(GScene s, double cellWidth, double slope_deg, double aspect_deg) {
		super(s, cellWidth);
		this.slope_deg = slope_deg;
		this.aspect_deg = aspect_deg;

		createCells (); // 07/03/2013

		// fc-13.6.2013 added the vertices creation: the plot bounding rectangle
		double x0 = getOrigin ().x;
		double y0 = getOrigin ().y;
		double x1 = x0 + getXSize ();
		double y1 = y0 + getYSize ();
		Vertex3d v0 = new Vertex3d (x0, y0, 0);
		Vertex3d v1 = new Vertex3d (x0, y1, 0);
		Vertex3d v2 = new Vertex3d (x1, y1, 0);
		Vertex3d v3 = new Vertex3d (x1, y0, 0);
		Collection<Vertex3d> vertices = new ArrayList<Vertex3d> ();
		vertices.add (v0);
		vertices.add (v1);
		vertices.add (v2);
		vertices.add (v3);
		setVertices (vertices);

		buildHeightMap (); // fc-14.6.2013

		// Update all z coordinates in the cells according to the heightMap // fc-14.6.2013
		for (int i = 0; i < getNLin (); i++) {
			for (int j = 0; j < getNCol (); j++) {
				HetCell c = (HetCell) getCell (i, j);
				c.updateZs (heightMap);
			}
		}

	}

	/**
	 * Create a heightMap covering the whole scene. It can calculate z for all (x, y).
	 */
	private void buildHeightMap () { // fc-14.6.2013

		int nLin = getNLin ();
		int nCol = getNCol ();
		double[][] heights = new double[nLin][nCol];

		for (int i = 0; i < nLin; i++) {
			for (int j = 0; j < nCol; j++) {
				HetCell cell = (HetCell) getCell (i, j);
				heights[i][j] = HetModel.getZCoordinate (
						cell.getXCenter (),
						cell.getYCenter (),
						Math.toRadians (getSlope_deg()),
						Math.toRadians (getAspect_deg ()));
			}
		}

		double zScaleFactor = 1;
		double pixelSize = getCellWidth ();
		heightMap = new HeightMap(heights, zScaleFactor, pixelSize);
		Vertex3d v0 = getOrigin ();
		heightMap.move (v0.x, v0.y, v0.z);

	}

	/**
	 * This method creates cells in the plot. GL - 7/3/13
	 */
	public void createCells () {
		for (int i = 0; i < getImmutable ().nLin; i++) {
			for (int j = 0; j < getImmutable ().nCol; j++) {
				// x of the bottom left corner of the Cell
				double a = getOrigin ().x + j * getCellWidth ();
				// y of the bottom left corner of the Cell
				double b = getOrigin ().y + (getImmutable ().nLin - i - 1) * getCellWidth ();
				// Cells relative coordinates = line, column (i, j)
				addCell (new HetCell (this, i, j, a, b)); // here, we create Cell instances
			}
		}
		createTableCellOrigin_CellId ();
	}

	// /**
	// * This method creates cells in the plot.
	// */
	// public void createCells (double sensorHeight) {
	// for (int i = 0; i < getImmutable().nLin; i++) {
	// for (int j = 0; j < getImmutable().nCol; j++) {
	// // x of the bottom left corner of the Cell
	// double a = getOrigin ().x + j * getCellWidth ();
	// // y of the bottom left corner of the Cell
	// double b = getOrigin ().y + (getImmutable().nLin-i-1)*getCellWidth ();
	// // Cells relative coordinates = line, column (i, j)
	// addCell (new HetCell (this, i, j, a, b, sensorHeight)); // here, we create Cell instances
	// }
	// }
	// createTableBottomLeft_CellId ();
	// }

	public double getSlope_deg () {
		return slope_deg;
	}

	public void setSlope_deg (double slope_deg) {
		this.slope_deg = slope_deg;
	}

	public double getAspect_deg () {
		return aspect_deg;
	}

	public void setAspect_deg (double aspect_deg) {
		this.aspect_deg = aspect_deg;
	}


	public HeightMap getHeightMap () {
		return heightMap;
	}

}
