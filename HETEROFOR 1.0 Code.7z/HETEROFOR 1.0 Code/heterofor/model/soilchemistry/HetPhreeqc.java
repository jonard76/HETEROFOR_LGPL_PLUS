/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soilchemistry;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetReporter;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import jeeb.lib.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import USGS.IPhreeqc;
import USGS.VAR;
import USGS.iphreeqc_java;
import jeeb.lib.util.PathManager;

//import IPhreeqc;
//import jeeb.lib.util.PathManager;

/**
 * A connector to the Phreeqc dll for Heterofor. reequilibrate soil chemistry.
 *
 * @author M. Jonard, F. de Coligny - October 2015
 */
public class HetPhreeqc {

	public static String NEW_LINE = "\n";

	/**
	 * Check if the Phreeqc dll/so is available on this system.
	 */
	static public boolean isPhreeqcAvailable() {
		try {
			loadPhreeqc();
			return true;
		} catch (Throwable t) {
			return false;
		}
	}

	static public void loadPhreeqc() throws Exception {
		// Load the Phreeqc dll/so
		System.loadLibrary("iphreeqc_java"); // throws exc or err if trouble
	}

	/**
	 * Constructor.
	 */
	public HetPhreeqc(HetSoil soil, HetInitialParameters ip) throws Exception {

		// Load the Phreeqc dll/so
		loadPhreeqc();

		IPhreeqc phreeqc = new IPhreeqc();
		phreeqc.SetOutputStringOn(true);

		String databaseFileName = PathManager.getDir("data") + "/heterofor/nutrientCycling/Chemphreeqc.dat";

		if (phreeqc.LoadDatabase(databaseFileName) != 0) {
			System.out.println(phreeqc.GetErrorString());
			System.exit(1);
		}

		for (HetHorizon h : soil.getHorizons()) {

			// Checks can be run by working on the 4th horizon only: comment the
			// upper loop and uncomment these 5 lines
			// Iterator<HetHorizon> it = soil.getHorizons().iterator();
			// HetHorizon h = it.next(); // temporary
			// h = it.next(); // temporary
			// h = it.next(); // temporary
			// h = it.next(); // temporary

			StringBuffer in = new StringBuffer();

			appendSelectedOutput(in, h, ip);

			in.append("END" + NEW_LINE);
			in.append("PRINT" + NEW_LINE);
			in.append("-selected_output false" + NEW_LINE);

			appendSolutionExchangersEqPhases(in, h, ip);

			in.append("END" + NEW_LINE);
			in.append("PRINT" + NEW_LINE);
			in.append("-selected_output true" + NEW_LINE);

			appendRunCells(in, h, ip);

			in.append("END" + NEW_LINE);

			HetReporter.printInStandardOutput("" + in); // check phreeqc input before run

			runPhreeqc(phreeqc, in);

			// Get Phreeqc's results
			Vector<VAR> results = new java.util.Vector<VAR>();
			for (int j = 0; j < phreeqc.GetSelectedOutputColumnCount(); ++j) {
				VAR v = new VAR();
				iphreeqc_java.VarInit(v);
				phreeqc.GetSelectedOutputValue(1, j, v);
				results.add(v);
			}

			// TRACE results in terminal
			HetReporter.printInStandardOutput("#results: " + results.size());
			for (VAR v : results) {
				HetReporter.printInStandardOutput("" + v.getDVal());
			}

			updateHorizonChemistry(h, results, ip);

		}

		HetReporter.printInStandardOutput("HetPhreeqc run was OK ***");

	}

	/**
	 * Prepare Phreeqc input related to SELECTED_OUTPUT block.
	 */
	private void appendSelectedOutput(StringBuffer in, HetHorizon h, HetInitialParameters ip) {

		in.append("KNOBS " + NEW_LINE);
		in.append("-iterations 1000" + NEW_LINE);
		in.append("-convergence_tolerance 1e-6" + NEW_LINE);

		// Selected output block
		in.append("SELECTED_OUTPUT " + NEW_LINE);
		in.append("-reset false " + NEW_LINE);
		in.append("-high_precision true" + NEW_LINE);
		in.append("USER_PUNCH" + NEW_LINE);

		int basicLine = 10;

		// pH is apart (not a concentration)
		in.append("" + basicLine + " PUNCH -LA(\"H+\")" + NEW_LINE);

		double waterVolume = h.volume * h.meanWaterContent * 1000; // l
		double horizonMass = h.volume * h.bulkDensity; // kg

		for (String eltName : h.getSolutionConcentrations().keySet()) {
			basicLine += 10;
			in.append("" + basicLine + " PUNCH TOTMOLE(\"" + eltName + "\") * "
					+ ip.getChemicalElement(eltName).atomicMass + " * 1000 / " + waterVolume + NEW_LINE); // mg/l
		}

		// // Inorganic dissolved carbon is apart (not a concentration)
		// basicLine += 10;
		// in.append("" + basicLine + " PUNCH TOTMOLE(\"C(4)\") * " +
		// ip.getChemicalElement("C(4)").atomicMass
		// + " * 1000 / " + waterVolume + NEW_LINE); // mg/l

		// Cation exchangeable
		for (String exchName : h.getExchangeableCationConcentrations().keySet()) {
			basicLine += 10;
			int absCharge = Math.abs(ip.getChemicalElement(exchName).charge);
			in.append("" + basicLine + " PUNCH MOL(\"" + exchName + "\") * " + waterVolume + NEW_LINE); // mol
		}

		// Anion exchangeable
		for (String exchName : h.getExchangeableAnionConcentrations().keySet()) {
			basicLine += 10;
			int absCharge = Math.abs(ip.getChemicalElement(exchName).charge);
			in.append("" + basicLine + " PUNCH MOL(\"" + exchName + "\") * " + waterVolume + NEW_LINE); // mol
		}

		// Mineral
		for (String mineralName : h.getMineralConcentrations().keySet()) {
			basicLine += 10;

			// HetMineral m = h.getMineral(mineralName);

			// if (m.weatheringType = 1) then
			in.append("" + basicLine + " PUNCH EQUI(\"" + mineralName + "\")" + NEW_LINE); // mol

			// else
			// in.append("" + basicLine + " PUNCH KIN(\"" + mineralName + "\")"
			// + NEW_LINE); // mol

		}

		// Equilibrium between atmospheric CO2 and dissolved inorganic C in
		// solution
		basicLine += 10;
		in.append("" + basicLine + " PUNCH EQUI(\"CO2(g)\")" + NEW_LINE);

	}

	/**
	 * Prepare Phreeqc input related to SOLUTION, EXCHANGE, EQUILIBRIUM_PHASE
	 * blocks.
	 */
	private void appendSolutionExchangersEqPhases(StringBuffer in, HetHorizon h, HetInitialParameters ip) {

		// Solution block
		in.append("SOLUTION " + h.id + NEW_LINE);
		in.append("-units mg/L" + NEW_LINE);

		// water volume per m2, in l
		double v = h.meanWaterContent * h.volume * 1000; // m3 -> l
		in.append("-water " + v + NEW_LINE);

		// No temperature provided to phreeqc at this time

		// pH is apart (not a concentration)
		in.append("pH" + " " + h.solution_pH + NEW_LINE);

		for (String eltName : h.getSolutionConcentrations().keySet()) {
			double conc = h.getSolutionConcentration(eltName);
			in.append(eltName + " " + conc + NEW_LINE);
		}

		// Inorganic dissolved carbon is apart (not a concentration)
		// in.append("C(4)" + " " + 0 + NEW_LINE);

		// Exchange block
		in.append("EXCHANGE " + h.id + NEW_LINE);

		for (String exchName : h.getExchangeableCationConcentrations().keySet()) {
			double conc = h.getExchCationConcentration(exchName);
			int absCharge = Math.abs(ip.getChemicalElement(exchName).charge);
			double qty = conc / 1000 * 10 * h.bulkDensity * h.volume / absCharge;
			in.append(exchName + " " + qty + NEW_LINE);
		}

		for (String exchName : h.getExchangeableAnionConcentrations().keySet()) {
			double conc = h.getExchAnionConcentration(exchName);
			int absCharge = Math.abs(ip.getChemicalElement(exchName).charge);
			double qty = conc / 1000 * 10 * h.bulkDensity * h.volume / absCharge;
			in.append(exchName + " " + qty + NEW_LINE);
		}

		// Equilibrium phases block: always there, at least for CO2(g), see
		// below
		in.append("EQUILIBRIUM_PHASE " + h.id + NEW_LINE);

		// Kinetics block is optional: only if minerals with weatheringType == 2
		// found in the list
		boolean kineticsBlockNeeded = false;

		for (String mineralName : h.getMineralConcentrations().keySet()) {
			HetMineral m = h.getMineral(mineralName);
			if (m.weatheringType == 1) {
				double conc = m.concentration; // mole/kg
				double qty = conc * h.volume * h.bulkDensity; // kg
				double tsi = m.targetSaturationIndex;

				String rt = m.reactionType; // d, p or b (both)
				if (rt.equals ("b"))
					rt = "";

				// in.append(mineralName + " " + tsi + " " + qty + NEW_LINE);
				// d or p indicates respectively dissolution only or
				// precipitation
				// only. If nothing is specified, both are allowed. To be
				// specified
				// in the input file. MJ (26/04/2016)
				in.append(mineralName + " " + tsi + " " + qty + " " + rt + NEW_LINE);
			} else {
				kineticsBlockNeeded = true;
			}
		}

		// Equilibrium between atmospheric CO2 and dissolved inorganic C in
		// solution
		in.append("CO2(g)" + " " + h.logpCO2 + " " + 10 + NEW_LINE);

		// Kinetics block
		if (kineticsBlockNeeded) {
			 in.append("KINETICS " + h.id + NEW_LINE);// ajouter que si n�cessaire

			 for (String mineralName : h.getMineralConcentrations().keySet()) {
				 HetMineral m = h.getMineral(mineralName);
				 if (m.weatheringType == 2) {
					 double conc = m.concentration; // mole/kg
					 double qty = conc * h.volume * h.bulkDensity; // kg

					 in.append(mineralName + NEW_LINE);
					 in.append("-m " + qty + NEW_LINE);
					 in.append("-p " + m.kineticsParameters + NEW_LINE);
					 in.append("-ti 1 year" + NEW_LINE);
					 // timeUnit = second (default), day or year
				 }
			 }

		}


	}


	/**
	 * Run Phreeqc for the given buffer
	 */
	private void runPhreeqc(IPhreeqc phreeqc, StringBuffer in) {

		if (phreeqc.RunString(in.toString()) == 0) {
			HetReporter.printInStandardOutput(phreeqc.GetOutputString());
		} else {
			HetReporter.printInStandardOutput(phreeqc.GetErrorString());
		}

	}

	/**
	 * Prepare Phreeqc input related to RUN_CELLS block.
	 */
	private void appendRunCells(StringBuffer in, HetHorizon h, HetInitialParameters ip) {
		// Run cells block
		in.append("RUN_CELLS " + NEW_LINE);
		in.append("-cells " + h.id + NEW_LINE);

	}

	private void updateHorizonChemistry(HetHorizon h, Vector<VAR> results, HetInitialParameters ip) {

		// Index in the result vector
		int i = 0;

		h.solution_pH = results.get(i++).getDVal();

		// Solution concentrations
		List<String> eltNames = new ArrayList<>(h.getSolutionConcentrations().keySet());
		for (int k = 0; k < eltNames.size(); k++) {
			String eltName = eltNames.get(k);
			h.setSolutionConcentration(eltName, results.get(i++).getDVal());
		}

		// // Temporary
		// results.get(i++).getDVal(); // C(4)

		// Horizon mass
		double horizonMass = h.volume * h.bulkDensity; // kg

		// Exchangeable cations
		List<String> exchNames = new ArrayList<>(h.getExchangeableCationConcentrations().keySet());
		for (int k = 0; k < exchNames.size(); k++) {
			String exchName = exchNames.get(k);
			int absCharge = Math.abs(ip.getChemicalElement(exchName).charge);
			// cmolc/kg OR meq/100g
			h.setExchCationConcentration(exchName, results.get(i++).getDVal() * 100 * absCharge / horizonMass);
		}

		// Exchangeable anions
		exchNames = new ArrayList<>(h.getExchangeableAnionConcentrations().keySet());
		for (int k = 0; k < exchNames.size(); k++) {
			String exchName = exchNames.get(k);
			int absCharge = Math.abs(ip.getChemicalElement(exchName).charge);
			// cmolc/kg OR meq/100g
			h.setExchAnionConcentration(exchName, results.get(i++).getDVal() * 100 * absCharge / horizonMass);
		}

		HetReporter.printInLog("HetPhreeqC, storing mineral concentrations... (horizonMass: " + horizonMass + " h.volume: "
				+ h.volume + " h.bulkDensity: " + h.bulkDensity + ")");

		// Mineral concentrations
		List<String> mineralNames = new ArrayList<>(h.getMineralConcentrations().keySet());
		for (int k = 0; k < mineralNames.size(); k++) {
			String mineralName = mineralNames.get(k);
			// fc-7.9.2016 REMOVED getMineral() in HetHorizon
			// HetMineral m = h.getMineral(mineralName);
			// m.concentration = results.get(i++).getDVal() / horizonMass;
			// mol/kg
			h.setMineralConcentration(mineralName, results.get(i++).getDVal() / horizonMass);
		}

	}

}
