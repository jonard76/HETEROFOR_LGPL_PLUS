/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soilchemistry;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import jeeb.lib.util.Log;

/**
 * A mineral in the heterofor model. Contains a concentration and other data.
 *
 * @author M. Jonard - October 2015
 */
public class HetMineral implements Serializable {

	// fc+mj-8.12.206
	private static Map<String, MineralComposition> compositionMap;

	/**
	 * A mineral contains several mineral components, each with a chemical
	 * element name (see HetChemicalElement) and a mole number.
	 */
	private static class MineralComposition {
		public String mineralName;
		// map: HetChemicalElement name -> number of moles, e.g. K:1 / Al:3 /
		// Si:3
		public Map<String, Double> map;

		/**
		 * Decodes the composition for the mineral with the given name, e.g.
		 * K:1;Al:3;Si:3
		 */
		public MineralComposition(String mineralName, String encodedString)
				throws Exception {
			try {
				this.mineralName = mineralName;

				map = new HashMap<>();
				StringTokenizer st = new StringTokenizer(encodedString.trim(),
						" ;");
				for (; st.hasMoreTokens();) {
					StringTokenizer st2 = new StringTokenizer(st.nextToken()
							.trim(), " :"); // e.g. K:1

					String ceName = st2.nextToken().trim(); // K
					double moleNumber = Double.parseDouble(st2.nextToken()
							.trim()); // 1

					map.put(ceName, moleNumber);
				}
			} catch (Exception e) {
				throw new Exception(
						"HetMineral.MineralCoponent could not decode this component: "
								+ encodedString, e);
			}
		}

		public Set<String> getChemicalElementNames () {
			return map.keySet ();
		}

		/**
		 * Returns the number of moles in this mineral for the given chemical
		 * element name.
		 */
		public double getMoleNumber(String ceName) {
			Double n = map.get(ceName);
			return n == null ? 0 : n;
		}

	}

	static {
		try {
			compositionMap = new HashMap<>();
			compositionMap.put("Quartz", new MineralComposition("Quartz",
					"Si:1"));
			compositionMap.put("K-feldspar", new MineralComposition(
					"K-feldspar", "K:1;Al:1;Si:3"));
			compositionMap.put("K-mica", new MineralComposition("K-mica",
					"K:1;Al:3;Si:3"));
			compositionMap.put("Illite", new MineralComposition("Illite",
					"K:.6;Mg:0.25;Al:2.3;Si:3.5"));
			compositionMap.put("Albite", new MineralComposition("Albite",
					"Na:1;Al:1;Si:3"));
			compositionMap.put("Anorthite", new MineralComposition("Anorthite",
					"Ca:1;Al:2;Si:2"));
			compositionMap.put("Chlorite(14A)", new MineralComposition(
					"Chlorite(14A)", "Mg:5;Al:2;Si:3"));
			compositionMap.put("Vrm", new MineralComposition("Vrm",
					"Mg:0.4;Al:0.8;Si:3.2"));
			compositionMap.put("Kaolinite", new MineralComposition("Kaolinite",
					"Al:2;Si:2"));
			compositionMap.put("Variscite", new MineralComposition("Variscite",
					"Al:1;P:1"));
			compositionMap.put("Ca-Montmorillonite", new MineralComposition(
					"Ca-Montmorillonite", "Ca:0.165;Al:2.33;Si:3.67"));
			compositionMap.put("Manganite", new MineralComposition("Manganite",
					"Mn(2):1"));
			compositionMap.put("Fe(OH)3(a)", new MineralComposition(
					"Fe(OH)3(a)", "Fe(3):1"));

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetMineral static initializer",
					"Error during compositionMap construction", e);
		}

	}

	static public Set<String> getChemicalElementNames (String mineralName) {
		MineralComposition composition = compositionMap
				.get(mineralName);
		return composition.getChemicalElementNames ();
	}

	/**
	 * If the mineral with the given name contains the given chemical element
	 * name, return its moleNumber, else return 0.
	 */
	static public double getMoleNumber(String mineralName, String ceName) {
		MineralComposition composition = compositionMap
				.get(mineralName);
		return composition.getMoleNumber(ceName);
	}

//	/**
//	 * Return the list of chemical element names in this mineral.
//	 */
//	static public List<String> getCeNames(String mineralName) {
//		List<MineralComposition> components = componentsLMap
//				.getObjects(mineralName);
//		List<String> ceNames = new ArrayList<>();
//		for (MineralComposition c : components)
//			ceNames.add(c.ceName);
//		return ceNames;
//	}

	public String name;
	public double concentration; // mole/kg

	public int weatheringType; // equilibrium: 1 / kinetics: 2

	// If weatheringType == 1
	// Target saturation index as log(IAP/Ks), with IAP=ion activity
	// product and Ks-solubility product of the mineral (all
	// dimensionless)
	public double targetSaturationIndex;
	public String reactionType; // d, p, or b (both)

	// If weatheringType == 2
	public String kineticsParameters; // Encoded for PhreeqC

	/**
	 * Constructor, concentration;weatheringProperties, e.g. 0;1;-0.11
	 */
	public HetMineral(String name, String encodedString) throws Exception {

		// 2 possible expected formats:
		// e.g. 0.9;1;(-0.11,d)
		// -> concentration = 0.9, weatheringType = 1, targetSaturationIndex =
		// -0.11,
		// reactionType = d
		// e.g. 0.9;2;(23.13,1.5)
		// -> concentration = 0.9, weatheringType = 2, kineticsParameters =
		// 23.13 1.5

		try {
			this.name = name;

			StringTokenizer st = new StringTokenizer(encodedString, ";");
			concentration = Double.parseDouble(st.nextToken()); // e.g. 0.9
			weatheringType = Integer.parseInt(st.nextToken()); // 1 or 2

			// Weathering parameters
			if (weatheringType == 1) {

				String param = st.nextToken(); // e.g. (-0.11,d)
				param = param.replace('(', ' ');
				param = param.replace(')', ' ');
				param = param.trim(); // e.g. -0.11,d

				StringTokenizer st2 = new StringTokenizer(param, ", ");

				targetSaturationIndex = Double.parseDouble(st2.nextToken()); // -0.11
				reactionType = st2.nextToken().trim(); // d

			} else if (weatheringType == 2) {

				kineticsParameters = st.nextToken(); // e.g. (23.13,1.5)
				kineticsParameters = kineticsParameters.replace('(', ' ');
				kineticsParameters = kineticsParameters.replace(')', ' ');
				kineticsParameters = kineticsParameters.replace(',', ' ');
				kineticsParameters = kineticsParameters.trim(); // e.g. 23.13
																// 1.5

				// In case several spaces between the numbers
				// e.g. 23.13 <2 spaces> 1.5 -> 23.13 1.5 (single space)
				while (kineticsParameters.contains("  ")) {
					kineticsParameters = kineticsParameters.replace("  ", " ");
					kineticsParameters = kineticsParameters.trim();
				}

			} else {
				throw new Exception("HetMineral: unknown weathering value: "
						+ weatheringType);
			}
		} catch (Exception e) {
			throw new Exception(
					"HetMineral error, could not interpret this encoded string: "
							+ encodedString, e);
		}

	}

	/**
	 * Constructor, e.g. 0;1;-0.11
	 */
	public HetMineral(HetMineral original) {
		this.name = original.name;
		this.concentration = 0; // fc-7.9.2016 will be set by PhreeqC
		this.weatheringType = original.weatheringType;
		this.targetSaturationIndex = original.targetSaturationIndex;
		this.reactionType = original.reactionType;
		this.kineticsParameters = original.kineticsParameters;
	}

	@Override
	public String toString() {
		return "HetMineral: " + name + " concentration: " + concentration
				+ " weatheringType: " + weatheringType
				+ " targetSaturationIndex: " + targetSaturationIndex
				+ " reactionType: " + reactionType + " kineticsParameters: "
				+ kineticsParameters;
	}

}
