/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.vegetationperiod;

import heterofor.model.fineresolutionradiativebalance.HetKeyDoy;
import heterofor.model.phenology.HetPhenology;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A phase in a vegetation period, e.g. leafDevelopmentPhase,
 * completeDevelopmentPhase...
 *
 * @author F. André, F. de Coligny - March 2016
 */
public class HetPhase implements Serializable {

	public String name; // LD, LY...

	public int startDoy;
	public int endDoy;
	private List<HetKeyDoy> keyDoys; // optional

	private boolean completeDevelopmentPhase;

	/**
	 * Constructor
	 */
	public HetPhase(String name, int startDoy, int endDoy, int numberOfKeyDoy, Map<Integer, HetPhenology> phenologyMap)
			throws Exception {

		if (startDoy >= endDoy)
			throw new Exception("Could not create an HetPhase: startDoy (" + startDoy + ") >= endDoy (" + endDoy + ")");

		this.name = name;
		this.startDoy = startDoy;
		this.endDoy = endDoy;

		// 2 key doys -> 3 intervals / integer division
		int interval = (endDoy - startDoy) / (numberOfKeyDoy + 1);
		for (int i = 1; i <= numberOfKeyDoy; i++) {
			int doy = startDoy + i * interval;

			HetKeyDoy kd = new HetKeyDoy(doy, name + i); // LD1, LD2,
															// LY2...
			addKeyDoy(kd);

			// for (int speciesId : phenologyMap.keySet()) {
			//
			// HetPhenology pheno = phenologyMap.get(speciesId);
			// // double ladProp = pheno.getLadProportion (doy); // [0, 1] //
			// // LATER
			// double ladProp = 0.333 * i; // TMP
			//
			// kd.addLadProportion(speciesId, ladProp);
			//
			// }

		}

	}

	public boolean contains(int doy) {
		return startDoy <= doy && doy <= endDoy;
	}

	public boolean isCompleteDevelopmentPhase() {
		return completeDevelopmentPhase;
	}

	public void setCompleteDevelopmentPhase(boolean completeDevelopmentPhase) {
		this.completeDevelopmentPhase = completeDevelopmentPhase;
	}

	private void addKeyDoy(HetKeyDoy keyDoy) {
		if (keyDoys == null)
			keyDoys = new ArrayList<>();
		keyDoys.add(keyDoy);
	}

	public List<HetKeyDoy> getKeyDoys() {
		return keyDoys;
	}

	public String getName() {
		return name;
	}

}
