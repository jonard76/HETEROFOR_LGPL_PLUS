/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.vegetationperiod;

import heterofor.model.HetScene;
import heterofor.model.HetTree;

/**
 * Computes the equivalent surfaces for diffuse and direct radiation for a given
 * tree from a yearly radiation balance (LEGACY mode in SamsaraLight).
 *
 * @author F. André, F. de Coligny - May 2017
 *
 */
public class HetAbsorbedRaditionCoefficientsYearlyLevel {

	private double treeLeafAbsorbedDirectRadiationCoefficient = 0;
	private double treeLeafAbsorbedDiffuseRadiationCoefficient = 0;

	/**
	 * Constructor
	 */
	public HetAbsorbedRaditionCoefficientsYearlyLevel(HetScene newScene, HetTree refTree) {

		// Calculation of yearly leaf PAR interception coefficient: DIRECT
//		double treeBranchAbsorbedDirectRadiation = newScene.getBarkAbsorbedDirectRadiation()
//				* refTree.getBranchBarkArea();
		double treeCrownAbsorbedDirectRadiation = refTree.getLightResult().getCrownDirectEnergy() * (1 - 0.11);
		double treeLeafAbsorbedDirectRadiation = treeCrownAbsorbedDirectRadiation; //- treeBranchAbsorbedDirectRadiation;

		// MJ/tree/year / MJ/tree/year
		treeLeafAbsorbedDirectRadiationCoefficient = treeLeafAbsorbedDirectRadiation
				/ newScene.getStandIncidentDirectRadiation();

		// Calculation of yearly leaf PAR interception coefficient: DIFFUSE
//		double treeBranchAbsorbedDiffuseRadiation = newScene.getBarkAbsorbedDiffuseRadiation()
//				* refTree.getBranchBarkArea();
		double treeCrownAbsorbedDiffuseRadiation = refTree.getLightResult().getCrownDiffuseEnergy() * (1 - 0.11);
		double treeLeafAbsorbedDiffuseRadiation = treeCrownAbsorbedDiffuseRadiation;
				//- treeBranchAbsorbedDiffuseRadiation;

		// MJ/tree/year / MJ/tree/year
		treeLeafAbsorbedDiffuseRadiationCoefficient = treeLeafAbsorbedDiffuseRadiation
				/ newScene.getStandIncidentDiffuseRadiation();

	}

	public double getTreeLeafAbsorbedDirectRadiationCoefficient() {
		return treeLeafAbsorbedDirectRadiationCoefficient;
	}

	public double getTreeLeafAbsorbedDiffuseRadiationCoefficient() {
		return treeLeafAbsorbedDiffuseRadiationCoefficient;
	}

}
