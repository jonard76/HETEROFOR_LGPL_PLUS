/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import capsis.defaulttype.Tree;
import capsis.defaulttype.plotofcells.Cell;
import capsis.defaulttype.plotofcells.PlotOfCells;
import capsis.defaulttype.plotofcells.SquareCell;
import capsis.lib.regeneration.RGStand;
import capsis.lib.samsaralight.SLFoliageStateManager;
import capsis.lib.samsaralight.SLLightableScene;
import capsis.lib.samsaralight.SLSensor;
import heterofor.model.fineresolutionradiativebalance.HetBeamSetFactoryOptimized; // for optimized tag mode
//import heterofor.model.fineresolutionradiativebalance.HetBeamSetFactory; // fa-09.08.2017: for non-optimized tag mode
import heterofor.model.phenology.HetPhenology;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import heterofor.model.vegetationperiod.HetVegetationPeriod;
import jeeb.lib.util.Log;

/**
 * HetScene is the description of the Heterofor scene. It is a list of HetTree
 * instances.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetScene extends RGStand implements SLLightableScene, SLFoliageStateManager {

	// private List<Vertex2d> mainRectangle; //GL 8/3/13
	private List<SLSensor> sensors; // gl 23-05-2013

	private HetSoil soil; // optional, may be null, linked to PhreeqC //
	// fc+mj-27.10.2015

	private double NAvailable_kg;
	private double NStandUptake;
	private double NStandOptimalUptake;

	// public double barkStorageCapacity; // l/stand
	// public double foliageStorageCapacity; // l/stand

	// fc-et-al-20.1.2017 was a list, key is year_month_day_hour
	public LinkedHashMap<String, HetWaterBalance> waterBalanceMap;
	// public List<HetWaterBalance> waterBalanceList;

	private double[] dailyGPP_kgC; // fc-et-al-20.1.2017
	private double[] dailyMaintenanceLeafRespiration_kgC; // fc-et-al-20.1.2017

	// fc_et_al_20.1.2017
	private double barkAbsorbedRadiation;
	private double barkAbsorbedDirectRadiation;
	private double barkAbsorbedDiffuseRadiation;
	private double standIncidentGlobalRadiation;

	// fc+fa-31.7.2017 reactivated the two lines below
	private double standIncidentDirectRadiation;
	private double standIncidentDiffuseRadiation;

	// nb+lw-24.01.2017 key: speciesId, value: phenology
	private HashMap<Integer, HetPhenology> phenologyMap;

	// fc+mj+fa-28.6.2017 added next year pheno
	// pheno of year y is now calc at year y - 1 and stored in
	// phenologyMapOfNextYear
	private HashMap<Integer, HetPhenology> phenologyMapOfNextYear;

	// fa-5.7.2017
	private int refVegetationPeriodLength; // Length of the vegetation period
											// corresponding to previous
											// radiative balance run
											// (Samsaralight)
	private int currentVegetationPeriodLength; // Length of the vegetation
												// period for current year
	// fa-6.7.2017
	private int nextYearVegetationPeriodLength; // Length of the vegetation
												// period for next year

	// fc+mj-9.3.2017 added integrative variables at the scene level
	private double grossPrimaryProduction_gC_m2;
	private double netPrimaryProduction_gC_m2;
	private double maintenanceRespiration_gC_m2;
	private double retranslocation_gC_m2;

	// fc+mj+br-4.10.2018 regeneration library connection
	private double regenerationGrossPrimaryProduction_gC_m2;
	private double regenerationNetPrimaryProduction_gC_m2;

	// Optional, only if ip.fineResolutionRadiativeBalanceActivated, related to
	// photosynthesis at hourly level
	private HetVegetationPeriod vegetationPeriod;
	private HetVegetationPeriod vegetationPeriodOfNextYear;

	// Optional, only if ip.fineResolutionRadiativeBalanceActivated, the
	// beamSetFactory which beams were used for the radiative balance on this
	// scene, changed every n years with n = ip.radiationCalculationTimeStep
	private HetBeamSetFactoryOptimized beamSetFactory; // for optimized tag mode
//	private HetBeamSetFactory beamSetFactory; // fa-09.08.2017: for non-optimized tag mode

	private double crownProjectionSum_stand;

	// mj+fa-05.03.2018
	private HashMap<String, Double> q10SumMap;
	private HashMap<Integer, Double> q10SumMapLeaf;
	private HashMap<Integer, Double> q10SumMapFineRoot;

	// fa+mj-20.03.2018
	private HashMap<Integer, Double> meanUpperCrownHeightMap;
	private HashMap<Integer, Double> meanLowerCrownHeightMap;

	/**
	 * Constructor
	 */
	public HetScene() {
		super();

		// Create a default plot
//		setPlot(new DefaultPlot());
//		getPlot().setScene(this);

		this.waterBalanceMap = new LinkedHashMap<>(); // Linked: keep insertion
		// order

	}

	/**
	 * Returns the sum of trees leaf areas.
	 */
	public double getLeafArea () {

		// fc+mj+br-1.10.2018 see HetWaterBalanceCalculator

		double leafArea_stand = 0;

		for (Iterator i = this.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			leafArea_stand += t.getLeafArea();
		}
		return leafArea_stand;
	}

	@Override
	public HetPlot getPlot () {return (HetPlot) super.getPlot ();}	// optional
//	@Override
//	public PlotOfCells getPlot () {return (PlotOfCells) super.getPlot ();}	// optional

	@Override
	public HetScene getEvolutionBase() {

		HetScene eb = (HetScene) super.getEvolutionBase(); // calls
		// getLightClone ()

		// fc+mj+fa-28.6.2017 transfer next year pheno into eb
		// e.g. 2001.setPheno (2000.nextPheno)
		eb.setPhenologyMap(this.getPhenologyMapOfNextYear());
		eb.setPhenologyMapOfNextYear(null);

		// fc+mj+fa-29.6.2017 same for vegetation period
		eb.setVegetationPeriod(this.getVegetationPeriodOfNextYear());
		eb.setVegetationPeriodOfNextYear(null);

		// fc-9.5.2017
		Cell c1 = this.getPlot().getCell(1);
		Cell c2 = eb.getPlot().getCell(1);
		if (c1 == c2)
			HetReporter.printInStandardOutput("HetScene getEvolutionBase () WARNING: cell 1 in this.plot and cloned plot is the same object !");

		return eb;

	}

	/**
	 * Clone a HetScene with the super method and, next, add the variable that
	 * are not primitive
	 *
	 * @author gl 23-5-2013
	 */
	public Object clone() {
		try {
			HetScene s = (HetScene) super.clone();

			// copy the sensors that are not primitive
			List<SLSensor> copiedsensors = new ArrayList<SLSensor>();
			if (this.sensors != null) {
				for (SLSensor sensor : this.sensors) {
					SLSensor copiedSensor = sensor.getCopy();
					copiedsensors.add(copiedSensor);
				}
				s.sensors = copiedsensors;
			}

			// fc-7.9.2016 was missing during evolution (warning: soil is
			// optional, depends on user's choice at start time, provides a soil
			// file or not)
			if (this.soil != null)
				s.soil = new HetSoil(this.soil);

			return s;

		} catch (Exception exc) {
			Log.println(Log.ERROR, "HetScene.clone ()", "Exception caught, source scene=" + this, exc);
			return null;
		}
	}

	/**
	 * Returns a complete copy of the HetScene with its trees, soil, horizons,
	 * sensors and water balance list.
	 */
	public HetScene getInterventionBase() { // nb-15.12.2016

		// Copy the GScene containing clones of every tree
		// The super.getInterventionBase() instruction calls the above clone()
		// method
		// which creates a new sensors list and a new soil for the copied scene.
		// So, here,
		// it is not to handle the sensors and the soil.
		HetScene copiedScene = (HetScene) super.getInterventionBase();

		// fc+mj+fa-28.6.2017 transfer pheno and next year pheno into ib
		// e.g. *2002.setNextPheno (2002.nextPheno)
		copiedScene.setPhenologyMapOfNextYear(this.getPhenologyMapOfNextYear());
		copiedScene.setPhenologyMap(this.getPhenologyMap());

		// fc+mj+fa-29.6.2017 same for vegetationPeriod
		copiedScene.setVegetationPeriodOfNextYear(this.getVegetationPeriodOfNextYear());
		copiedScene.setVegetationPeriod(this.getVegetationPeriod());

		// Processing with variables of non primitive type
		copiedScene.waterBalanceMap = new LinkedHashMap<>();
		for (String key : this.waterBalanceMap.keySet()) {
			HetWaterBalance refWaterBalance = this.waterBalanceMap.get(key); // fc-20.1.2017
			// now
			// a
			// Map
			copiedScene.waterBalanceMap.put(key, refWaterBalance.getCopy());
		}

		// Processing with variables which value is set to 0 in the HetHorizon
		// per copy constructor.
		List<HetHorizon> copiedHorizonList = copiedScene.soil.getHorizons();
		for (HetHorizon copiedHorizon : copiedHorizonList) {

			// Using the id to identify a horizon
			HetHorizon refHorizon = this.soil.getHorizon(copiedHorizon.id);

			copiedHorizon.solution_pH = refHorizon.solution_pH;
			copiedHorizon.totalFineRootLength = refHorizon.totalFineRootLength;

			for (String elementName : refHorizon.getSolutionConcentrations().keySet()) {
				double refConcentration = refHorizon.getSolutionConcentration(elementName);
				copiedHorizon.setSolutionConcentration(elementName, refConcentration);
			}

			for (String elementName : refHorizon.getMineralConcentrations().keySet()) {
				double refConcentration = refHorizon.getMineralConcentration(elementName);
				copiedHorizon.setMineralConcentration(elementName, refConcentration);
			}

			for (String elementName : refHorizon.getExchangeableCationConcentrations().keySet()) {
				double refConcentration = refHorizon.getExchCationConcentration(elementName);
				copiedHorizon.setExchCationConcentration(elementName, refConcentration);
			}

			for (String elementName : refHorizon.getExchangeableAnionConcentrations().keySet()) {
				double refConcentration = refHorizon.getExchAnionConcentration(elementName);
				copiedHorizon.setExchAnionConcentration(elementName, refConcentration);
			}

		}

		return copiedScene;
	}

	/**
	 * Returns a leaf area development proportion in [0, 1] for any given doy in
	 * the year and the given species. If pheno is not found, return 1.
	 */
	public double getLadProportionOfNextYear(int speciesId, int doy) {
		// fa+fc-01.08.2017
		// fc+mj-12.9.2017 changed name method: ofNextYear
		if (doy == 366) // leap year
			return 0;

		try {
			// fc+mj+fa-28.6.2017 refactored, we now return values of next
			// year
			HetPhenology pheno = phenologyMapOfNextYear.get(speciesId);
			// HetPhenology pheno = phenologyMap.get(speciesId);

			if (pheno == null)
				throw new Exception("Error in HetScene " + this
						+ ", getLadProportionOfNextYear () could not find an HetPhenology for speciesId: " + speciesId);

			return pheno.getLadProportion(doy);

		} catch (Exception e) {
			// fc+mj+fa-31.7.2017 return 1 if no phenology
			// (phenology is optional)
			return 1;
		}
	}

	// fa-19.06.2017
	/**
	 * Returns a green leaf proportion in [0, 1] for any given doy in the year
	 * and the given species. If pheno is not found, return 1.
	 */
	public double getGreenProportionOfNextYear(int speciesId, int doy) {
		// fa+fc-01.08.2017
		// fc+mj-12.9.2017 changed name method: ofNextYear
		if (doy == 366) // leap year
			return 0;

		try {
			// fc+mj+fa-28.6.2017 refactored, we now return values of next year
			HetPhenology pheno = phenologyMapOfNextYear.get(speciesId);
			// HetPhenology pheno = phenologyMap.get(speciesId);

			if (pheno == null)
				throw new Exception("Error in HetScene " + this
						+ ", getGreenProportionOfNextYear () could not find an HetPhenology for speciesId: " + speciesId);

			return pheno.getGreenProportion(doy);

		} catch (Exception e) {
			// fc+mj+fa-31.7.2017 return 1 if no phenology
			// (phenology is optional)
			return 1;
		}
	}

	// public List<Vertex2d> getMainRectangle () { //GL 8/3/13
	// return mainRectangle;
	// }

	// public void setMainRectangle (List<Vertex2d> mainRectangle) { //GL 8/3/13
	// this.mainRectangle = mainRectangle;
	//
	// for (Iterator i = mainRectangle.iterator (); i.hasNext ();) {
	// Vertex2d v = (Vertex2d) i.next ();
	// System.out.println ("HetScene mainRectangle: "+v);
	// }
	//
	// }

	// Accessors
	public void addSensor(SLSensor sensor) {
		if (sensors == null) {
			sensors = new ArrayList<SLSensor>();
		}
		sensors.add(sensor);
	}

	public List<SLSensor> getSensors() {
		return sensors;
	}

	public double getNAvailable_kg() {
		return NAvailable_kg;
	}

	public void setNAvailable_kg(double nAvailable_kg) {
		NAvailable_kg = nAvailable_kg;
	}

	public double getNStandUptake() {
		return NStandUptake;
	}

	public void setNStandUptake(double nStandUptake) {
		NStandUptake = nStandUptake;
	}

	public double getNStandOptimalUptake() {
		return NStandOptimalUptake;
	}

	public void setNStandOptimalUptake(double nStandOptimalUptake) {
		NStandOptimalUptake = nStandOptimalUptake;
	}

	@Override
	public String toString() {
		return "HetScene_" + getCaption();
	}

	@Override
	public List<SquareCell> getCellstoEnlight() {
		// TODO FP Auto-generated method stub
		return null;
	}

	public void setSoil(HetSoil soil) {
		this.soil = soil;
	}

	public HetSoil getSoil() {
		return soil;
	}

	// fc+mj+lw-8.9.2016
	public boolean isSoilHorizonsAvailable() {
		// soil is optional
		// soil may be null, or it may contain only horizons without chemistry
		try {
			// If we can find a NON empty solution concentration map in 1st
			// horizon, chemistry was loaded
			return soil.getHorizon(1) != null;
		} catch (Exception e) {
			// if soil is null, no 1st horizon found... no horizons
			return false;
		}
	}

	// fc+mj+lw-8.9.2016
	public boolean isSoilChemistryAvailable() {
		// soil is optional
		// soil may be null, or it may contain only horizons without chemistry
		try {
			// If we can find a NON empty solution concentration map in 1st
			// horizon, chemistry was loaded
			return !soil.getHorizon(1).getSolutionConcentrations().isEmpty();
		} catch (Exception e) {
			// if soil is null, no 1st horizon found... no chemistry
			return false;
		}
	}

	public void updateHorizonFineRootLengths() {
		if (soil == null)
			return;

		for (HetHorizon h : soil.getHorizons()) {
			h.totalFineRootLength = 0;

			for (Tree tree : getTrees()) {
				HetTree t = (HetTree) tree;
				double horizonFineRootLength = h.fineRootProportion * t.getFineRootLength();
				h.totalFineRootLength += horizonFineRootLength;
			}

		}

	}

	public HetElementState getLitterNutrientReturn() {
		// Estimate exchangeable stocks per soil horizon
		HetElementState standLitterNutrientReturn = new HetElementState();
		// We do not consider here the trees cut by an intervener extension
		List<Tree> list = new ArrayList<>(this.getTrees());
		list.addAll(this.getTrees("dead"));
		list.addAll(this.getTrees("cut"));

		for (Tree t : list) {
			HetTree refTree = (HetTree) t;

			for (HetLitterCompartment lc : refTree.getLitterCompartments()) {

				for (String eName : HetTreeElement.elementNames) {
					double value = lc.getNutrientFlux(eName);

					standLitterNutrientReturn.addValue(eName, value);

				}
			}
		}

		return standLitterNutrientReturn;
	}

	public double[] getDailyGPP_kgC() {
		return dailyGPP_kgC;
	}

	public void setDailyGPP_kgC(double[] dailyGPP_kgC) {
		this.dailyGPP_kgC = dailyGPP_kgC;
	}

	public double[] getDailyMaintenanceLeafRespiration_kgC() {
		return dailyMaintenanceLeafRespiration_kgC;
	}

	public void setDailyMaintenanceLeafRespiration_kgC(double[] dailyMaintenanceLeafRespiration_kgC) {
		this.dailyMaintenanceLeafRespiration_kgC = dailyMaintenanceLeafRespiration_kgC;
	}

	public double getBarkAbsorbedRadiation() {
		return barkAbsorbedRadiation;
	}

	public void setBarkAbsorbedRadiation(double barkAbsorbedRadiation) {
		this.barkAbsorbedRadiation = barkAbsorbedRadiation;
	}

	public double getBarkAbsorbedDirectRadiation() {
		return barkAbsorbedDirectRadiation;
	}

	public void setBarkAbsorbedDirectRadiation(double barkAbsorbedDirectRadiation) {
		this.barkAbsorbedDirectRadiation = barkAbsorbedDirectRadiation;
	}

	public double getBarkAbsorbedDiffuseRadiation() {
		return barkAbsorbedDiffuseRadiation;
	}

	public void setBarkAbsorbedDiffuseRadiation(double barkAbsorbedDiffuseRadiation) {
		this.barkAbsorbedDiffuseRadiation = barkAbsorbedDiffuseRadiation;
	}

	public double getStandIncidentGlobalRadiation() {
		return standIncidentGlobalRadiation;
	}

	public void setStandIncidentGlobalRadiation(double standIncidentGlobalRadiation) {
		this.standIncidentGlobalRadiation = standIncidentGlobalRadiation;
	}

	public void setStandIncidentDirectRadiation(double standIncidentDirectRadiation) {
		this.standIncidentDirectRadiation = standIncidentDirectRadiation;
	}

	public double getStandIncidentDirectRadiation() {
		return standIncidentDirectRadiation;
	}

	public void setStandIncidentDiffuseRadiation(double standIncidentDiffuseRadiation) {
		this.standIncidentDiffuseRadiation = standIncidentDiffuseRadiation;
	}

	public double getStandIncidentDiffuseRadiation() {
		return standIncidentDiffuseRadiation;
	}

	// Year pheno
	public HashMap<Integer, HetPhenology> getPhenologyMap() {
		return phenologyMap;
	}

	public void setPhenologyMap(HashMap<Integer, HetPhenology> phenologyMap) {
		this.phenologyMap = phenologyMap;
	}

	// fc+mj+fa-28.6.2017 added next year pheno
	// pheno of year y is now calc at year y - 1 and stored in
	// phenologyMapOfNextYear
	public HashMap<Integer, HetPhenology> getPhenologyMapOfNextYear() {
		return phenologyMapOfNextYear;
	}

	public void setPhenologyMapOfNextYear(HashMap<Integer, HetPhenology> nextYearPhenologyMap) {
		this.phenologyMapOfNextYear = nextYearPhenologyMap;
	}

	public void setGrossPrimaryProduction_gC_m2(double grossPrimaryProduction_gC_m2) {
		this.grossPrimaryProduction_gC_m2 = grossPrimaryProduction_gC_m2;
	}

	public double getGrossPrimaryProduction_gC_m2() {
		return grossPrimaryProduction_gC_m2;
	}

	public void setNetPrimaryProduction_gC_m2(double netPrimaryProduction_gC_m2) {
		this.netPrimaryProduction_gC_m2 = netPrimaryProduction_gC_m2;
	}

	public double getNetPrimaryProduction_gC_m2() {
		return netPrimaryProduction_gC_m2;
	}

	public double getRegenerationGrossPrimaryProduction_gC_m2() {
		return regenerationGrossPrimaryProduction_gC_m2;
	}

	public void setRegenerationGrossPrimaryProduction_gC_m2(double regenerationGrossPrimaryProduction_gC_m2) {
		this.regenerationGrossPrimaryProduction_gC_m2 = regenerationGrossPrimaryProduction_gC_m2;
	}

	public double getRegenerationNetPrimaryProduction_gC_m2() {
		return regenerationNetPrimaryProduction_gC_m2;
	}

	public void setRegenerationNetPrimaryProduction_gC_m2(double regenerationNetPrimaryProduction_gC_m2) {
		this.regenerationNetPrimaryProduction_gC_m2 = regenerationNetPrimaryProduction_gC_m2;
	}

	public void setMaintenanceRespiration_gC_m2(double maintenanceRespiration_gC_m2) {
		this.maintenanceRespiration_gC_m2 = maintenanceRespiration_gC_m2;
	}

	public double getMaintenanceRespiration_gC_m2() {
		return maintenanceRespiration_gC_m2;
	}

	public void setRetranslocation_gC_m2(double retranslocation_gC_m2) {
		this.retranslocation_gC_m2 = retranslocation_gC_m2;
	}

	public double getRetranslocation_gC_m2() {
		return retranslocation_gC_m2;
	}

	public void setVegetationPeriod(HetVegetationPeriod vegetationPeriod) {
		this.vegetationPeriod = vegetationPeriod;
	}

	public HetVegetationPeriod getVegetationPeriod() {
		return vegetationPeriod;
	}

	public void setVegetationPeriodOfNextYear(HetVegetationPeriod vegetationPeriodOfNextYear) {
		this.vegetationPeriodOfNextYear = vegetationPeriodOfNextYear;
	}

	public HetVegetationPeriod getVegetationPeriodOfNextYear() {
		return vegetationPeriodOfNextYear;
	}

	// fa-5.7.2017
	public void setCurrentVegetationPeriodLength(int currentVegetationPeriodLength) {
		this.currentVegetationPeriodLength = currentVegetationPeriodLength;
	}

	public int getCurrentVegetationPeriodLength() {
		return currentVegetationPeriodLength;
	}

	public void setRefVegetationPeriodLength(int refVegetationPeriodLength) {
		this.refVegetationPeriodLength = refVegetationPeriodLength;
	}

	public int getRefVegetationPeriodLength() {
		return refVegetationPeriodLength;
	}

	// fa-6.7.2017
	public void setNextYearVegetationPeriodLength(int nextYearVegetationPeriodLength) {
		this.nextYearVegetationPeriodLength = nextYearVegetationPeriodLength;
	}

	public int getNextYearVegetationPeriodLength() {
		return nextYearVegetationPeriodLength;
	}

	// mj+fa-20.09.2017
	public void setCrownProjectionSum_stand(double crownProjectionSum_stand) {
		this.crownProjectionSum_stand = crownProjectionSum_stand;
	}

	public double getCrownProjectionSum_stand() {
		return crownProjectionSum_stand;
	}

	//
	// /**
	// * Check if the given doy is in vegetation period. In FineResolutionMode,
	// * check in the scene's HetVegetationPeriod (null if not fineResolution),
	// * otherwise, check in the SamsaraLight model
	// */
	// public boolean isVegetationPeriod(HetVegetationPeriod vegetationPeriod,
	// HetSamsaFileLoader samsaFileLoader, int doy) {
	//
	// // fc+fa-18.5.2017
	// if (vegetationPeriod != null)
	// return vegetationPeriod.isVegetationPeriod(doy);
	// else
	// return samsaFileLoader.isVegetationPeriod(doy);
	//
	// }

	// fc+fa-04.08.2017: optimized tag mode
	public void setBeamSetFactory(HetBeamSetFactoryOptimized beamSetFactory) {
		this.beamSetFactory = beamSetFactory;
	}

	// fc+fa-04.08.2017: optimized tag mode
	public HetBeamSetFactoryOptimized getBeamSetFactory() {
		return beamSetFactory;
	}

	// fa-09.08.2017: for non-optimized tag mode
//	public void setBeamSetFactory(HetBeamSetFactory beamSetFactory) {
//		this.beamSetFactory = beamSetFactory;
//	}

	// fa-09.08.2017: for non-optimized tag mode
//	public HetBeamSetFactory getBeamSetFactory() {
//		return beamSetFactory;
//	}

//	private HashMap<String, Double> q10SumMap;
//	private HashMap<Integer, Double> q10SumMapLeaf;
//	private HashMap<Integer, Double> q10SumMapFineRoot;

	// fa-06.03.2018
	public void setQ10SumMap(HashMap<String, Double> q10SumMap) {
		this.q10SumMap = q10SumMap;
	}

	// fa-06.03.2018
	public HashMap<String, Double> getQ10SumMap() {
		return q10SumMap;
	}

	// fa-06.03.2018
	public void setQ10SumMapLeaf(HashMap<Integer, Double> q10SumMapLeaf) {
		this.q10SumMapLeaf = q10SumMapLeaf;
	}

	// fa-06.03.2018
	public HashMap<Integer, Double> getQ10SumMapLeaf() {
		return q10SumMapLeaf;
	}

	// fa-06.03.2018
	public void setQ10SumMapFineRoot(HashMap<Integer, Double> q10SumMapFineRoot) {
		this.q10SumMapFineRoot = q10SumMapFineRoot;
	}

	// fa-06.03.2018
	public HashMap<Integer, Double> getQ10SumMapFineRoot() {
		return q10SumMapFineRoot;
	}

	// fa+mj-20.03.2018
	public void setMeanUpperCrownHeightMap(HashMap<Integer, Double> meanUpperCrownHeightMap) {
		this.meanUpperCrownHeightMap = meanUpperCrownHeightMap;
	}

	// fa+mj-20.03.2018
	public HashMap<Integer, Double> getMeanUpperCrownHeightMap() {
		return meanUpperCrownHeightMap;
	}

	// fa+mj-20.03.2018
	public void setMeanLowerCrownHeightMap(HashMap<Integer, Double> meanLowerCrownHeightMap) {
		this.meanLowerCrownHeightMap = meanLowerCrownHeightMap;
	}

	// fa+mj-20.03.2018
	public HashMap<Integer, Double> getMeanLowerCrownHeightMap() {
		return meanLowerCrownHeightMap;
	}

}
