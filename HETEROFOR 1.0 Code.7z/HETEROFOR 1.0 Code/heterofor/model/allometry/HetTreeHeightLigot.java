package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing tree height based on diameter.
 *
 * @author G. Ligot, M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetTreeHeightLigot extends HetSimpleFunction {

	private double a;
	private double b;
	private double m;

	/**
	 * Constructor.
	 */
	public HetTreeHeightLigot(String str) throws Exception { // e.g.
		// treeHeightLigot(-1.6;32.73;31.52)
		if (!str.startsWith("treeHeightLigot(")) {
			throw new Exception("HetTreeHeightLigot error, string should start with \"treeHeightLigot(\": " + str);
		}
		String s = str.replace("treeHeightLigot(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		m = Check.doubleValue(st.nextToken());

		if (b == 0)
			throw new Exception("Error in HetTreeHeightLigot, parameter b must be != 0: " + str);
		if (m == 0)
			throw new Exception("Error in HetTreeHeightLigot, parameter m must be != 0: " + str);
	}

	/**
	 * Calculates height (m) from dbh (cm).
	 */
	@Override
	public double result(double dbh_cm) {

		double height_m = m * (1 - Math.exp(-(dbh_cm - a) / b));

		return height_m;

	}

	/**
	 * Calculates dbh (cm) from height (m).
	 */
	public double getDbh(double height_m) {

		// height_m must be under m (max height) 
		if (height_m > m - 2)
			height_m = m - 2;
		
		double dbh_cm = -b * Math.log((-height_m / m) + 1) + a;

		return dbh_cm;

	}

	public String toString() {
		return "treeHeightLigot(" + a + ";" + b + ";" + m + ")";
	}

}
