package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling LAI from h(m)
 * Return the leaf area index LAI
 * 
 * @author B. Ryelandt - April 2019
 */
public class HetSeedlingHeightToLAI extends HetSimpleFunction {

	private double k;

	/**
	 * Constructor.
	 */
	public HetSeedlingHeightToLAI(String str) throws Exception {

		if (!str.startsWith("seedlingHeightToLAI(")) {
			throw new Exception(
					"HetSeedlingHeightToLAI error, string should start with \"seedlingHeightToLAI(\": "
							+ str);
		}
		String s = str.replace("seedlingHeightToLAI(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		k = Check.doubleValue(st.nextToken());
	}

	/**
	 * Returns HetSeedlingHeightToLAI.
	 */
	public double result(double height_m) {

		return (6d * height_m) / (k + height_m);

	}

	public String toString() {
		return "seedlingHeightToLAI(" + k + ")";
	}

}   
