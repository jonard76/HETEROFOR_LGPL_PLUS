package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling height from diameter and transmittance
 * Return the height (m)
 * 
 * @author B. Ryelandt - April 2019
 */
public class HetSeedlingDiameterToHeight extends HetFunction2Variables {
//seedlingDiameterToHeight(b,s,a,b0,b1)


	private double b;
	private double threshold; //threshold
	private double a;
	private double b0;
	private double b1;

	/**
	 * Constructor.
	 */
	public HetSeedlingDiameterToHeight(String str) throws Exception {

		// e.g. seedlingDiameterToHeight(80.1122;-7.80176;0)

		if (!str.startsWith("seedlingDiameterToHeight(")) {
			throw new Exception(
					"HetSeedlingDiameterToHeight error, string should start with \"seedlingDiameterToHeight(\": "
							+ str);
		}
		String s = str.replace("seedlingDiameterToHeight(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		b = Check.doubleValue(st.nextToken());
		threshold = Check.doubleValue(st.nextToken());
		a = Check.doubleValue(st.nextToken());
		b0 = Check.doubleValue(st.nextToken());
		b1 = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns seedlingHeightToDiameterRatio.
	 */
	public double result(double transmittance, double diameter_cm) {

		if (diameter_cm < threshold){

			return b * diameter_cm;		

		}else{

		return a + (b0 + b1 * transmittance) * diameter_cm;

		}

	}

	public String toString() {
		return "seedlingDiameterToHeight(" + b + ";" + threshold + ";" + a + ";" + b0 + ";" + b1 + ")";
	}

}
