package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling biomass aerial from h(m) and d5(cm)
 * Return the total biomass (kgOM)
 * 
 * @author B. Ryelandt - April 2019
 */
public class HetSeedlingGetBiomass extends HetFunction2Variables {

	private double a;

	/**
	 * Constructor.
	 */
	public HetSeedlingGetBiomass(String str) throws Exception {

		if (!str.startsWith("seedlingGetBiomass(")) {
			throw new Exception(
					"HetSeedlingGetBiomass error, string should start with \"seedlingGetBiomass(\": "
							+ str);
		}
		String s = str.replace("seedlingGetBiomass(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
	}

	/**
	 * Returns HetSeedlingGetBiomass.
	 */
	public double result(double height_m, double diameter_cm) {

		return a * height_m * diameter_cm * diameter_cm;

	}

	public String toString() {
		return "seedlingGetBiomass(" + a + ")";
	}

}  
