package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function to compute the girth at 10% of the tree height. Dagnelie et al.
 * 1999
 * 
 * @author M. Jonard - November 2017
 */
public class HetTenPcHeightGirth implements Serializable {

	public double a;
	public double b;
	public double c;
	public double d;
	public double e;
	public double f;

	/**
	 * Constructor.
	 */
	public HetTenPcHeightGirth(String str) throws Exception { // e.g.
																// tenPcHeightGirth(3.9330;1.0284;-0.31611E-3;0.44036E-6;-0.33113;-0.28051E-5)
		if (!str.startsWith("tenPcHeightGirth(")) {
			throw new Exception("tenPcHeightGirth error, string should start with \"tenPcHeightGirth(\": " + str);
		}
		String s = str.replace("tenPcHeightGirth(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());
		e = Check.doubleValue(st.nextToken());
		f = Check.doubleValue(st.nextToken());

	}

	/**
	 * Calculates the function
	 */
	public double result(double girth_cm, double height_m) {

		double res = a + b * girth_cm + c * girth_cm * girth_cm + d * girth_cm * girth_cm * girth_cm + e * height_m + f
				* girth_cm * girth_cm * height_m;

		return res;
	}

	public String toString() {
		return "tenPcHeightGirth(" + a + ";" + b + ";" + c + ";" + d + ";" + e + ";" + f + ")";
	}

}
