
 /*
  * The HETEROFOR model.
  *
  * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
  *
  * This file is part of the HETEROFOR model and is free software: you can redistribute it and/or
  * modifiy it under the terms of the GNU Lesser General Public License as published by the
  * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;


/**
 * An estimation function for the crown to stem diameter ratio.
 *
 * @author M. Jonard - November 2013
 */
public class CrownToStemDiameterEstimation extends HetSimpleFunction implements Serializable {
	public double a;
	public double b;
	public double c;
	public double d; // mg / g

	/**
	 * Constructor.
	 */
	public CrownToStemDiameterEstimation (String str) throws Exception { // e.g. crownToStemDiameterEstimation(1.2;2.23;1.25;520)
		if (!str.startsWith ("crownToStemDiameterEstimation(")) {
			throw new Exception ("CrownToStemDiameterEstimation error, string should start with \"crownToStemDiameterEstimation(\": "+str);
		}
		String s = str.replace ("crownToStemDiameterEstimation(", "");
		s= s.replace (')', ' ');
		s = s.trim ();
		StringTokenizer st = new StringTokenizer (s, " ;");
		a = Check.doubleValue (st.nextToken ());
		b = Check.doubleValue (st.nextToken ());
		c = Check.doubleValue (st.nextToken ());
		d = Check.doubleValue (st.nextToken ());

	}

	/**
	 * Calculates the allometry for the given values.
	 */
	public double result (double c130_cm) {

		double c130Inv = 1d / c130_cm;

		double res = a + b * c130_cm + c * c130Inv + d * (c130Inv * c130Inv);

		return res;
	}

	public String toString () {
		return "crownToStemDiameterEstimation("+a+";"+b+";"+c+";"+d+")";
	}

}
