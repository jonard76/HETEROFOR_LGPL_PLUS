package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the radiation modifier for stomatal conductance from specific leaf radiation absorption
 * Return the radiation modifier (-)
 * 
 * @author F. Andr� June 2019
 */
public class HetRadiationModifier implements Serializable {

	public double a;

	/**
	 * Constructor.
	 */
	public HetRadiationModifier(String str) throws Exception {

		// e.g. radiationModifier(37.2)

		if (!str.startsWith("radiationModifier(")) {
			throw new Exception(
					"HetRadiationModifier error, string should start with \"radiationModifier(\": "
							+ str);
		}
		String s = str.replace("radiationModifier(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		
	}

	/**
	 * Returns radiationModifier.
	 */
	public double result(double leafRadiation_m2leaf) {

		return leafRadiation_m2leaf / (leafRadiation_m2leaf + a);

	}
	
	public String toString() {
		return "radiationModifier(" + a + ")";
	}

} 
