 /*
  * The HETEROFOR model.
  *
  * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
  *
  * This file is part of the HETEROFOR model and is free software: you can redistribute it and/or
  * modifiy it under the terms of the GNU Lesser General Public License as published by the
  * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing bark proportion.
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - October 2016
 */
public class HetBarkProportionFunction extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetBarkProportionFunction(String str) throws Exception { // e.g.
																	// barkProportionFunction(0.08;-0.26;0.32478)
		if (!str.startsWith("barkProportionFunction(")) {
			throw new Exception(
					"HetBarkProportionFunction error, string should start with \"barkProportionFunction(\": " + str);
		}
		String s = str.replace("barkProportionFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}


	/**
	 * The diameter: of the stem or of branch compartments.
	 */
	@Override
	public double result(double diameter) { // cm

		double woodProportion = a + b * Math.exp(c * diameter);
		double barkProportion = 1 - woodProportion;

		barkProportion = Math.min(1, Math.max (0, barkProportion));

		return barkProportion;

	}

	public String toString() {
		return "barkProportionFunction(" + a + ";" + b + ";" + c + ")";
	}



}
