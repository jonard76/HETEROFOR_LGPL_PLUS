/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.fineresolutionradiativebalance;

import java.io.Serializable;

/**
 * A line with average radiation information calculated from corresponding meteo
 * lines from several consecutive years
 *
 * These lines are stored in an HetAverageRadiation object.
 *
 * @author F. André, F. de Coligny - April 2017
 */
public class HetAverageRadiationLine implements Serializable {

	public int month;
	public int doy;
	public int hour;
	public double globalRadiation_MJm2; //
	public double diffuseToGlobalRatio; // [0, 1]

	/**
	 * Constructor
	 */
	public HetAverageRadiationLine(int month, int doy, int hour, double radiation_MJm2, double diffuseToGlobalRatio) {
		this.month = month;
		this.doy = doy;
		this.hour = hour;

		this.globalRadiation_MJm2 = radiation_MJm2;
		this.diffuseToGlobalRatio = diffuseToGlobalRatio;

	}

	public String toString () {
		return "HetAverageRadiationLine"
				+" month: "+month
				+" doy: "+doy
				+" hour: "+hour
				+" globalRadiation_MJm2: "+globalRadiation_MJm2
				+" diffuseToGlobalRatio: "+diffuseToGlobalRatio;
	}

}
