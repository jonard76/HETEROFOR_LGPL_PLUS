/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.fineresolutionradiativebalance;

import heterofor.model.HetReporter;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.phenology.HetPhenologyDate;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;

/**
 * A container for HetAverageRadiationLines.
 *
 * @author F. André, F. de Coligny - April 2017
 */
public class HetAverageRadiation implements Serializable {

	//private static final String SEP = "_";

	static public class Key implements Comparable, Serializable {
		public int doy;
		public int hour;

		public Key(int doy, int hour) {
			this.doy = doy;
			this.hour = hour;
		}

		@Override
		public int compareTo(Object o) {
			Key otherKey = (Key) o;
			int val = doy * 1000 + hour;
			int otherVal = otherKey.doy * 1000 + otherKey.hour;
			return val - otherVal;
		}

		// fc-9.6.2017
		@Override
		public int hashCode() {
			return doy * 1000 + hour;
		}

		// fc-9.6.2017
		@Override
		public boolean equals(Object other) {
			return this.hashCode() == other.hashCode();
		}

		public String toString() {
			return "HetAverageRadiation doy: " + doy + " hour: " + hour;
		}

	}

	private int startYear;
	private int endYear;
	private HetMeteorology meteo;

	private Map<Key, HetAverageRadiationLine> radiationMap;

	/**
	 * Constructor
	 */
	public HetAverageRadiation(int startYear, int endYear, HetMeteorology meteo) throws Exception {
		this.startYear = startYear;
		this.endYear = endYear;
		this.meteo = meteo;

		run();

	}

	private void run() throws Exception {

		HetReporter.printInStandardOutput("HetAverageRadiation.run ()...");

		// We keep the insertion order: LinkedHashMap
		radiationMap = new LinkedHashMap<>();

		List<Iterator> averageRadiations = new ArrayList<>();

		HetReporter.printInStandardOutput("HetAverageRadiation.run ()...");

		for (int y = startYear; y <= endYear; y++) {

			ArrayList<HetMeteoLine> lines = meteo.getMeteoLines(y);
			averageRadiations.add(lines.iterator());

			HetReporter.printInStandardOutput("   year: " + y + " meteo lines: " + lines.size());

		}

		int n = endYear - startYear + 1;

		boolean moreLines = true;
		int doy = 0;

		try {

			while (moreLines) {

				double sum_radiation = 0;
				double sum_diffuseToGlobalRatio = 0;

				int month = 0;
				int hour = 0;

				// Next line for all years, sum values
				for (Iterator i : averageRadiations) {
					HetMeteoLine line = (HetMeteoLine) i.next();

					doy = HetPhenologyDate.getDayOfYear(line.year, line.month, line.day);

					month = line.month;
					hour = line.hour;
					sum_radiation += line.radiation;
					sum_diffuseToGlobalRatio += line.diffuseToGlobalRatio;

					// System.out.println("   summing lines for doy: " + doy +
					// ", month: " + month + " and hour: " + hour
					// + ", line.radiation: " + line.radiation +
					// ", line.diffuseToGlobalRatio: "
					// + line.diffuseToGlobalRatio);

					if (!i.hasNext())
						moreLines = false;
				}

				// Calculate average values
				double radiation_MJm2 = sum_radiation * 3600d / 1000000d / n; // W/m2
																				// ->
				// MJ/m2
				double diffuseToGlobalRatio = sum_diffuseToGlobalRatio / n;

				HetAverageRadiationLine radLine = new HetAverageRadiationLine(month, doy, hour, radiation_MJm2,
						diffuseToGlobalRatio);
				radiationMap.put(new Key(doy, hour), radLine);

			}
		} catch (Exception e) {
			throw new Exception("Error in HetAverageRadiation at doy: " + doy, e);
		}

	}

	public Map<Key, HetAverageRadiationLine> getRadiationMap() {
		return radiationMap;
	}

	/**
	 * Returns the incident global radiation for the given period and hour.
	 */
	public double getIncidentGlobalRadiation(int startDoy, int endDoy, int hour) throws RuntimeException {
		double sumGlobalRadiation_MJm2 = 0;

		for (int doy = startDoy; doy <= endDoy; doy++) {
			sumGlobalRadiation_MJm2 += getIncidentGlobalRadiation(doy, hour);
		}

		return sumGlobalRadiation_MJm2;
	}

	//fa-22.6.2017
	/**
	 * Returns the incident direct radiation for the given period and hour.
	 */
	public double getIncidentDirectRadiation(int startDoy, int endDoy, int hour) throws RuntimeException {
		double sumDirectRadiation_MJm2 = 0;

		for (int doy = startDoy; doy <= endDoy; doy++) {
			sumDirectRadiation_MJm2 += getIncidentDirectRadiation(doy, hour);
		}

		return sumDirectRadiation_MJm2;
	}

	//fa-22.6.2017
	/**
	 * Returns the incident diffuse radiation for the given period and hour.
	 */
	public double getIncidentDiffuseRadiation(int startDoy, int endDoy, int hour) throws RuntimeException {
		double sumDiffuseRadiation_MJm2 = 0;

		for (int doy = startDoy; doy <= endDoy; doy++) {
			sumDiffuseRadiation_MJm2 += getIncidentDiffuseRadiation(doy, hour);
		}

		return sumDiffuseRadiation_MJm2;
	}

	/**
	 * Returns the incident global radiation for the given doy and hour.
	 */
	public double getIncidentGlobalRadiation(int doy, int hour) throws RuntimeException {
		HetAverageRadiationLine line = radiationMap.get(new Key(doy, hour));

		//// fa-31.05.2017 - for test
		//System.out.println("getIncidentGlobalRadiation, hour: " + hour + ", doy: " + doy + ", radiation: " + line);

		if (line == null) {
			Log.println(traceRadiationap()); // fc-9.6.2017
			throw new RuntimeException(
					"Error in HetAverageRadiation, calculateIncidentGlobalRadiation() could not get the average line for doy: "
							+ doy + ", hour: " + hour);
		}

		return line.globalRadiation_MJm2;
	}

	//fa-22.6.2017
	/**
	 * Returns the incident direct radiation for the given doy and hour.
	 */
	public double getIncidentDirectRadiation(int doy, int hour) throws RuntimeException {
		HetAverageRadiationLine line = radiationMap.get(new Key(doy, hour));

		if (line == null) {
			Log.println(traceRadiationap()); // fc-9.6.2017
			throw new RuntimeException(
					"Error in HetAverageRadiation, calculateIncidentDirectRadiation() could not get the average line for doy: "
							+ doy + ", hour: " + hour);
		}

		return line.globalRadiation_MJm2 * (1 - line.diffuseToGlobalRatio);
	}

	//fa-22.6.2017
	/**
	 * Returns the incident diffuse radiation for the given doy and hour.
	 */
	public double getIncidentDiffuseRadiation(int doy, int hour) throws RuntimeException {
		HetAverageRadiationLine line = radiationMap.get(new Key(doy, hour));

		if (line == null) {
			Log.println(traceRadiationap()); // fc-9.6.2017
			throw new RuntimeException(
					"Error in HetAverageRadiation, calculateIncidentDiffuseRadiation() could not get the average line for doy: "
							+ doy + ", hour: " + hour);
		}

		return line.globalRadiation_MJm2 * line.diffuseToGlobalRatio;
	}

	public List<HetAverageRadiationLine> getLines(int doy) {
		ArrayList<HetAverageRadiationLine> list = new ArrayList<>();
		for (HetAverageRadiationLine line : radiationMap.values()) {
			if (line.doy == doy)
				list.add(line);
		}

		return list;

	}

	/**
	 * Returns the average radiation lines in a list map which Key is month.
	 */
	public ListMap<Integer, HetAverageRadiationLine> getRadiationsPerMonth() {

		ListMap<Integer, HetAverageRadiationLine> radiationsPerMonth = new ListMap<>();

		for (HetAverageRadiationLine line : radiationMap.values()) {
			radiationsPerMonth.addObject(line.month, line);
		}
		return radiationsPerMonth;
	}

	// fc-9.6.2017
	public String traceRadiationap() {
		StringBuffer b = new StringBuffer("HetAverageRadiation.radiationMap...");
		if (radiationMap == null)
			b.append("   radiationMap = null");
		else if (radiationMap.isEmpty())
			b.append("   radiationMap is empty");
		else {
			for (Key k : new TreeSet<>(radiationMap.keySet())) {
				HetAverageRadiationLine line = radiationMap.get(k);
				b.append("\n   " + k.doy + "." + k.hour + ": " + line);
			}
			b.append("\n   -> " + radiationMap.size() + " lines.");
		}

		return b.toString();
	}

}
