package heterofor.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import heterofor.model.HetInventoryLoader.CohortRecord;
import jeeb.lib.util.TicketDispenser;

/**
 * A manager to handle the regeneration cohorts creation along the simulation.
 * Called on root scene and then every year in case some cohorts must be added
 * every year.
 * 
 * @author M. Jonard, B. Ryelandt, F. de Coligny
 */
public class HetRegenerationCohortsManager implements Serializable {

	private boolean yearlyRegenerationCohortsEmergence;
	private List<CohortRecord> cohortRecords;
	
	// A way to get unique ids for the regeneration cohorts
	private TicketDispenser cohortSizeClassIdDispenser;
	
	/**
	 * Constructor.
	 */
	public HetRegenerationCohortsManager(boolean yearlyRegenerationCohortsEmergence, 
			List<CohortRecord> cohortRecords) {

		this.yearlyRegenerationCohortsEmergence = yearlyRegenerationCohortsEmergence;
		this.cohortRecords = cohortRecords;
		
		cohortSizeClassIdDispenser = new TicketDispenser();

	}

	
	/**
	 * Creates the regeneration cohorts on the given scene.
	 */
	public void run (HetInitialParameters ip, HetScene scene) {
		Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap();
		
		boolean initialScene = scene.isInitialScene();
		
		for (CohortRecord r : cohortRecords) {

			boolean addCohorts = initialScene || (yearlyRegenerationCohortsEmergence && r.year == 1);
			
			if (!addCohorts)
				continue; // jump to next cohort
			
			HetPlot plot = (HetPlot) scene.getPlot();

			List targetCells = new ArrayList();

			// Which cell for this cohort ?
			if (r.i >= 0 && r.j >= 0) {
				HetCell cell = (HetCell) plot.getCell(r.i, r.j);
				targetCells.add(cell);
			} else {
				// Assign cohort to all cells if both indices are -1
				targetCells.addAll(plot.getCells());
			}

			for (Object tc : targetCells) {

				HetCell targetCell = (HetCell) tc;

				HetSpecies species = speciesMap.get(r.speciesId);
				HetCohort c = new HetCohort(species, r.year);

				for (Iterator iC = r.classes.iterator(); iC.hasNext();) {
					CohortRecord.Token token = (CohortRecord.Token) iC.next();

					int newId = cohortSizeClassIdDispenser.next();

					double heightAvg = new Double(token.b);
					double diameterAvg = new Double(token.c);
					int number = new Integer((int) token.d);

					HetCohortSizeClass sizeClass = new HetCohortSizeClass(newId, c, heightAvg, diameterAvg, number);
					c.addSizeClass(sizeClass);

				}

				targetCell.addCohort(c);

			}

		}

	}
	
	
}
