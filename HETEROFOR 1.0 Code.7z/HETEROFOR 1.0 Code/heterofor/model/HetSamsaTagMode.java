/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import heterofor.model.fineresolutionradiativebalance.HetBeamSetFactory;
import heterofor.model.fineresolutionradiativebalance.HetBeamSetFactoryOptimized;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.vegetationperiod.HetVegetationPeriod;

import java.util.TreeSet;

import capsis.lib.samsaralight.SLBeamSet;
import capsis.lib.samsaralight.SLModel;

/**
 * A manager for the SamsaraLight radiative balance process in Heterofor: tag
 * mode for more fine resolution, with additional tagged beams around particular
 * dates, possibly related to phenology (bud burst date...).
 *
 * @author F. de Coligny - June 2017
 */
public class HetSamsaTagMode extends HetSamsaManager {

	/**
	 * Constructor with phenology activated, takes a HetMeteorology and a
	 * HetVegetationPeriod
	 */
	public HetSamsaTagMode(HetSamsaFileLoader samsaFileLoader, int radiationCalculationTimeStep, HetScene scene,
			double treeMaxHeight, double maxCrownRadius, HetMeteorology meteorology,
			HetVegetationPeriod vegetationPeriod, TreeSet<Integer> thinningDates, int dateOfInitialScene, SLModel slModel) throws Exception { //fa-05.01.2018: added thinningDates & dateOfInitialScene

		// Super constructor creates slModel and slSettings
		super(samsaFileLoader, radiationCalculationTimeStep, slModel);

		slSettings.setTagMode(true);

		// fc+fa-27.4.2017 BeamSet creation in fine resolution mode
		// Create beamSet, valid for 3 years (if radiationCalculationTimeStep =
		// 3)
		// int startYear = scene.getDate();
		int startYear = scene.getDate() + 1; // fa-7.7.2017: +1 as processLighting occurs at the end of evolution loop, therefore for next year(s)
		int endYear = startYear + radiationCalculationTimeStep - 1; // default
		//fa-05.01.2018: the current date is not a multiple of radiationCalculationTimeStep (because true thinning or intervention occurred)
		if ((scene.getDate() - dateOfInitialScene) % radiationCalculationTimeStep != 0d) {
			double ellapsedTimeStepFraction = (double) (scene.getDate() - dateOfInitialScene) / radiationCalculationTimeStep - Math.floor((scene.getDate() - dateOfInitialScene) / radiationCalculationTimeStep);
			double remainingTimeStepFraction = 1.0 - ellapsedTimeStepFraction;
			endYear = (int) (startYear + remainingTimeStepFraction * radiationCalculationTimeStep - 1);
		}
		//fa-05.01.2018: if true thinning WILL occur within the current radiationCalculationTimeStep
		if (thinningDates != null && thinningDates.ceiling(startYear) != null && thinningDates.ceiling(startYear) <= endYear) {
			endYear = thinningDates.ceiling(startYear);
		}

		// Create a custom beamSet
		HetBeamSetFactoryOptimized beamSetFactory = new HetBeamSetFactoryOptimized(startYear, endYear, vegetationPeriod, meteorology,
				slSettings); // fc+fa-3.8.2017
//		HetBeamSetFactory beamSetFactory = new HetBeamSetFactory(startYear, endYear, vegetationPeriod, meteorology,
//				slSettings);

		// Memo factory in the scene, available for 3 years
		scene.setBeamSetFactory(beamSetFactory); // MAYBE NOT NEEDED
													// fc-29.6.2017

		// Create a custom beamSet (includes neighbourhoods system reseting)
		SLBeamSet beamSet = beamSetFactory.getBeamSet();
		double cellWidth = ((HetPlot) scene.getPlot()).getCellWidth();

		slModel.setBeamSet(beamSet, scene, treeMaxHeight, cellWidth, maxCrownRadius);

	}

	// processLighting() is in HetSamsaManager superclass

}
