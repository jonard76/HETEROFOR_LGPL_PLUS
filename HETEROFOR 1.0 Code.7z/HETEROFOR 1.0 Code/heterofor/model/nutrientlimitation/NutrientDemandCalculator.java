/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.nutrientlimitation;

import heterofor.model.HetElementState;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetReporter;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import jeeb.lib.util.Log;

import java.util.List;
import java.util.Random;

/**
 * Compute tree nutrient requirement, retranslocation and demand.
 *
 * @author M. Jonard - May 2016
 */
public class NutrientDemandCalculator {
	private HetInitialParameters ip;
	private Random random;
	private HetScene refScene;
	private HetTree refTree;
	private HetTree newTree;

	private HetElementState requirement;
	private HetElementState retranslocation;
	private HetElementState demand;

	/**
	 * Constructor.
	 */
	public NutrientDemandCalculator(HetInitialParameters ip, Random random, HetScene refScene, HetTree refTree, HetTree newTree) {
		this.ip = ip;
		this.random = random;
		this.refScene = refScene;
		this.refTree = refTree;
		this.newTree = newTree;

		requirement = new HetElementState();
		retranslocation = new HetElementState();
		demand = new HetElementState();

	}

	public void execute () {

//		// Soil chemistry is optional
//		if (!refScene.isSoilChemistryAvailable())
//			return;

		HetSpecies sp = refTree.getSpecies();

		for (String eName : HetTreeElement.elementNames) {

			// Element requirement sums on compartments (13)
			for (HetTreeCompartment tc : refTree.getTreeCompartments()) {
				// double Cconc = tc.getConcentration(HetTreeElement.C) /
				// 1000d; // g/g = Kg/Kg
				double Cconc = 0.5;
				double req = tc.getConcentration(eName) * tc.getBiomassProduction(refTree, newTree) / Cconc;

				if (Double.isNaN (req)) {
					HetReporter.printInLog("NutrientDemandCalculator.execute () req: NaN *** eName: "+eName+" tc.getConcentration(eName): "+tc.getConcentration(eName)
								+" tc.getBiomassProduction(refTree, newTree): "+tc.getBiomassProduction(refTree, newTree)+" tc: "+tc);
				}

				requirement.addValue(eName, req); // req in g.
			}

			// Element retranslocation sums on compartments (13)

			// Leaf retranslocation
			List<HetTreeCompartment> leafComps = refTree.getTreeCompartmentsForType(HetTreeCompartment.TYPE_LEAF);
			double leafBiomass = 0;
			double leafNutrientAmount = 0;

			for (HetTreeCompartment c : leafComps) {
				leafBiomass += c.biomass;
				leafNutrientAmount += c.biomass * c.getConcentration(eName);
			}
			double avgLeafConcentration = leafNutrientAmount / leafBiomass;

			HetLitterCompartment lc = refTree.getLitterCompartment(HetLitterCompartment.LEAVES);
			// double Cconc = lc.getConcentration(HetTreeElement.C) / 1000d;
			// // g/g = Kg/Kg
			double Cconc = 0.5;
			double leafLitterFall = lc.biomass / Cconc; // Kg_OM
			double leafLitterConc = lc.getConcentration(eName);

			double leafNutrientRetranslocation = ((leafLitterFall / (1 - sp.leafRetranslocationRate)) * avgLeafConcentration)
					- (leafLitterFall * leafLitterConc); // g
			// fc+mj-7.12.2016
			leafNutrientRetranslocation = leafNutrientRetranslocation < 0 ? 0 : leafNutrientRetranslocation;

			// Fine root retranslocation
			HetTreeCompartment frc = refTree.getTreeCompartment(HetTreeCompartment.ROOTS_FINE);
			double fineRootConc = frc.getConcentration(eName);

			lc = refTree.getLitterCompartment(HetLitterCompartment.FINE_ROOTS);
			// Cconc = lc.getConcentration(HetTreeElement.C) / 1000d; // g/g
			// = Kg/Kg
			Cconc = 0.5;
			double fineRootLitterFall = lc.biomass / Cconc; // Kg_OM
			double fineRootLitterConc = lc.getConcentration(eName);

			double fineRootNutrientRetranslocation = ((fineRootLitterFall / (1 - sp.fineRootRetranslocationRate)) * fineRootConc)
					- (fineRootLitterFall * fineRootLitterConc); // g
			// fc+mj-7.12.2016
			fineRootNutrientRetranslocation = fineRootNutrientRetranslocation < 0 ? 0 : fineRootNutrientRetranslocation;

			double nutrientRetranslocation = leafNutrientRetranslocation + fineRootNutrientRetranslocation; // g

			retranslocation.addValue(eName, nutrientRetranslocation);

			// Element demand: requirement - retranslocation (13)
			double demand_g = requirement.getValue(eName) - retranslocation.getValue(eName);

			if (Double.isNaN(requirement.getValue(eName)))
				HetReporter.printInLog("NutrientDemandCalculator *NaN*: requirement.getValue(eName) for eName: "+eName);
			if (Double.isNaN(retranslocation.getValue(eName)))
				HetReporter.printInLog("NutrientDemandCalculator *NaN*: retranslocation.getValue(eName) for eName: "+eName);

			demand.setValue(eName, demand_g);

		}

//		System.out.println("tree: " + refTree.getId());
//		System.out.println("   treeRequirement:     " + requirement);
//		System.out.println("   treeRetranslocation:  " + retranslocation);
//		System.out.println("   treeDemand:            " + demand);
//		System.out.println();

	}

	public HetElementState getRequirement() {
		return requirement;
	}
	public HetElementState getRetranslocation() {
		return retranslocation;
	}
	public HetElementState getDemand() {
		return demand;
	}


}
