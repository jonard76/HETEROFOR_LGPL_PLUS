/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetHydraulicPedotransferParameters;
import heterofor.model.soil.HetInverseVanGenuchten;
import heterofor.model.soil.HetMualemVanGenuchten;
import heterofor.model.soil.HetSoil;
import heterofor.model.soil.HetVanGenuchten;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import jeeb.lib.util.AdditionMap;
import jeeb.lib.util.AmapTools;

/**
 * Calculates the hourly water content for each horizon.
 *
 * @author M. Jonard, Louis de Wergifosse, F. de Coligny - October 2016
 */
public class HetHorizonsWaterContentCalculator {

	static private boolean traceOn = false;

	private Map<Integer, Double> zeroRootWaterUptakeMap; // fc+mj-14.9.2017

	private static class HydraulicProperties implements Comparable {

		public int hId;
		public HetHorizon horizon;
		public double prevWaterContent;
		public HetHydraulicPedotransferParameters pedoParams;
		public double K; // (cm/day)
		public double prevMatricPotential; // cm
		public double prevWaterPotential; // cm

		// List of water quantity sorted by descending order of water
		// accessibility
		public List<Double> availableWaterList; // l

		/**
		 * Constructor
		 */
		public HydraulicProperties() {
			availableWaterList = new ArrayList<>();
		}

		/**
		 * Copy constructor
		 */
		public HydraulicProperties(HydraulicProperties original) {
			// fc+mj-14.9.2017
			this.hId = original.hId;
			this.horizon = original.horizon; // not copied
			this.prevWaterContent = original.prevWaterContent;
			this.pedoParams = new HetHydraulicPedotransferParameters(original.pedoParams);
			this.K = original.K;
			this.prevMatricPotential = original.prevMatricPotential;
			this.prevWaterPotential = original.prevWaterPotential;

			this.availableWaterList = new ArrayList<>(original.availableWaterList);

		}

		// Natural ordering: ascending prevMatricPotential
		// fc+mj-8.3.2017 was ordered on prevWaterPotential
		@Override
		public int compareTo(Object o) {
			HydraulicProperties other = (HydraulicProperties) o;

			if (prevMatricPotential < other.prevMatricPotential)
				return -1;
			else if (prevMatricPotential > other.prevMatricPotential)
				return 1;
			else
				return hId - other.hId;
		}

		// // Natural ordering: ascending prevWaterPotential
		// @Override
		// public int compareTo(Object o) {
		// HydraulicProperties other = (HydraulicProperties) o;
		//
		// if (prevWaterPotential < other.prevWaterPotential)
		// return -1;
		// else if (prevWaterPotential > other.prevWaterPotential)
		// return 1;
		// else
		// return hId - other.hId;
		// }

		@Override
		public String toString() {
			return "HydraulicProperties hId: " + hId + " prevWaterContent: " + prevWaterContent + " pedoParams: "
					+ pedoParams + " K: " + K + " prevMatricPotential: " + prevMatricPotential + " prevWaterPotential: "
					+ prevWaterPotential + " availableWaterList: " + AmapTools.toString(availableWaterList);
		}

	}

	private HetScene refScene;
	private HetScene newScene;
	private HetSoil refSoil;
	private HetSoil newSoil;

	// A convenient map
	private Map<Integer, HydraulicProperties> hPropMap;

	private double deepDrainage;

	/**
	 * Constructor
	 */
	public HetHorizonsWaterContentCalculator(HetScene refScene, HetScene newScene) {
		this.refScene = refScene;
		this.newScene = newScene;
		this.refSoil = refScene.getSoil();
		this.newSoil = newScene.getSoil();
	}

	/**
	 * Creates the hydraulic properties map for all horizons
	 */
	private void createHPropMap(Map<Integer, HetHorizon> newHorizons, Map<Integer, Double> prevHorizonsWaterContent) {
		hPropMap = new HashMap<>();

		List<Integer> sortedHorizonIds = new ArrayList<>(new TreeSet<>(newHorizons.keySet()));
		int idTop = sortedHorizonIds.get(0);
		HetHorizon hTop = refSoil.getHorizon(idTop); // top horizon //
														// fc+mj-14.9.2017
		// HetHorizon hTop = newHorizons.get(idTop); // WRONG, horizons are not
		// ordered here

		// Loop on Horizons from top to bottom
		for (int hId : sortedHorizonIds) {

			HetHorizon h = newHorizons.get(hId);

			HydraulicProperties prop = new HydraulicProperties();

			prop.hId = h.id;
			prop.horizon = h;

			prop.prevWaterContent = prevHorizonsWaterContent.get(hId);

			prop.pedoParams = new HetHydraulicPedotransferParameters(h);
			prop.pedoParams.execute();

			prop.K = new HetMualemVanGenuchten(h, prop.pedoParams, prop.prevWaterContent).execute(); //fa+lw-02.07.2019
//			prop.K = new HetMualemVanGenuchtenVogel(h, prop.pedoParams, prop.prevWaterContent).execute();

			prop.prevMatricPotential = new HetInverseVanGenuchten(h, prop.pedoParams, prop.prevWaterContent).execute();
//			prop.prevMatricPotential = new HetInverseVanGenuchtenVogel(h, prop.pedoParams, prop.prevWaterContent).execute(); // fa+lw-02.07.2019

			prop.prevWaterPotential = (hTop.upperLimit - (h.upperLimit + h.lowerLimit) / 2d) * 100d
					+ prop.prevMatricPotential;

			hPropMap.put(hId, prop);

			//HetReporter.printInStandardOutput("Horizon #" + hId + ", prevWaterPotential = " + prop.prevWaterPotential + ", K = " + prop.K);


		}

	}

	private boolean firstTrace = true;

	/**
	 * Computes the transpiration distribution between horizons and therefore
	 * provides root water uptake for each horizon.
	 * 17.06.2019, Based on Couvreur et al. (2012), improved version using createRootWaterUptakeMap3 approach if not enough extractable water in some horizons
	 */
//	private Map<Integer, Double> createRootWaterUptakeMap5(double transpiration) {
	private Map<Integer, Double> createRootWaterUptakeMap5(double transpiration, Map<Integer, HetHorizon> newHorizons, Map<Integer, Double> prevHorizonsWaterContent) { //fa-18.06.2019

		double standTranspiration = transpiration * refScene.getArea();

		if (standTranspiration <= 0) {

			// Create zero map first time only
			if (zeroRootWaterUptakeMap == null) {
				zeroRootWaterUptakeMap = new HashMap<>();
				for (int hId : hPropMap.keySet())
					zeroRootWaterUptakeMap.put(hId, 0d);
			}

			// 0 for each horizon
			return zeroRootWaterUptakeMap;
		}

		Map<Integer, Double> rootWaterUptakeMap = new HashMap<>();
		Map<Integer, Double> extractableWaterQuantityMap = new HashMap<>();

		double extractableWaterQuantitySum = 0d;

//		double weightedMeanPrevWaterPotential = 0d;
//		for (int hId : hPropMap.keySet()) {
//			HydraulicProperties hProp = hPropMap.get(hId);
//
//			HetHorizon h = refSoil.getHorizon(hId);
//			weightedMeanPrevWaterPotential += hProp.prevWaterPotential * h.fineRootProportion;
//		}
		double weightedMeanPrevWaterPotential = this.calculateWeightedMeanWaterPotential (newHorizons, prevHorizonsWaterContent); //fa-18.06.2019

		for (int hId : hPropMap.keySet()) {

			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);

			double extractableWaterQuantity = (hProp.prevWaterContent - h.wiltingPointWaterContent) * 998d * h.volume
					* refScene.getArea() * (1d - h.additionalCoarseFraction);
			extractableWaterQuantityMap.put(hId, extractableWaterQuantity);
			extractableWaterQuantitySum += extractableWaterQuantity;
		}

		double remainingWaterToAssign = Math.min(standTranspiration, extractableWaterQuantitySum);

		extractableWaterQuantitySum = 0d;
		for (int hId : hPropMap.keySet()) {

			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);

			double fineRootProportion = h.fineRootProportion;

			double expectedWaterUptake = remainingWaterToAssign * fineRootProportion
					+ (refSoil.getCompensatoryEffectConductance() * 3600d
							* (hProp.prevWaterPotential - weightedMeanPrevWaterPotential) / 100d * 1000d
							* fineRootProportion) * refScene.getArea();

			rootWaterUptakeMap.put(hId, Math.min(expectedWaterUptake, extractableWaterQuantityMap.get(hId)));

			remainingWaterToAssign -= rootWaterUptakeMap.get(hId);

			extractableWaterQuantityMap.put(hId, extractableWaterQuantityMap.get(hId) - rootWaterUptakeMap.get(hId)); // update after uptake
			extractableWaterQuantitySum += extractableWaterQuantityMap.get(hId);

		}

		if (remainingWaterToAssign >= 0d) {
			for (int hId : hPropMap.keySet()) {
				if (extractableWaterQuantitySum == 0d)
					rootWaterUptakeMap.put(hId, rootWaterUptakeMap.get(hId) + extractableWaterQuantityMap.put(hId, 0d));
				else
					rootWaterUptakeMap.put(hId, rootWaterUptakeMap.get(hId) + extractableWaterQuantityMap.get(hId) / extractableWaterQuantitySum * remainingWaterToAssign);
			}
		}

		return rootWaterUptakeMap;
	}

	/**
	 * Computes the transpiration distribution between horizons and therefore
	 * provides root water uptake for each horizon.
	 * Based on Couvreur et al. (2012)
	 */
	private Map<Integer, Double> createRootWaterUptakeMap4(double transpiration) {
		Map<Integer, Double> rootWaterUptakeMap = new HashMap<>();
		// fc+mj-14.9.2017
		double standTranspiration = transpiration * refScene.getArea();

		if (standTranspiration <= 0) {

			// Create zero map first time only
			if (zeroRootWaterUptakeMap == null) {
				zeroRootWaterUptakeMap = new HashMap<>();
				for (int hId : hPropMap.keySet())
					zeroRootWaterUptakeMap.put(hId, 0d);
			}

			// 0 for each horizon
			return zeroRootWaterUptakeMap;
		}

		double extractableWaterQuantitySum = 0d;
		for (int hId : hPropMap.keySet()) {

			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);

			double extractableWaterQuantity = (hProp.prevWaterContent - h.wiltingPointWaterContent) * 998d * h.volume
					* refScene.getArea() * (1d - h.additionalCoarseFraction);
			extractableWaterQuantitySum += extractableWaterQuantity;
		}

		double remainingWaterToAssign = Math.min(standTranspiration, extractableWaterQuantitySum);

		double weightedMeanPrevWaterPotential = 0d;

		for (int hId : hPropMap.keySet()) {
			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);
			weightedMeanPrevWaterPotential += hProp.prevWaterPotential * h.fineRootProportion;
		}

		// Loop on hPropMap
		for (int hId : hPropMap.keySet()) {

			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);

			double fineRootProportion = h.fineRootProportion;

			double expectedWaterUptake = remainingWaterToAssign * fineRootProportion
					+ (refSoil.getCompensatoryEffectConductance() * 3600d
							* (hProp.prevWaterPotential - weightedMeanPrevWaterPotential) / 100d * 1000d
							* fineRootProportion) * refScene.getArea();

			// double actualWaterUptake = Math.min(availableWaterQuantity,
			// expectedWaterUptake);
			rootWaterUptakeMap.put(hId, expectedWaterUptake);
		}

		return rootWaterUptakeMap;
	}

	/**
	 * Computes the transpiration distribution between horizons and therefore
	 * provides root water uptake for each horizon.
	 * Based on horizon extractable water
	 */
	private Map<Integer, Double> createRootWaterUptakeMap3(double transpiration) {
		// fc+mj-14.9.2017
		Map<Integer, Double> rootWaterUptakeMap = new HashMap<>();

		double standTranspiration = transpiration * refScene.getArea();

		if (standTranspiration <= 0) {

			// Create zero map first time only
			if (zeroRootWaterUptakeMap == null) {

				zeroRootWaterUptakeMap = new HashMap<>();
				for (int hId : hPropMap.keySet())
					zeroRootWaterUptakeMap.put(hId, 0d);
			}

			// 0 for each horizon
			return zeroRootWaterUptakeMap;
		}

		Map<Integer, Double> extractableWaterQuantitys = new HashMap<>();
		double extractableQuantitySum = 0d;

		for (int hId : hPropMap.keySet()) {
			HydraulicProperties hProp = hPropMap.get(hId);
			HetHorizon h = refSoil.getHorizon(hId);

			double extractableWaterQuantity = (hProp.prevWaterContent - h.wiltingPointWaterContent) * 998d * h.volume
					* refScene.getArea() * (1d - h.additionalCoarseFraction);

			extractableWaterQuantity = Math.max(extractableWaterQuantity, 0);

			extractableWaterQuantitys.put(hId, extractableWaterQuantity);
			extractableQuantitySum += extractableWaterQuantity;

		}

		standTranspiration = Math.min(extractableQuantitySum, standTranspiration);

		for (int hId : hPropMap.keySet()) {
			HydraulicProperties hProp = hPropMap.get(hId);
			HetHorizon h = refSoil.getHorizon(hId);

			double horizonWaterUptake = extractableWaterQuantitys.get(h.id) / extractableQuantitySum * standTranspiration;

			rootWaterUptakeMap.put(h.id, horizonWaterUptake);

		}

		return rootWaterUptakeMap;
	}

	/**
	 * Computes the transpiration distribution between horizons and therefore
	 * provides root water uptake for each horizon.
	 * Based on Couvreur et al. (2012). NOT FINALIZED HERE, see createRootWaterUptakeMap4 & createRootWaterUptakeMap5
	 */
	private Map<Integer, Double> createRootWaterUptakeMap2(double transpiration) {
		Map<Integer, Double> rootWaterUptakeMap = new HashMap<>();
		// fc+mj-14.9.2017
		double standTranspiration = transpiration * refScene.getArea();

		if (standTranspiration <= 0) {

			// Create zero map first time only
			if (zeroRootWaterUptakeMap == null) {
				zeroRootWaterUptakeMap = new HashMap<>();
				for (int hId : hPropMap.keySet())
					zeroRootWaterUptakeMap.put(hId, 0d);
			}

			// 0 for each horizon
			return zeroRootWaterUptakeMap;
		}

		List<Integer> sortedHorizonIds = new ArrayList<>(new TreeSet<>(refSoil.getHorizonMap().keySet()));
		int idTop = sortedHorizonIds.get(0);
		HetHorizon hTop = refSoil.getHorizon(idTop); // top horizon //
														// fc+mj-14.9.2017
		// HetHorizon hTop = refSoil.getHorizons().get(idTop); // WRONG,
		// horizons are not ordered here

		// Copy hPropMap and the hProps inside
		// Create a fineRootProportionMap
		Map<Integer, HydraulicProperties> hPropMapCopy = new HashMap<>();
		Map<Integer, Double> fineRootProportionMap = new HashMap<>();
		for (int hId : hPropMap.keySet()) {
			HydraulicProperties hProp = hPropMap.get(hId);

			HydraulicProperties hPropCopy = new HydraulicProperties(hProp);
			hPropMapCopy.put(hId, hPropCopy);

			fineRootProportionMap.put(hId, hProp.horizon.fineRootProportion);
		}

		double remainingWaterContentToAssign = standTranspiration;

		int securityCounter = 0;
		while (remainingWaterContentToAssign > 0 && ++securityCounter <= 10) {

			HetReporter.printInStandardOutput("HetHorizonsWaterContentCalculator while #" + securityCounter);

			double sum = 0d;

			for (int hId : hPropMapCopy.keySet()) {
				HydraulicProperties hProp = hPropMapCopy.get(hId);

				sum += hProp.prevWaterPotential;
			}

			int n = hPropMapCopy.size();
			double meanPrevWaterPotential = sum / n;

			// Loop on hPropMap copy
			double fineRootProportionSum = 0d;
			for (int hId : hPropMapCopy.keySet()) {
				// This is a copy, can be updated
				HydraulicProperties hProp = hPropMapCopy.get(hId);

				HetHorizon h = refSoil.getHorizon(hId);

				double availableWaterQuantity = (hProp.prevWaterContent - h.wiltingPointWaterContent) * 998d * h.volume
						* refScene.getArea() * (1d - h.additionalCoarseFraction);

				double fineRootProportion = fineRootProportionMap.get(hId);

				double expectedWaterUptake = remainingWaterContentToAssign * fineRootProportion
						+ (refSoil.getCompensatoryEffectConductance() * 3600d
								* (hProp.prevWaterPotential - meanPrevWaterPotential) / 100d / 1000d
								* fineRootProportion) * refScene.getArea();

				double actualWaterUptake = Math.min(availableWaterQuantity, expectedWaterUptake);

				// Update hProp (we work on a copy)
				hProp.prevWaterContent = hProp.prevWaterContent
						- actualWaterUptake / (998d * h.volume * refScene.getArea() * (1d - h.additionalCoarseFraction)); // m3/m3

				hProp.prevMatricPotential = new HetInverseVanGenuchten(h, hProp.pedoParams, hProp.prevWaterContent).execute(); //fa-lw-02.07.2019
//				hProp.prevMatricPotential = new HetInverseVanGenuchtenVogel(h, hProp.pedoParams, hProp.prevWaterContent)
//						.execute();

				hProp.prevWaterPotential = (hTop.upperLimit - (h.upperLimit + h.lowerLimit) / 2d) * 100d
						+ hProp.prevMatricPotential;

				// Update fineRootProportionMap (1)
				if (availableWaterQuantity - actualWaterUptake < 0)
					fineRootProportionMap.put(hId, 0d);
				fineRootProportionSum += fineRootProportionMap.get(hId);

				remainingWaterContentToAssign -= actualWaterUptake;

				rootWaterUptakeMap.put(hId, actualWaterUptake);
			}

			// Update fineRootProportionMap (2)
			if (fineRootProportionSum != 0)
				for (int hId : hPropMapCopy.keySet()) {
					double fineRootProportion = fineRootProportionMap.get(hId) / fineRootProportionSum;
					fineRootProportionMap.put(hId, fineRootProportion);
				}

		}

		return rootWaterUptakeMap;
	}

	/**
	 * Computes the transpiration distribution between horizons and therefore
	 * provides root water uptake for each horizon.
	 * Based on water accessibility estimated from the horizon water potential
	 */
	// Warning: water balance does not reach zero with this method

	private Map<Integer, Double> createRootWaterUptakeMap(double transpiration) {
		Map<Integer, Double> rootWaterUptakeMap = new HashMap<>();

		// Calculate waterPotential for each horizon
		// Map<Double, Integer> waterPotential_hId = new HashMap<>();

		double standTranspiration = transpiration * refScene.getArea();

		if (standTranspiration <= 0) {

			// Create zero map first time only
			if (zeroRootWaterUptakeMap == null) {
				zeroRootWaterUptakeMap = new HashMap<>();
				for (int hId : hPropMap.keySet())
					zeroRootWaterUptakeMap.put(hId, 0d);
			}

			// 0 for each horizon
			return zeroRootWaterUptakeMap;
		}

		if (standTranspiration > 0 && firstTrace)
			traceOn = true;

		if (traceOn)
			HetReporter.printInStandardOutput("HetHorizonsWaterContentCalculator.createRootWaterUptakeMap ()...");

		// Sort hProps on ascending prevWaterPotential
		List<HydraulicProperties> list = new ArrayList<>(new TreeSet<>(hPropMap.values()));
		int availableWaterListSize = 0;

		// for i == 8 (last horizon), we do not enter the loop on k, so we do
		// not calculate waterContent2. But we need to
		// keep the last value of waterContent2 to calculate
		// remainingAvailableWaterQuantity for i == 8
		double waterContent2_lastValue = 0;

		for (int i = 0; i < list.size(); i++) {

			HydraulicProperties hProp_i = list.get(i);
			int hId_i = hProp_i.hId;
			HetHorizon h_i = hProp_i.horizon;

			for (int j = 0; j < i; j++)
				hProp_i.availableWaterList.add(0d);

			double waterContent1 = hProp_i.prevWaterContent;
			double waterContent2 = 0;
			for (int k = i + 1; k < list.size(); k++) {

				// fc+mj-6.3.2017
				HydraulicProperties hProp_prev_k = list.get(k - 1);

				HydraulicProperties hProp_k = list.get(k);
				int hId_k = hProp_k.hId;
				HetHorizon h_k = hProp_k.horizon;

				// Water content for horizon i for matric potential of horizon
				// k-1
				waterContent1 = new HetVanGenuchten(h_i, hProp_i.pedoParams, hProp_prev_k.prevMatricPotential).execute(); //fa+lw-02.07.2019
//				waterContent1 = new HetVanGenuchtenVogel(h_i, hProp_i.pedoParams, hProp_prev_k.prevMatricPotential).execute();

				// Water content of horizon i for matric potential of horizon k
				double a = h_i.wiltingPointWaterContent;
				double b = new HetVanGenuchten(h_i, hProp_i.pedoParams, hProp_k.prevMatricPotential).execute();
				waterContent2 = Math.max(a, b);
				waterContent2_lastValue = waterContent2;

				double availableWaterQuantity = (waterContent1 - waterContent2) * 998d * h_i.volume * refScene.getArea()
						* (1d - h_i.additionalCoarseFraction);

				hProp_i.availableWaterList.add(availableWaterQuantity);

			}

			// Remaining available water
			double remainingAvailableWaterQuantity = (waterContent2_lastValue - h_i.wiltingPointWaterContent) * 998d
					* h_i.volume * refScene.getArea() * (1d - h_i.additionalCoarseFraction);
			hProp_i.availableWaterList.add(remainingAvailableWaterQuantity);

			availableWaterListSize = Math.max(availableWaterListSize, hProp_i.availableWaterList.size());

			// if (traceOn) { // only one single time (hour)
			// System.out.println("HetHorizonsWaterContentCalculator h1: ");
			// System.out.println(" " + hProp_i);
			// }

			if (traceOn)
				HetReporter.printInStandardOutput("i: " + i + "\n" + hProp_i);

		}

		// traceOn = false;

		// Re loop on horizons, sum the availableWaterList values
		List<Double> availableWaterSums = new ArrayList<>();
		// Init list to zero values
		for (int k = 0; k < availableWaterListSize; k++) {
			availableWaterSums.add(0d);
		}

		for (int i = 0; i < list.size(); i++) {

			HydraulicProperties hProp1 = list.get(i);

			// Are there roots ?
			if (hProp1.horizon.fineRootProportion > 0) {

				for (int k = 0; k < hProp1.availableWaterList.size(); k++) {
					Double v = availableWaterSums.get(k);
					if (v == null)
						v = 0d;
					availableWaterSums.set(k, v + hProp1.availableWaterList.get(k));
				}

			}

		}

		if (traceOn)
			HetReporter.printInStandardOutput("availableWaterSums: " + AmapTools.toString(availableWaterSums));

		//
		double extractableWaterQuantitySum = 0d;
		for (int hId : hPropMap.keySet()) {

			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);

			double extractableWaterQuantity = (hProp.prevWaterContent - h.wiltingPointWaterContent) * 998d * h.volume
					* refScene.getArea() * (1d - h.additionalCoarseFraction);
			extractableWaterQuantitySum += extractableWaterQuantity;
		}
		double remainingWaterUptakeToAssign = Math.min(standTranspiration, extractableWaterQuantitySum);

		int index = 0;
		for (index = 0; index < availableWaterSums.size(); index++) {

			double v = availableWaterSums.get(index);

			if (availableWaterSums.get(index) == 0) // mj+fa-8.9.2017
				continue;
			if (remainingWaterUptakeToAssign - v <= 0)
				break;

			remainingWaterUptakeToAssign -= v;

		}

		// if we did not break just upper, index was incremented one extra
		// time
		if (index >= availableWaterSums.size())
			index--;

		//
		double waterUptakeProportionAtIndex = 0;
		// int indexNext = index + 1;
		// if (indexNext < availableWaterSums.size()) {

		if (availableWaterSums.get(index) <= 0) // mj+fa-8.9.2017
			waterUptakeProportionAtIndex = 0;
		else
			waterUptakeProportionAtIndex = remainingWaterUptakeToAssign / availableWaterSums.get(index);

		// }

		// Order does not matter here
		for (int i = 0; i < list.size(); i++) {

			HydraulicProperties hProp_i = list.get(i);

			// Are there roots ?
			if (standTranspiration != 0 && hProp_i.horizon.fineRootProportion > 0) {

				double sum = 0;
				for (int k = 0; k < index; k++) {
					sum += hProp_i.availableWaterList.get(k);
				}

				sum += waterUptakeProportionAtIndex * hProp_i.availableWaterList.get(index);

				rootWaterUptakeMap.put(hProp_i.hId, sum);

			} else {
				rootWaterUptakeMap.put(hProp_i.hId, 0d);
			}
		}

		// // fc+mj+fa+lw-15.2.2017 TO BE REMOVED for test only
		// for (int hId : rootWaterUptakeMap.keySet ()) {
		// rootWaterUptakeMap.put(hId, 0d);
		// }
		// // fc+mj+fa+lw-15.2.2017 TO BE REMOVED for test only

		if (traceOn) {
			HetReporter.printInStandardOutput("standTranspiration: " + standTranspiration);
			HetReporter.printInStandardOutput("rootWaterUptakeMap: " + AmapTools.toString(rootWaterUptakeMap));

			traceOn = false;
			firstTrace = false;
		}

		return rootWaterUptakeMap;
	}

	/**
	 * Hourly process, takes a map giving for each horizon (hId) its water
	 * content for the previous hour. Returns a new Map with the new water
	 * content values for all horizons.
	 */
	public Map<Integer, Double> updateHorizonsWaterContent(Map<Integer, Double> prevHorizonsWaterContent,
			double stemflow, double throughfall, double transpiration, double soilEvaporation,
			AdditionMap waterError_horizon, double rainfall, double interception, int year, int month, int day,
			int hour) { // hourly,
		// fa-13.06.2019:
		// added
		// 'rainfall',
		// 'interception' & date

		Map<Integer, HetHorizon> newHorizons = newSoil.getHorizonMap();

		// HydraulicProperties for all horizons
		createHPropMap(newHorizons, prevHorizonsWaterContent);
		Map<Integer, HydraulicProperties> hPropMap_init = hPropMap; //fa-14.06.2019: copy of the hydraulic property map, to be used in case of iterations of the 'while' loop below

		// water content values for the new hour
		Map<Integer, Double> newHorizonsWaterContent = new HashMap<>();

		// fa+mj-13.06.2019: check water balance and adapt (reduce) stability
		// criteria if necessary
		boolean waterBalanceIsAcceptable = false;
		double stabilityCriteriaReductionFactor = 10d;
		double maxStabilityCriteriaReductionFactor = 1e3;
		double toleranceThreshold = 0.01; // mm
		double waterBalanceError = 0d;
		while (!waterBalanceIsAcceptable && stabilityCriteriaReductionFactor <= maxStabilityCriteriaReductionFactor) {

			//fa-14.06.2019: reset of hydraulic properties to initial values in case of new iteration of the while loop
			if (stabilityCriteriaReductionFactor > 10d)
				hPropMap = hPropMap_init;

			double upperDrainage = throughfall * refScene.getArea() + stemflow * refScene.getArea(); // l
			double upperSurplus = 0;
			double preferentialFlow = 0;
			double preferentialFlowProportion = refSoil.getPreferentialFlowProportion();
			double upperCapillaryRise = 0;

			// fa-30.09.2017: moved below
			// mj+fa-21.09.2017: For discretized time step
			// double upperCapillaryRise_ts = 0;
			// double upperDrainage_ts = 0;
			// double upperSurplus_ts = 0;

			double remainingSoilEvaporation = soilEvaporation * refScene.getArea();

			// fc+mj-17.9.2017 alternative method for root water uptake
			// Map<Integer, Double> rootWaterUptakeMap =
			// createRootWaterUptakeMap(transpiration);
			// Map<Integer, Double> rootWaterUptakeMap =
			// createRootWaterUptakeMap2(transpiration);
//			Map<Integer, Double> rootWaterUptakeMap = createRootWaterUptakeMap5(transpiration);
			Map<Integer, Double> rootWaterUptakeMap = createRootWaterUptakeMap5(transpiration, newHorizons, prevHorizonsWaterContent); //fa-18.06.2019
			// Map<Integer, Double> rootWaterUptakeMap =
			// createRootWaterUptakeMap4(transpiration); // simplified copy of
			// createRootWaterUptakeMap2

			// mj+fa-20.09.2017: time discretization criteria
			double globalStabilityCriteria = Double.MAX_VALUE;
			for (int hId : new TreeSet<>(newHorizons.keySet())) {
				// Horizon h
				HetHorizon h = newHorizons.get(hId);
				HydraulicProperties hProp = hPropMap.get(h.id);
				// double Kh = hProp.K; // cm/day
				double Kh = hProp.K * (1 - h.totalCoarseFraction); // cm/day //
																// mj+fa-25.04.2018

				double stabilityCriteria = prevHorizonsWaterContent.get(hId) * h.thickness
						/ (stabilityCriteriaReductionFactor * Kh / 100d / 24d / 3600d);
				globalStabilityCriteria = Math.min(stabilityCriteria, globalStabilityCriteria);
//				HetReporter.printInStandardOutput("Horizon #" + hId + ", Date " + day + "/" + month + "/" + year + " " + hour + ":00:00" + ", stabilityCriteriaReductionFactor = " + stabilityCriteriaReductionFactor + ", globalStabilityCriteria = " + globalStabilityCriteria + ", stabilityCriteria = " + stabilityCriteria + ", prevHorizonsWaterContent = " + prevHorizonsWaterContent.get(hId) + ", Kh = " + Kh);

			}
//			HetReporter.printInStandardOutput("Date " + day + "/" + month + "/" + year + " " + hour + ":00:00" + ", stabilityCriteriaReductionFactor = " + stabilityCriteriaReductionFactor + ", globalStabilityCriteria = " + globalStabilityCriteria);
			int timeStepNumber = (int) Math.floor(3600 / globalStabilityCriteria);
			if (timeStepNumber < 1)
				timeStepNumber = 1;

			Map<Integer, Double> prevHorizonsWaterContentTemp = new HashMap<>();
			Map<Integer, Double> drainageMap = new HashMap<>();
			for (int hId : prevHorizonsWaterContent.keySet()) {
				prevHorizonsWaterContentTemp.put(hId, prevHorizonsWaterContent.get(hId));

				drainageMap.put(hId, 0d);
			}

			// mj+fa-20.09.2017: time discretization loop
			// Horizons sorted on ascending hId
			for (int ts = 0; ts < timeStepNumber; ++ts) {

				// fa-30.09.2017: moved from above
				// mj+fa-21.09.2017: For discretized time step
				double upperCapillaryRise_ts = 0;
				double upperDrainage_ts = 0;
				double upperSurplus_ts = 0;

				createHPropMap(newHorizons, prevHorizonsWaterContentTemp);

				for (int hId : new TreeSet<>(newHorizons.keySet())) {

					HetHorizon h = newHorizons.get(hId);

					// hNext is the horizon below h
					// when h is the lowest horizon, hNext = h
					HetHorizon hNext = h; // special case
					int hIdNext = hId + 1;
					if (newHorizons.get(hIdNext) != null)
						hNext = newHorizons.get(hId + 1); // normal case

					double prevWaterContent_ts = prevHorizonsWaterContentTemp.get(hId);

					// Get hydraulic properties for h and hNext
					HydraulicProperties hProp = hPropMap.get(h.id);
					HydraulicProperties hNextProp = hPropMap.get(hNext.id);

					// Kh: hydraulic conductivity for h (cm/day)
					HetHydraulicPedotransferParameters pedoParams = hProp.pedoParams;
					// double Kh = hProp.K; // cm/day
					double Kh = hProp.K * (1 - h.totalCoarseFraction); // cm/day //
																	// mj+fa-25.04.2018
					double matricPotential = hProp.prevMatricPotential;
					// double waterPotential = hProp.prevWaterPotential;
					// //upwind mean//lw-07.02.19

					// KhNext: hydraulic conductivity for hNext (cm/day)
					// HetHydraulicPedotransferParameters hpParamsNext =
					// hNextProp.pedoParams;
					// double KhNext = hNextProp.K // cm/day
					double KhNext = hNextProp.K * (1 - h.totalCoarseFraction); // cm/day
																			// //
																			// mj+fa-25.04.2018
					double matricPotentialNext = hNextProp.prevMatricPotential;
					// double waterPotentialNext = hNextProp.prevWaterPotential;
					// //upwind mean//lw-07.02.19

					// fc+mj-8.3.2017
					// double K = Math.min(Kh, KhNext); // cm/day
//					double K = (Kh + KhNext) / 2d; // arithmetic
					// mean//lw-07.02.19

					double K = (h.thickness + hNext.thickness) / (h.thickness / Kh + hNext.thickness / KhNext); // harmonic
//																												// mean//lw-07.02.19

//					double K = Kh; //upwind mean//lw-07.02.19
					// if (waterPotentialNext >= waterPotential)
					// K = KhNext; //upwind mean//lw-07.02.19

//					 double K = (Kh * 1 / 2d * h.thickness + KhNext * 1 / 2d * hNext.thickness) / (1 / 2d * h.thickness + 1 / 2d * hNext.thickness);

					// deltaHdeltaZ cm/cm
					double deltaHdeltaZ = (matricPotentialNext - matricPotential)
							/ ((1 / 2d * h.thickness + 1 / 2d * hNext.thickness) * 100d); // fa-02.03.2017
																							// *100d:
																							// m
																							// ->
																							// cm
																							// if
																							// (deltaHdeltaZ
																							// >
																							// 20)
					// deltaHdeltaZ = 20;
					// if (deltaHdeltaZ < -20)
					// deltaHdeltaZ = -20;
					// fc+mj-7.3.2017 searching bug in drainage
					// deltaHdeltaZ = 0;
					// K = 0.2d;

					// drainage in l
					// 24 / 100 : cm/j -> m/timeStep
					// * 998 : m3 -> l
					double timeStepNumberDouble = (double) timeStepNumber;
					double drainage_ts = K / 24d / timeStepNumberDouble / 100d * (deltaHdeltaZ + 1) * refScene.getArea()
							* 998d;

					// Minimum K0 between h and hNext
					double K0min = Math.min(hProp.pedoParams.K0, hNextProp.pedoParams.K0); // cm/day

					double drainageMax_ts = K0min / 24d / timeStepNumberDouble / 100d * refScene.getArea() * 998d;

					drainage_ts = Math.min(drainage_ts, drainageMax_ts);
					// drainage_ts = Math.min(Math.abs(drainage_ts),
					// drainageMax_ts);

					double cumulatedDrainage = 0;

					double capillaryRise_ts = 0;
					if (drainage_ts < 0)
						capillaryRise_ts = -drainage_ts;

					double waterInput = upperDrainage_ts + capillaryRise_ts + upperSurplus_ts; // l
					double waterOutput = drainage_ts + upperCapillaryRise_ts; // l

					double standHorizonVolume = h.volume * refScene.getArea(); // m3
					double newWaterContent_ts = prevWaterContent_ts
							+ (waterInput - waterOutput) / (998d * standHorizonVolume * (1d - h.additionalCoarseFraction)); // m3/m3

					if (newWaterContent_ts < h.wiltingPointWaterContent / 2d)
						newWaterContent_ts = h.wiltingPointWaterContent / 2d;

					// System.out.println("HetHorizonsWaterContentCalculator:
					// newWaterContent_ts= " + newWaterContent_ts +
					// ",drainage_ts= " + drainage_ts + ", drainageMax_ts= " +
					// drainageMax_ts + ", upperDrainage_ts= " +
					// upperDrainage_ts + ", K= " + K + ", K0min= " + K0min);

					double surplus_ts = 0d; // l
					if (newWaterContent_ts > h.saturatedWaterContent) {
						newWaterContent_ts = h.saturatedWaterContent;
						surplus_ts = waterInput - ((h.saturatedWaterContent - prevWaterContent_ts) * standHorizonVolume
								* 998d * (1d - h.additionalCoarseFraction) + waterOutput);
					}

					if (!Double.isNaN(drainage_ts))
						cumulatedDrainage = drainage_ts + drainageMap.get(hId);
					else
						HetReporter.printInStandardOutput("HetHorizonWaterContent: Drainage = NAN: K= " + K + ", K0= "
								+ K0min + ", deltaHdeltaZ= " + deltaHdeltaZ + ", timeStepNumber= "
								+ timeStepNumberDouble + ", matricPotential=" + matricPotential
								+ ", matricPotentialNext=" + matricPotentialNext + ", prevWaterContent_ts= "
								+ prevWaterContent_ts);
					// System.out.println("HetHorizonWaterContent: Drainage =
					// NAN: drainage_ts= " + K / 24d / timeStepNumberDouble /
					// 100d * (deltaHdeltaZ + 1) * refScene.getArea() * 998d +
					// ", drainageMax_ts= " + K0min / 24d / timeStepNumberDouble
					// / 100d * refScene.getArea() * 998d);

					if (drainage_ts > 0) {
						upperDrainage_ts = drainage_ts;
						upperCapillaryRise_ts = 0;
					} else {
						upperDrainage_ts = 0d;
						upperSurplus_ts = surplus_ts;
						upperCapillaryRise_ts = capillaryRise_ts;
					}

					drainageMap.put(hId, cumulatedDrainage);
					prevHorizonsWaterContentTemp.put(hId, newWaterContent_ts);
				}
			}

			for (int hId : new TreeSet<>(newHorizons.keySet())) {

				// hId order is ok: 1 -> 9
				// System.out.println("HetHorizonsWaterContentCalculator.updateHorizonsWaterContent
				// (), hId: "+hId);

				// Horizon h
				HetHorizon h = newHorizons.get(hId);

				// mj+fa-21.09.2017: commented (see time discretization above)
				/*
				 * // hNext is the horizon below h // when h is the lowest
				 * horizon, hNext = h HetHorizon hNext = h; // special case int
				 * hIdNext = hId + 1; if (newHorizons.get(hIdNext) != null)
				 * hNext = newHorizons.get(hId + 1); // normal case
				 */

				double prevWaterContent = prevHorizonsWaterContent.get(hId);

				// mj+fa-21.09.2017: commented (see time discretization above)
				/*
				 * // Get hydraulic properties for h and hNext
				 * HydraulicProperties hProp = hPropMap.get(h.id);
				 * HydraulicProperties hNextProp = hPropMap.get(hNext.id);
				 *
				 * // Kh: hydraulic conductivity for h (cm/day)
				 * HetHydraulicPedotransferParameters pedoParams =
				 * hProp.pedoParams; double Kh = hProp.K; // cm/day double
				 * matricPotential = hProp.prevMatricPotential;
				 *
				 * // KhNext: hydraulic conductivity for hNext (cm/day) //
				 * HetHydraulicPedotransferParameters hpParamsNext = //
				 * hNextProp.pedoParams; double KhNext = hNextProp.K; // cm/day
				 * double matricPotentialNext = hNextProp.prevMatricPotential;
				 *
				 * // fc+mj-8.3.2017 double K = Math.min(Kh, KhNext); // cm/day
				 *
				 * // double K = (Kh * 1 / 2d * h.thickness + KhNext * 1 / 2d *
				 * // hNext.thickness) // / (1 / 2d * h.thickness + 1 / 2d *
				 * hNext.thickness);
				 *
				 * // deltaHdeltaZ cm/cm double deltaHdeltaZ =
				 * (matricPotentialNext - matricPotential) / ((1 / 2d *
				 * h.thickness + 1 / 2d * hNext.thickness) * 100d); //
				 * fa-02.03.2017 // *100d: // m // -> // cm // if //
				 * (deltaHdeltaZ // > // 20) // deltaHdeltaZ = 20; // if
				 * (deltaHdeltaZ < -20) // deltaHdeltaZ = -20; // fc+mj-7.3.2017
				 * searching bug in drainage // deltaHdeltaZ = 0; // K = 0.2d;
				 */

				// drainage in l
				// 24 / 100 : cm/j -> m/h
				// * 998 : m3 -> l
				// mj+fa-21.09.2017: commented (see time discretization above)
				// double drainage = K / 24d / 100d * (deltaHdeltaZ + 1) *
				// refScene.getArea() * 998d;
				double drainage = drainageMap.get(hId);
				double candidateDrainage = drainage; // for trace

				// Minimum K0 between h and hNext
				// mj+fa-21.09.2017: commented (see time discretization above)
				/*
				 * double K0min = Math.min(hProp.pedoParams.K0,
				 * hNextProp.pedoParams.K0); // cm/day
				 *
				 * double drainageMax = K0min / 24d / 100d * refScene.getArea()
				 * * 998d;
				 *
				 * drainage = Math.min(drainage, drainageMax);
				 */

				// fc+mj-8.3.2017 This Log is heavy, should be disabled when
				// debug
				// is ok
				// String TAB = "\t";
				// Log.println("HeteroforDebug",
				// "HetHorizonsWaterContentCalculator.updateHorizonsWaterContent()"
				// + TAB
				// + " hId: " + hId
				// + TAB + "Kh:" + TAB + Kh
				// + TAB + "KhNext:" + TAB + KhNext
				// + TAB + "K:" + TAB + K
				// + TAB + "deltaHdeltaZ: " + TAB + deltaHdeltaZ
				// + TAB + " K0min: "+K0min
				// + TAB + " candidateDrainage: "+candidateDrainage
				// + TAB + " drainageMax: "+drainageMax
				// + TAB + " drainage: "+drainage
				// );

				// Organic horizons
				// if (h.lowerLimit >= 0) {
				// drainage = 0; // fc+mj-7.3.2017 TESTING
				// }

				// drainage = 0; // fc+mj-7.3.2017 TESTING (works quite well ;-)

				// Water input
				double capillaryRise = 0; // l
				if (drainage < 0)
					capillaryRise = -drainage;

				double waterInput = upperDrainage + upperSurplus + capillaryRise; // l

				// Water output
				// double woDrainage = drainage > 0 ? drainage : 0;
				double woDrainage = drainage; // l
				if (drainage <= 0d)
					woDrainage = 0d;

				double woEvaporation = 0; // l
				if (h.lowerLimit >= 0) { // evaporating horizon
					double hEvaporationCapacity = (prevWaterContent - h.wiltingPointWaterContent) * h.volume
							* refScene.getArea() * 998d * (1d - h.additionalCoarseFraction);

					woEvaporation = Math.min(hEvaporationCapacity, remainingSoilEvaporation);
					remainingSoilEvaporation -= woEvaporation; // l
				}

				if (rootWaterUptakeMap == null)
					HetReporter.printInStandardOutput("HetHorizonsWaterContentCalculator, rootWaterUptakeMap == null");
				if (rootWaterUptakeMap.get(hId) == null) {
					HetReporter.printInStandardOutput(
							"HetHorizonsWaterContentCalculator, rootWaterUptakeMap.get(hId) == null for hId: " + hId);
					HetReporter.printInStandardOutput("rootWaterUptakeMap: " + AmapTools.toString(rootWaterUptakeMap));
				}

				if (rootWaterUptakeMap == null || rootWaterUptakeMap.get(hId) == null)
					HetReporter.printInStandardOutput("HetHorizonsWaterContentCalculator: rootWaterUptakeMap= "
							+ rootWaterUptakeMap + ", rootWaterUptakeMap= " + rootWaterUptakeMap.get(hId));
				double waterOutput = woDrainage + woEvaporation + rootWaterUptakeMap.get(hId) + upperCapillaryRise; // l

				double standHorizonVolume = h.volume * refScene.getArea(); // m3

				double newWaterContent = prevWaterContent
						+ (waterInput - waterOutput) / (998d * standHorizonVolume * (1d - h.additionalCoarseFraction)); // m3/m3

				// if (Double.isNaN(newWaterContent)) {
				// System.out.println("HetHorizonsWaterContentCalculator,
				// newWaterContent: NaN");
				// }

				 // fc+mj+fa+lw-15.2.2017
				if (newWaterContent < h.wiltingPointWaterContent / 2d)
					newWaterContent = h.wiltingPointWaterContent / 2d;

				 // fc+mj-7.3.2017 water quantity: difference between wilting
				 // point and current water content double value
				// =(h.wiltingPointWaterContent - newWaterContent) * standHorizonVolume * 998d (1d - h.additionalCoarseFraction); // l


//
//				 // Drainage correction // fc+mj-8.3.2017 drainage = drainage
//				 - value; drainage = Math.max(0, drainage);
//
//				 // Trace double v1 = value / refScene.getArea(); // l/m2
//				 waterError_horizon.addValue("" + h.id, v1); }
//
//				 // newWaterContent = Math.max(newWaterContent, //
//				 h.wiltingPointWaterContent);

				double surplus = 0d; // l
				if (newWaterContent > h.saturatedWaterContent) {
					newWaterContent = h.saturatedWaterContent;

					surplus = waterInput - ((h.saturatedWaterContent - prevWaterContent) * standHorizonVolume * 998d
							* (1d - h.additionalCoarseFraction) + waterOutput);
				}

				preferentialFlow += preferentialFlowProportion * surplus; // fa+mj-07.09.2017:
																			// Attempt
																			// to
																			// account
																			// for
																			// preferential
																			// fluxes

				newHorizonsWaterContent.put(hId, newWaterContent);

				// Lowest horizon
				if (refSoil.isLowestHorizon(hId)) {
					// deepDrainage = (drainage + surplus) / refScene.getArea();
					// //
					// l/m2
					deepDrainage = (drainage + preferentialFlow + (1 - preferentialFlowProportion) * surplus)
							/ refScene.getArea(); // l/m2

					if (Double.isNaN(deepDrainage)) {
						HetReporter.printInStandardOutput(
								"HetHorizonsWaterContentCalculator, deepDrainage: NaN: drainage= " + drainage
										+ ", preferentialFlow=" + preferentialFlow + ", surplus= " + surplus);
					}

				}

				// Updates for next iteration
				// upperDrainage = drainage > 0 ? drainage : 0;
				upperDrainage = drainage;
				if (drainage <= 0d)
					upperDrainage = 0d;

				upperSurplus = (1 - preferentialFlowProportion) * surplus;
				upperCapillaryRise = capillaryRise;

				// water table rising not accounted
			}

			// fa-13.06.2019
			double waterContentVariation = 0.0;

			for (int hId : new TreeSet<>(newHorizons.keySet())) {

				HetHorizon horizon = newHorizons.get(hId);

				double waterContent = newHorizonsWaterContent.get(hId);
				double previousWaterContent = prevHorizonsWaterContent.get(hId);

				waterContentVariation += (waterContent - previousWaterContent) * horizon.thickness
						* (1.0 - horizon.additionalCoarseFraction) * 1000.0;

			}

			waterBalanceError = rainfall
					- (transpiration + interception + soilEvaporation + deepDrainage + waterContentVariation);
//			double toleranceThreshold = 0.01; // mm
			waterBalanceIsAcceptable = Math.abs(waterBalanceError) < toleranceThreshold;

			stabilityCriteriaReductionFactor = stabilityCriteriaReductionFactor * 10d;

//			if (stabilityCriteriaReductionFactor > maxStabilityCriteriaReductionFactor)
//				HetReporter.printInStandardOutput("HetHorizonWaterContent.updateHorizonsWaterContent() : Date " + day
//						+ "/" + month + "/" + year + " " + hour + ":00:00" + ", stabilityCriteriaReductionFactor = "
//						+ stabilityCriteriaReductionFactor + " reached maximum fixed value and waterBalanceError = "
//						+ waterBalanceError + " mm is still beyond tolerance threshold fixed to " + toleranceThreshold
//						+ " mm, simulation will continue with these values.");

		} // end of while loop

		if (!waterBalanceIsAcceptable && stabilityCriteriaReductionFactor > maxStabilityCriteriaReductionFactor)
			HetReporter.printInStandardOutput("HetHorizonWaterContent.updateHorizonsWaterContent() : Date " + day
					+ "/" + month + "/" + year + " " + hour + ":00:00" + ", stabilityCriteriaReductionFactor = "
					+ stabilityCriteriaReductionFactor + " reached maximum fixed value and waterBalanceError = "
					+ waterBalanceError + " mm is still beyond tolerance threshold fixed to " + toleranceThreshold
					+ " mm, simulation will continue with these values.");

		return newHorizonsWaterContent;
	}

	public double getDeepDrainage() {
		return deepDrainage;
	}

	//fa-18.06.2019
	public double calculateWeightedMeanWaterPotential (Map<Integer, HetHorizon> horizons, Map<Integer, Double> horizonsWaterContent) {
		createHPropMap(horizons, horizonsWaterContent);
		double weightedMeanPrevWaterPotential = 0d;
		for (int hId : hPropMap.keySet()) {
			HydraulicProperties hProp = hPropMap.get(hId);

			HetHorizon h = refSoil.getHorizon(hId);
			weightedMeanPrevWaterPotential += hProp.prevWaterPotential * h.fineRootProportion;
		}
		return weightedMeanPrevWaterPotential;
	}

}
