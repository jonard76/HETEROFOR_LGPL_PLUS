/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.io.Serializable;

/**
 * The equations for the Heterofor model.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetEquations implements Serializable {

	/**
	 * Calulate the ..
	 * dbh in cm.
	 */
//	static public double computeAboveGroundBiomass (double alpha, double beta, double dbh) {
//		return alpha * Math.pow (dbh, beta);
//	}


//	static public double computeDeltaAboveGroundBiomass (double interceptedRadiation, double radiationUseEfficiency,
//			double respirationRatio, double aboveGroundFraction) {
//		return interceptedRadiation * radiationUseEfficiency * respirationRatio * aboveGroundFraction;
//	}
//
//	static public double computeDbh (double aboveGroundBiomass, double alpha, double beta) {
//		return Math.pow(aboveGroundBiomass / alpha, 1d / beta);
//	}


}
