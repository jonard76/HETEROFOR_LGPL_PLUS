/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.phenology;

import heterofor.model.HetReporter;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Class containing the parameters of the phenological thermal time model and methods to calculate phenological dates
 * using this model.
 *
 * @author N. Beudez - May 2017
 */
public class HetThermalTimeModel extends HetPhenologyModel {

	// Parameters of the model
	private int t1_forcingStartingDateDOY;
	private double t1_criticalForcingTemperature;
	private double t1_forcingThreshold;
	private int t2a_budburstShift;
	private double t2a_budburstThreshold;
	private int t3_ageingStartingDateDOY;
	private double t3_criticalAgeingTemperature;
	private double t3_ageingThreshold;
	private double t4a_leafYellowingParameter;
	private double t4a_yellowingThreshold;
	private double t5a_fallingRate;
	private double t5a_frostFallingAmplifier;

	/**
	 * Constructor: parses a String containing the phenology parameters line (phenology model name + list of parameters), e.g.
	 * thermalTime(27;0.26;471.08;-2;200.0;213;20.0;230.0;0.4;0.01;0.022126;4.0)
	 * @param phenologyParametersLine The full phenology parameter line including the name of the phenology model and the list of phenology parameters
	 * @throws Exception
	 */
	public HetThermalTimeModel(String phenologyParametersLine) throws Exception {

		try {
			HetReporter.printInStandardOutput("HetThermalTimeModel instance\n");

			StringTokenizer st = parsePhenologyParameterLines(phenologyParametersLine, THERMAL_TIME);

			t1_forcingStartingDateDOY = Integer.parseInt(st.nextToken().trim());
			t1_criticalForcingTemperature = Double.parseDouble(st.nextToken().trim());
			t1_forcingThreshold = Double.parseDouble(st.nextToken().trim());
			t2a_budburstShift = Integer.parseInt(st.nextToken().trim());
			if (t2a_budburstShift > 0) {
				throw new Exception("HetThermalTimeModel.HetThermalTimeModel(String): t2a_budburstShift must be a negative or zero integer.");
			}
			t2a_budburstThreshold = Double.parseDouble(st.nextToken().trim());
			t3_ageingStartingDateDOY = Integer.parseInt(st.nextToken().trim());
			t3_criticalAgeingTemperature = Double.parseDouble(st.nextToken().trim());
			t3_ageingThreshold = Double.parseDouble(st.nextToken().trim());
			t4a_leafYellowingParameter = Double.parseDouble(st.nextToken().trim());
			t4a_yellowingThreshold = Double.parseDouble(st.nextToken().trim());
			t5a_fallingRate = Double.parseDouble(st.nextToken().trim());
			t5a_frostFallingAmplifier = Double.parseDouble(st.nextToken().trim());

			HetReporter.printInStandardOutput("t1_forcingStartingDateDOY: " + t1_forcingStartingDateDOY);
			HetReporter.printInStandardOutput("t1_criticalForcingTemperature: " + t1_criticalForcingTemperature);
			HetReporter.printInStandardOutput("t1_forcingThreshold: " + t1_forcingThreshold);
			HetReporter.printInStandardOutput("t2a_budburstShift: " + t2a_budburstShift);
			HetReporter.printInStandardOutput("t2a_budburstThreshold: " + t2a_budburstThreshold);
			HetReporter.printInStandardOutput("t3_ageingStartingDateDOY: " + t3_ageingStartingDateDOY);
			HetReporter.printInStandardOutput("t3_criticalAgeingTemperature: " + t3_criticalAgeingTemperature);
			HetReporter.printInStandardOutput("t3_ageingThreshold: " + t3_ageingThreshold);
			HetReporter.printInStandardOutput("t4a_leafYellowingParameter: " + t4a_leafYellowingParameter);
			HetReporter.printInStandardOutput("t4a_yellowingThreshold: " + t4a_yellowingThreshold);
			HetReporter.printInStandardOutput("t5a_fallingRate: " + t5a_fallingRate);
			HetReporter.printInStandardOutput("t5a_frostFallingAmplifier: " + t5a_frostFallingAmplifier);
			HetReporter.printInStandardOutput("");

		} catch (Exception e) {
			throw new Exception("HetThermalTimeModel.HetThermalTimeModel(String): could not parse this string: " + phenologyParametersLine, e);
		}

	}

	@Override
	public void completeInitialisation(HetPhenology phenology, int year, int t2b_averageTreeBudburstDateDOY) {

		HetReporter.printInStandardOutput("dans HetThermalTimeModel.completeInitialisation(HetPhenology phenology, int year, int t2b_averageTreeBudburstDateDOY)");

		int nextYear = year+1;

		// t0_chillingStartingDate is not needed for this model: t1_forcingStartingDateDOY is set below.

		// t1_forcingStartingDate
		phenology.getT1_forcingStartingDate().setValue(year, t1_forcingStartingDateDOY);

		// t2a_standBudburstStartingDate is not set: it will be calculated in run().

		// t2b_averageTreeBudburstDate is not set: it will be calculated in run() (because t1_forcingStartingDate is known).

		// t2c_completeLeafDevelopmentDate is not set: it will be calculated in run().

		// t3_ageingStartingDate
		phenology.getT3_ageingStartingDate().setValue(year, t3_ageingStartingDateDOY);

		// t4a_yellowingStartingDate is not set: it will be calculated in run().

		// t4b_yellowingEndingDate is not set: it will be calculated in run().

		// t5a_fallingStartingDate is not set: it will be calculated in run().

		// t5b_fallingEndingDate is not set: it will be calculated in run().

		// t0_chillingStartingDateNext is not needed for this model: t1_forcingStartingDateNext is set below.

		// t1_forcingStartingDateNext
		phenology.getT1_forcingStartingDateNext().setValue(nextYear, t1_forcingStartingDateDOY);
	}

	@Override
	public void completeInitialisation(HetPhenology newPhenology, HetPhenology sourcePhenology, int year) {

		HetReporter.printInStandardOutput("dans HetThermalTimeModel.completeInitialisation(HetPhenology newPhenology, HetPhenology sourcePhenology, int year)");

		int nextYear = year+1;

		// t0_chillingStartingDate
		newPhenology.getT0_chillingStartingDate().setValue(sourcePhenology.getT0_chillingStartingDateNext());

		// t0_chillingState
		newPhenology.setT0_chillingState(sourcePhenology.getT0_chillingStateNext());

		// t1_forcingStartingDate
		newPhenology.getT1_forcingStartingDate().setValue(sourcePhenology.getT1_forcingStartingDateNext());

		// t1_forcingState
		newPhenology.setT1_forcingState(sourcePhenology.getT1_forcingStateNext());

		// t2a_standBudburstStartingDate is not set: it will be calculated in run().

		// t2b_averageTreeBudburstDate is not set: it will be calculated in run().

		// t2a_budburstState is already set to 0.0 in HetPhenology.init().

		// t2c_completeLeafDevelopmentDate is not set: it will be calculated in run().

		// t3_ageingStartingDate
		newPhenology.getT3_ageingStartingDate().setValue(year, t3_ageingStartingDateDOY);

		// t3_ageingState is already set to 0.0 in HetPhenology.init().

		// t4a_yellowingStartingDate is not set: it will be calculated in run().

		// t4b_yellowingEndingDate is not set: it will be calculated in run().

		// t5a_fallingStartingDate is not set: it will be calculated in run().

		// t5b_fallingEndingDate is not set: it will be calculated in run().

		// t0_chillingStartingDateNext is not needed for this model: t1_forcingStartingDateNext is set below.

		// t0_chillingStateNext is not needed for this model: t1_forcingStartingDateNext is set below.

		// t1_forcingStartingDateNext
		newPhenology.getT1_forcingStartingDateNext().setValue(nextYear, t1_forcingStartingDateDOY);

		// t1_forcingStateNext is already set to 0.0 in HetPhenology.init().
	}

	/**
	 * Calculates the phenology states and dates for the given year.
	 */
	@Override
	public void run(HetPhenology phenology, int year, LinkedHashMap<String, Double> dateDailyAverageAirTemperatureMap,
			LinkedHashMap<String, Double> dateDailyAverageWindSpeedMap, List<HetMeteoLine> meteoLinesOfYear,
			double latitudeInRadians) throws Exception {

		HetReporter.printInStandardOutput("dans HetThermalTimeModel.run()");

		double dayLengthMin = calculateMinimalDayLength(latitudeInRadians);

		for (String date : dateDailyAverageAirTemperatureMap.keySet()) {

			// date is a year_month_day string
			String [] yearMonthDayTab = date.split( HetMeteorology.SEP );

			// year is already known
			int month = Integer.valueOf(yearMonthDayTab[1]);
			int day = Integer.valueOf(yearMonthDayTab[2]);

			double dailyAirTemperature = dateDailyAverageAirTemperatureMap.get(date);
			double dailyAverageWindSpeed = dateDailyAverageWindSpeedMap.get(date);

			calculate_t0_chillingStartingDate(phenology, year, month, day, dailyAirTemperature);
			calculate_t1_forcingStartingDate(phenology, year, month, day, dailyAirTemperature);
			// t2a_standBudburstStartingDate is calculated when t2b_averageTreeBudburstDate is reached so that
			// calculate_t2a_standBudburstStartingDate() is called after calculate_t2b_averageTreeBudburstDate().
			calculate_t2b_averageTreeBudburstDate(phenology, year, month, day, dailyAirTemperature, t1_forcingThreshold, THERMAL_TIME);
			calculate_t2a_standBudburstStartingDate(phenology, year, month, day, t2a_budburstShift, THERMAL_TIME);
			calculate_t2c_completeLeafDevelopmentDate(phenology, year, month, day, dailyAirTemperature, t2a_budburstThreshold, THERMAL_TIME);
			calculate_t3_ageingStartingDate(phenology, year, month, day, dailyAirTemperature, this.getClass().getSimpleName(), THERMAL_TIME);
			calculate_t4a_yellowingStartingDate(phenology, year, month, day, dailyAirTemperature, t3_criticalAgeingTemperature, t3_ageingThreshold, THERMAL_TIME);
			calculate_t4b_yellowingEndingDate(phenology, year, month, day, latitudeInRadians, dayLengthMin, t4a_leafYellowingParameter, t4a_yellowingThreshold, THERMAL_TIME);
			calculate_t5a_fallingStartingDate(phenology, year, month, day, THERMAL_TIME);
			calculate_t5b_fallingEndingDate(phenology, year, month, day, dailyAverageWindSpeed, meteoLinesOfYear, t5a_frostFallingAmplifier, t5a_fallingRate, THERMAL_TIME);

			calculate_t0_chillingStartingDateNext(phenology, year, month, day, dailyAirTemperature);
			calculate_t1_forcingStartingDateNext(phenology, year, month, day, dailyAirTemperature);
			calculate_t2b_averageTreeBudburstDateNext(phenology, year, month, day, dailyAirTemperature, t1_forcingThreshold, THERMAL_TIME);
		}

		completeGreenProportionAndLadProportionCalculations(phenology, dateDailyAverageWindSpeedMap.keySet());

	}

	/**
	 * Calculates the t0_chillingStartingDate.
	 */
	private void calculate_t0_chillingStartingDate(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) {

		return; // not needed because t1_forcingStartingDate is set
	}

	/**
	 * Calculates the t1_forcingStartingDate.
	 * @throws Exception
	 */
	private void calculate_t1_forcingStartingDate(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) throws Exception {

		if (!phenology.getT1_forcingStartingDate().isSet()) {

			throw new Exception("HetThermalTimeModel.calculate_t1_forcingStartingDate() year: " + year
					+ ". Error: t1_forcingStartingDate should have been set in "
					+ "HetThermalTimeModel.completeInitialisation(int year, HetPhenology phenology, int t2b_averageTreeBudburstDateDOY) or "
					+ "HetThermalTimeModel.completeInitialisation(int year, HetPhenology phenology), "
					+ "t1_forcingStartingDate: " + phenology.getT1_forcingStartingDate());
		}
	}

	/**
	 * Calculates the t0_chillingStartingDateNext (for the following year).
	 */
	private void calculate_t0_chillingStartingDateNext(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) throws Exception {

		return; // not needed because t1_forcingStartingDateNext is set
	}

	/**
	 * Calculates the t1_forcingStartingDateNext (for the following year).
	 * @throws Exception
	 */
	private void calculate_t1_forcingStartingDateNext(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) throws Exception {

		if (!phenology.getT1_forcingStartingDateNext().isSet()) {

			throw new Exception("HetThermalTimeModel.calculate_t1_forcingStartingDateNext() year: " + year
					+ ". Error: t1_forcingStartingDateNext should have been set in "
					+ "HetThermalTimeModel.completeInitialisation(int year, HetPhenology phenology, int t2b_averageTreeBudburstDateDOY) or "
					+ "HetThermalTimeModel.completeInitialisation(int year, HetPhenology phenology), "
					+ "t1_forcingStartingDateNext: " + phenology.getT1_forcingStartingDateNext());
		}
	}

	@Override
	protected double calculate_t1_forcingRate(double dailyAverageTemperature) {

		if (dailyAverageTemperature > t1_criticalForcingTemperature) {
			return dailyAverageTemperature;
		} else {
			return 0.0;
		}
	}

}
