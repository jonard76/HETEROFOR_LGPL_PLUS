/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.phenology;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * A date of phenology.
 *
 * @author L. de Wergifosse, N. Beudez - January 2017
 */
public class HetPhenologyDate implements Serializable {

	static private GregorianCalendar calendar;

	private int year;
	private int doy; // day of year

	/**
	 * Constructor 1
	 */
	public HetPhenologyDate() {
		reset();
	}

	/**
	 * Constructor 2
	 */
	public HetPhenologyDate(int year, int doy) {
		setValue(year, doy);
	}

	/**
	 *  Sets year and doy with the given year and doy
	 */
	public void setValue(int year, int doy) {
		this.year = year;
		this.doy = doy;
	}

	/**
	 * Sets year and doy with the one of the given phenology date
	 */
	public void setValue(HetPhenologyDate sourceDate) {
		setValue (sourceDate.getYear(), sourceDate.getDoy());
	}

	/**
	 * Returns the phenology date's year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * Returns the phenology date's day of year
	 */
	public int getDoy() {
		return doy;
	}

	/**
	 * Initializes the phenology date
	 */
	public void reset() {
		year = -1;
		doy = -1;
	}

	/**
	 * Returns true if the phenology date is set
	 */
	public boolean isSet() {
		return (year != -1 && doy != -1);
	}

	/**
	 * Creates and returns a phenology date using the classical date given as parameter
	 */
	public static HetPhenologyDate getPhenologyDate(int year, int month, int day) {
		return new HetPhenologyDate(year, getDayOfYear(year, month, day));
	}

	/**
	 * Returns the day of year of the classical date given as parameter
	 */
	public static int getDayOfYear(int year, int month, int day) {
		if (calendar == null)
			calendar = new GregorianCalendar();

		calendar.set(year, month - 1, day); // month in [0,11]
		return calendar.get(Calendar.DAY_OF_YEAR);
	}

	/**
	 * Returns a date to the dd/mm/yyyy format from the given year and day of year.
	 * @param year The year
	 * @param dayOfYear The day of the year
	 * @return The corresponding date to the dd/mm/yyyy format
	 */
	public static String getYearMonthDay(int year, int dayOfYear) {

		if (calendar == null)
			calendar = new GregorianCalendar();

		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.DAY_OF_YEAR, dayOfYear);

		String date = "";
		date += calendar.get(Calendar.DAY_OF_MONTH);
		date += "/";
		date += calendar.get(Calendar.MONTH)+1; // because Calendar.MONTH is in [0,11]
		date += "/";
		date += calendar.get(Calendar.YEAR);

		return date;
	}

	/**
	 * Returns true if the current phenology date is greater than or equal
	 * to the the phenology date given as parameter, false otherwise.
	 */
	public boolean isGreaterOrEqualThan(HetPhenologyDate date) {
		if (year < date.getYear()) return false;
		else if (year > date.getYear()) return true;
		else {
			if (doy >= date.getDoy()) return true;
			else return false;
		}
	}

	/**
	 * Returns true if the current phenology date is equal to the
	 * phenology date given as parameter, false otherwise.
	 */
	public boolean isEqualTo(HetPhenologyDate date) {
		if (year == date.getYear() && doy == date.getDoy() )
			return true;
		else
			return false;
	}

	/**
	 * Returns a (year, day of year) representation of a phenology date
	 */
	public String toString() {
		return "(" + year + ", " + doy + ")";
	}

}
