/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.phenology;

import heterofor.model.HetReporter;
import heterofor.model.meteorology.HetMeteoLine;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * The phenology class for Heterofor. A phenology is composed of phenological dates and states and
 * of a phenological model.
 *
 * @author N. Beudez, L. de Wergifosse, F. André - May 2017
 */
public class HetPhenology implements Serializable {

	// Dates and states	for current year
	private HetPhenologyDate t0_chillingStartingDate;				// chilling starting date (pair (year,day of year))
	private double t0_chillingState; 								// chilling state: sum of the chilling rates used to calculate t1 (forcing starting date)
	private HetPhenologyDate t1_forcingStartingDate; 				// forcing starting date (pair (year,day of year))
	private double t1_forcingState; 								// forcing state: sum of the forcing rates used to calculate t2b (leaf budburst date of the average tree)
	private HetPhenologyDate t2a_standBudburstStartingDate;			// leaf budburst (leaf on) starting date (pair (year,day of year)) of the stand
	private HetPhenologyDate t2b_averageTreeBudburstDate; 			// leaf budburst (leaf on) date (pair (year,day of year)) of the average tree
	private double t2a_budburstState;								// budburst state: sum of the budburst rates used to calculate t2c (complete leaf development date)
	private HetPhenologyDate t2c_completeLeafDevelopmentDate;		// complete leaf development date (pair (year,day of year))
	private HetPhenologyDate t3_ageingStartingDate; 				// ageing starting date (pair (year,day of year))
	private double t3_ageingState; 									// ageing state: sum of the ageing rates used to calculate t4 (yellowing starting date)
	private HetPhenologyDate t4a_yellowingStartingDate; 			// yellowing starting date (pair (year,day of year))
	private HetPhenologyDate t4b_yellowingEndingDate; 				// yellowing ending date (pair (year,day of year))
	private HetPhenologyDate t5a_fallingStartingDate;				// leaf fall starting date (pair (year,day of year))
	private HetPhenologyDate t5b_fallingEndingDate;					// leaf fall ending date (pair (year,day of year))

	// Dates and states for the following year
	private HetPhenologyDate t0_chillingStartingDateNext;			// t0 (chilling starting date, pair (year,day of year)) for the following year
	private double t0_chillingStateNext; 							// partial t0_chillingState to be updated the following year
	private HetPhenologyDate t1_forcingStartingDateNext; 			// t1 (forcing starting date, pair (year,day of year)) for the following year
	private double t1_forcingStateNext; 							// partial t1_forcingState to be updated the following year

	// Model
	private HetPhenologyModel model;

	// Key: day of year (doy), value: proportion of green leaves compared to the level of maximum development (value in [0,1])
	private HashMap<Integer, Double> doyGreenPropMap;

	// Key: day of year (doy), value: proportion of leaf area compared to the level of maximum development (value in [0,1])
	private HashMap<Integer, Double> doyLadPropMap;

	/**
	 * Constructor 1
	 * @param model The phenological model
	 */
	public HetPhenology(HetPhenologyModel model) {

		init();
		this.model = model;
	}

	/**
	 * Constructor 2
	 * @param sourcePhenology The source phenology
	 * @param year The year number
	 * @param t2b_averageTreeBudburstDateDOY The day of year (doy) of the leaf budburst date of the average tree
	 */
	public HetPhenology(HetPhenology sourcePhenology, int year, int t2b_averageTreeBudburstDateDOY) {

		init();
		this.model = sourcePhenology.getModel();
		this.model.completeInitialisation(this, year, t2b_averageTreeBudburstDateDOY);
	}

	/**
	 * Constructor 3
	 * @param sourcePhenology The source phenology
	 * @param year The year number
	 */
	public HetPhenology(HetPhenology sourcePhenology, int year) {

		init();
		this.model = sourcePhenology.getModel();
		this.model.completeInitialisation(this, sourcePhenology, year);
	}

	/**
	 * Initialize dates and states.
	 */
	public void init() {

		t0_chillingStartingDate = new HetPhenologyDate();
		t0_chillingState = 0.0;
		t1_forcingStartingDate = new HetPhenologyDate();
		t1_forcingState = 0.0;
		t2a_standBudburstStartingDate = new HetPhenologyDate();
		t2b_averageTreeBudburstDate = new HetPhenologyDate();
		t2a_budburstState = 0.0;
		t2c_completeLeafDevelopmentDate = new HetPhenologyDate();
		t3_ageingStartingDate = new HetPhenologyDate();
		t3_ageingState = 0.0;
		t4a_yellowingStartingDate = new HetPhenologyDate();
		t4b_yellowingEndingDate = new HetPhenologyDate();
		t5a_fallingStartingDate = new HetPhenologyDate();
		t5b_fallingEndingDate = new HetPhenologyDate();

		t0_chillingStartingDateNext = new HetPhenologyDate();
		t0_chillingStateNext = 0.0;
		t1_forcingStartingDateNext = new HetPhenologyDate();
		t1_forcingStateNext = 0.0;

		doyGreenPropMap = new HashMap<Integer, Double>();
		doyLadPropMap = new HashMap<Integer, Double>();
	}

	/**
	 * Executes the run() method of the phenological model.
	 * @param year The year number
	 * @param dateDailyAverageAirTemperatureMap The map with key: year_month_day string, value: the average air temperature of the day
	 * @param dateDailyAverageWindSpeedMap The map with key: year_month_day string, value: the average wind speed of the day
	 * @param meteoLinesOfYear The ordered meteorological lines of the year (one line per hour)
	 * @param latitudeInRadians The latitude of the plot expressed in radians
	 * @throws Exception
	 */
	public void run(int year, LinkedHashMap<String, Double> dateDailyAverageAirTemperatureMap,
			LinkedHashMap<String, Double> dateDailyAverageWindSpeedMap, List<HetMeteoLine> meteoLinesOfYear,
			double latitudeInRadians) throws Exception {

		model.run(this, year, dateDailyAverageAirTemperatureMap, dateDailyAverageWindSpeedMap, meteoLinesOfYear, latitudeInRadians);
	}

    /**
     * Returns a leaf area development proportion in [0,1] for any given doy in the year.
     */
    public double getLadProportion(int doy) {

    	return doyLadPropMap.get(doy);
    }

    // fa-19.06.2017
    /**
     * Returns a green leaf proportion in [0,1] for any given doy in the year.
     */
    public double getGreenProportion(int doy) {

    	return doyGreenPropMap.get(doy);
    }

	/**
	 * Displays the phenological dates in chronological order of appearance.
	 */
	public void displayDates() {

		HetReporter.printInStandardOutput("t0_chillingStartingDate: " + t0_chillingStartingDate.toString());
		HetReporter.printInStandardOutput("t1_forcingStartingDate: " + t1_forcingStartingDate.toString());
		HetReporter.printInStandardOutput("t2a_standBudburstStartingDate: " + t2a_standBudburstStartingDate.toString());
		HetReporter.printInStandardOutput("t2b_averageTreeBudburstDate: " + t2b_averageTreeBudburstDate.toString());
		HetReporter.printInStandardOutput("t2c_completeLeafDevelopmentDate: " + t2c_completeLeafDevelopmentDate.toString());
		HetReporter.printInStandardOutput("t3_ageingStartingDate: " + t3_ageingStartingDate.toString());
		HetReporter.printInStandardOutput("t4a_yellowingStartingDate: " + t4a_yellowingStartingDate.toString());
		HetReporter.printInStandardOutput("t5a_fallingStartingDate: " + t5a_fallingStartingDate.toString());
		HetReporter.printInStandardOutput("t4b_yellowingEndingDate: " + t4b_yellowingEndingDate.toString());
		HetReporter.printInStandardOutput("t5b_fallingEndingDate: " + t5b_fallingEndingDate.toString());
		HetReporter.printInStandardOutput("t0_chillingStartingDateNext: " + t0_chillingStartingDateNext.toString());
		HetReporter.printInStandardOutput("t1_forcingStartingDateNext: " + t1_forcingStartingDateNext.toString());
	}

	/**
	 * Displays the states.
	 */
	public void displayStates() {

		HetReporter.printInStandardOutput("t0_chillingState: " + t0_chillingState);
		HetReporter.printInStandardOutput("t1_forcingState: " + t1_forcingState);
		HetReporter.printInStandardOutput("t2a_budburstState: " + t2a_budburstState);
		HetReporter.printInStandardOutput("t3_ageingState: " + t3_ageingState);
		HetReporter.printInStandardOutput("t0_chillingStateNext: " + t0_chillingStateNext);
		HetReporter.printInStandardOutput("t1_forcingStateNext: " + t1_forcingStateNext);
	}

	/**
	 * Displays the foliage state: ladprop and greenProp for each doy (day of year)
	 */
	public void displayFoliageState() {

		for (int doy : doyGreenPropMap.keySet()) {
			HetReporter.printInStandardOutput("doy: " + doy + "  greenProp: " + doyGreenPropMap.get(doy));
		}

		HetReporter.printInStandardOutput("");

		for (int doy : doyLadPropMap.keySet()) {
			HetReporter.printInStandardOutput("doy: " + doy + "  ladProp: " + doyLadPropMap.get(doy));
		}

	}

	public HetPhenologyDate getT0_chillingStartingDate() {
		return t0_chillingStartingDate;
	}

	public double getT0_chillingState() {
		return t0_chillingState;
	}

	public void setT0_chillingState(double t0_chillingState) {
		this.t0_chillingState = t0_chillingState;
	}

	public HetPhenologyDate getT1_forcingStartingDate() {
		return t1_forcingStartingDate;
	}

	public double getT1_forcingState() {
		return t1_forcingState;
	}

	public void setT1_forcingState(double t1_forcingState) {
		this.t1_forcingState = t1_forcingState;
	}

	public HetPhenologyDate getT2a_standBudburstStartingDate() {
		return t2a_standBudburstStartingDate;
	}

	public HetPhenologyDate getT2b_averageTreeBudburstDate() {
		return t2b_averageTreeBudburstDate;
	}

	public double getT2a_budburstState() {
		return t2a_budburstState;
	}

	public void setT2a_budburstState(double t2a_budburstState) {
		this.t2a_budburstState = t2a_budburstState;
	}

	public HetPhenologyDate getT2c_completeLeafDevelopmentDate() {
		return t2c_completeLeafDevelopmentDate;
	}

	public HetPhenologyDate getT3_ageingStartingDate() {
		return t3_ageingStartingDate;
	}

	public double getT3_ageingState() {
		return t3_ageingState;
	}

	public void setT3_ageingState(double t3_ageingState) {
		this.t3_ageingState = t3_ageingState;
	}

	public HetPhenologyDate getT4a_yellowingStartingDate() {
		return t4a_yellowingStartingDate;
	}

	public HetPhenologyDate getT4b_yellowingEndingDate() {
		return t4b_yellowingEndingDate;
	}

	public HetPhenologyDate getT5a_fallingStartingDate() {
		return t5a_fallingStartingDate;
	}

	public HetPhenologyDate getT5b_fallingEndingDate() {
		return t5b_fallingEndingDate;
	}

	public HetPhenologyDate getT0_chillingStartingDateNext() {
		return t0_chillingStartingDateNext;
	}

	public double getT0_chillingStateNext() {
		return t0_chillingStateNext;
	}

	public void setT0_chillingStateNext(double t0_chillingStateNext) {
		this.t0_chillingStateNext = t0_chillingStateNext;
	}

	public HetPhenologyDate getT1_forcingStartingDateNext() {
		return t1_forcingStartingDateNext;
	}

	public double getT1_forcingStateNext() {
		return t1_forcingStateNext;
	}

	public void setT1_forcingStateNext(double t1_forcingStateNext) {
		this.t1_forcingStateNext = t1_forcingStateNext;
	}

	public HetPhenologyModel getModel() {
		return model;
	}

	public HashMap<Integer, Double> getDoyGreenPropMap() {
		return doyGreenPropMap;
	}

	public HashMap<Integer, Double> getDoyLadPropMap() {
		return doyLadPropMap;
	}

	/**
	 * A convenient view of the phenology object.
	 */
	@Override
	public String toString() {
		return "HetPhenology t2b_averageTreeBudburstDate: " + t2b_averageTreeBudburstDate; // fc-28.6.2017
	}

}