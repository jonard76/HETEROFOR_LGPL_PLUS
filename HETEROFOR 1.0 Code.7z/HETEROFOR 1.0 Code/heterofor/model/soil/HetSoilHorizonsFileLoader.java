/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soil;

import java.util.List;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for the Heterofor soil horizons file.
 *
 * @author F. de Coligny - September 2016
 */
public class HetSoilHorizonsFileLoader extends FileLoader {

	public double minSoilSurfaceConductance;
	public double maxSoilSurfaceConductance;
	public double compensatoryEffectConductance;
	public double preferentialFlowProportion;
	public List<Horizon> horizonLines;

	/**
	 * Constructor
	 */
	public HetSoilHorizonsFileLoader() throws Exception {
		super();

		// // Needed: the complex sections will be evaluated afterwards based on
		// // expected line prefixes (e.g. soilSolution...)
		// // -> unrecognized lines are turned into UnknownRecords
		// setMemorizeWrongLines(true);
		//
		// // addAdditionalClass(HetChemicalElement.class);
	}

	/**
	 * Replaces on the fly "NA" by 0 in the height column.
	 */
	protected String correctLine(String line) {
		return line.replace("NA", ""+HetHorizon.NOT_SET);
	}

	/**
	 * Loads the soil horizons file and store the species in the given map.
	 */
	public void load(String fileName, HetInitialParameters ip, HetModel model, HetScene scene) throws Exception {

		// 1. Load the file
		super.load(fileName);

		// fc-6.12.2017 no more report in FileLoader

//		String report = super.load(fileName);

		// for (Record record : this) {
		// System.out.println("Record: " + record.getClass() + ": " + record);
		// }

		// 2. Evaluate content
		try {

			// Create the soil object
			HetSoil soil = new HetSoil();

			// fc+mj+lw-20.10.2016
			soil.setMinSoilSurfaceConductance(minSoilSurfaceConductance);
			soil.setMaxSoilSurfaceConductance(maxSoilSurfaceConductance);

			// fc+mj-14.9.2017
			soil.setCompensatoryEffectConductance(compensatoryEffectConductance);

			//fa-29.09.2017
			soil.setPreferentialFlowProportion(preferentialFlowProportion);


			scene.setSoil(soil);

			// Load and add the soil horizons
			for (Horizon l : horizonLines) {

				double thickness = l.upperLimit - l.lowerLimit;
				double volume = thickness * 1; // per m2
				double additionalCoarseFraction = (l.totalCoarseFraction - l.samplingCoarseFraction) / (1d - l.samplingCoarseFraction); //mj+fa-19.06.2019

//				HetHorizon h = new HetHorizon(l.id, l.name, l.upperLimit, l.lowerLimit, thickness, volume,
//						l.coarseFraction, l.bulkDensity, l.sand, l.silt, l.clay, l.organicCarbon, l.meanWaterContent,
//						l.wiltingPointWaterContent, l.saturatedWaterContent, l.solution_pH, l.logpCO2,
//						l.fineRootProportion, l.tortuosityFactor);
				//fa-19.06.2019: splitted coarseFraction into totalCoarseFraction & samplingCoarseFraction
				HetHorizon h = new HetHorizon(l.id, l.name, l.upperLimit, l.lowerLimit, thickness, volume,
						l.totalCoarseFraction, l.samplingCoarseFraction, additionalCoarseFraction, l.bulkDensity, l.sand, l.silt, l.clay, l.organicCarbon, l.meanWaterContent,
						l.wiltingPointWaterContent, l.saturatedWaterContent, l.solution_pH, l.logpCO2,
						l.fineRootProportion, l.tortuosityFactor);

				soil.addHorizon(h);
			}
		} catch (Exception e) {
			setSuccess (false);
			Log.println(Log.ERROR, "HetSoilHorizonsFileLoader.load ()",
					"An error occurred during soil horizons file loading", e);
			throw new Exception ("An error occurred during soil horizons file loading: " + e
					+ ", see the Log for further information", e);
		}

//		return report;
	}

	@Override
	protected void checks() throws Exception {
		// // Each treeId must be found only once in the file
		// Set<Integer> treeIds = new HashSet<Integer> ();
		// for (Line l : lines) {
		// if (treeIds.contains(l.treeId))
		// throw new Exception
		// ("Error in file: found a treeId several times: "+l.treeId);
		// }

	}

	// A horizon line in the file
	@Import
	static public class Horizon extends Record {

		public int id;
		public String name;
		public double upperLimit; // m
		public double lowerLimit; // m
		// public double thickness; // m CALCULATED
		// public double volume; // for an area of 1 m2 CALCULATED
		public double totalCoarseFraction; // "fraction grossi�re sur le volume total (horizon)" (cailloux), m3 total stone/m3 total soil
										// [0,
										// 1]
		public double samplingCoarseFraction; // "fraction grossi�re pour le volume �chantillonn� (kopecky)" (cailloux), m3 stone in kopecky/m3 kopecky
										// [0,
										// 1]
		public double bulkDensity; // kg/m3
		public double sand; // g/g
		public double silt; // "limon", g/g
		public double clay; // "argile", g/g
		public double organicCarbon; // mg/g
		public double meanWaterContent; // m3/m3
		public double wiltingPointWaterContent; // m3/m3
		public double saturatedWaterContent; // m3/m3
		public double solution_pH;
		public double logpCO2; // with pCO2 in atm
		public double fineRootProportion; // %, [0, 1]
		public double tortuosityFactor; // (m/m) // fc+mj-10.5.2016

		public Horizon() {
			super();
		}

		public Horizon(String line) throws Exception {
			super(line);
		}

	}

}
