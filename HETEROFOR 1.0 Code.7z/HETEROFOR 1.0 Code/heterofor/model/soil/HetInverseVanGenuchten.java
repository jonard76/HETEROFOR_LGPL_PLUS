/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soil;

import heterofor.model.HetReporter;

/**
 * The inverse van Genuchten function computes matric potential (cm) from water content.
 *
 * @author M. Jonard, Louis de Wergifosse, F. de Coligny - October 2016
 */
public class HetInverseVanGenuchten {

	private HetHorizon horizon;
	private HetHydraulicPedotransferParameters params;
	private double waterContent;

	/**
	 * Constructor
	 */
	public HetInverseVanGenuchten(HetHorizon horizon, HetHydraulicPedotransferParameters params, double waterContent) {
		this.horizon = horizon;
		this.params = params;
		this.waterContent = waterContent;
	}


	public double execute() {

		double relativeSaturation = (waterContent - params.residualWaterContent)
				/ (params.saturatedWaterContent - params.residualWaterContent);

		//mj+fa-02.10.2017
		relativeSaturation = Math.min(1d, relativeSaturation);
//		relativeSaturation = Math.max(0d, relativeSaturation);
		relativeSaturation = Math.max(0.00000000001, relativeSaturation); // 0.00000000001 to be just above 0, otherwise below 'a' will be Infinity (0^-1/m)


		double m = 1d - 1d / params.n;

		double a = Math.pow(relativeSaturation, -1 / m) - 1;
		double h = Math.abs(Math.pow(a, 1d / params.n) / params.alpha); // fc+mj-7.3.2017 added abs

		if (Double.isNaN(h))
			HetReporter.printInStandardOutput("HetInverseVanGenuchten, relativeSaturation= " + relativeSaturation + ", h= " + h);

//		if (relativeSaturation < 1d)
//			h = -h;
//		else
//			h = 0;

		return h;

	}





}
