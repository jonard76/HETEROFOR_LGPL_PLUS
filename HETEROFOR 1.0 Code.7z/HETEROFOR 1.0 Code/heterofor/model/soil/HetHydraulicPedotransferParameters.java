/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soil;

/**
 * Computes the parameters of the Mualem-van Genuchten functions.
 *
 * @author M. Jonard, Louis de Wergifoose, F. de Coligny - October 2016
 */
public class HetHydraulicPedotransferParameters {

	private HetHorizon horizon;

	public double residualWaterContent; // m3/m3
	public double saturatedWaterContent; // m3/m3
//	public double virtualWaterContent; // m3/m3
	public double alpha;
	public double n;
	public double K0; // cm/day
	public double lambda;
//	public double tau;

	/**
	 * Constructor
	 */
	public HetHydraulicPedotransferParameters(HetHorizon horizon) {
		this.horizon = horizon;
	}

	/**
	 * Copy constructor
	 */
	public HetHydraulicPedotransferParameters(HetHydraulicPedotransferParameters original) {
		// fc+mj-14.9.2017
		this.horizon = original.horizon;
		this.residualWaterContent = original.residualWaterContent;
		this.saturatedWaterContent = original.saturatedWaterContent;
//		this.virtualWaterContent = original.virtualWaterContent;
		this.alpha = original.alpha;
		this.n = original.n;
		this.K0 = original.K0;
		this.lambda = original.lambda;
//		this.tau = original.tau;
	}

	/**
	 * Run execute (), then the six parameters are available.
	 */
	public void execute() {

		saturatedWaterContent = horizon.saturatedWaterContent;

		// MOVED to HetHorizon
		// if (horizon.saturatedWaterContent == HetHorizon.NOT_SET) {
		// saturatedWaterContent = 0.6355 + 0.0013 * horizon.clay * 100d -
		// 0.1631 * horizon.bulkDensity;
		// }

		residualWaterContent = horizon.residualWaterContent;

		// MOVED to HetHorizon
		// if (horizon.residualWaterContent == HetHorizon.NOT_SET) {
		// // Missing values for a1, b1 c1 in Weynants et al. 2009 (...)
		// // residualWaterContent = 1 + 1 * horizon.clay * 100d + 1 *
		// // horizon.organicCarbon;
		// // To be reviewed (...)
		// residualWaterContent = 1d / 2d * saturatedWaterContent;
		// }

		// Pedo transfer function probably not valid for organic horizons
		if (horizon.lowerLimit >= 0) {

			// // Values from Dettmann et al. 2014
			// alpha = 0.251;
			// n = 1.75;

			// // Values from van Genuchten 1980 for Beit Netofa Clay
			// K0 = 0.082;
			// //
			// lambda = -6;

			// lw-7.3.2017
			// Values from Paivanen 1973 for Sphagnum peat
			// This function seems to be better // fc+mj-8.3.2017
			K0 = Math.pow(10, -2.321 - 13.22 * horizon.bulkDensity * 1000d / 1000000d) * 24 * 60 * 60; // cm/day

			// Values from Paivanen 1973 for sedge peat
//			K0 = Math.pow(10, -1.924 - 10.702 * horizon.bulkDensity * 1000d / 1000000d) * 24 * 60 * 60; // cm/day

			// Values from Dettmann et al. 2014
//			virtualWaterContent = horizon.saturatedWaterContent ;
			alpha = 0.251;
			n = 1.75;
			lambda = 0.5;
//			tau = 0.5;

		} else {

		// Weynants PTF
			double lnAlpha = -4.3003 - 0.0097 * horizon.clay * 100d + 0.0138 * horizon.sand * 100d - 0.0992
					* horizon.organicCarbon / 1000d;
			alpha = Math.exp(lnAlpha);

			double lnN_1 = -1.0846 - 0.0236 * horizon.clay * 100d - 0.0085 * horizon.sand * 100d + 0.0001
					* horizon.sand * 100d * horizon.sand * 100d;

			double n_1 = Math.exp(lnN_1);
			n = n_1 + 1;

			double lnK0 = 1.9582 + 0.0308 * horizon.sand * 100d - 0.6142 * horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction) - 0.1566
					* horizon.organicCarbon / 1000d;
			K0 = Math.exp(lnK0);

			lambda = -1.8642 - 0.1317 * horizon.clay * 100d + 0.0067 * horizon.sand * 100d;

		}

		// Puhlmann PTF // lw-28.06.2019

//			double lnAlpha = 2.021 - 1.187 * (horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction)) * (horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction))
//					-0.031899 * horizon.sand * 100d - 0.58805 * Math.log(horizon.organicCarbon / 10d + 0.1)
//					- 0.00032963 * horizon.silt * 100d * horizon.silt * 100d - 0.016267 * horizon.silt * 100d * horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction);

//			alpha = Math.exp(lnAlpha);

//			double lnN_1 = -2.9804 + 0.0003758 * horizon.sand * 100d * horizon.sand * 100d + 0.004751 * horizon.silt * 100d
//					+ 0.017826 * horizon.silt * 100d / (horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction)) ;

//			double n_1 = Math.exp(lnN_1);
//			n = n_1 + 1d;

//			double log10K0 = -1.10316 - 1.2491 * (horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction)) * (horizon.bulkDensity / 1000d / (1d - horizon.samplingCoarseFraction)) - 0.00087388 *
//					horizon.clay * 100d * horizon.clay * 100d ;

//			K0 = Math.pow(10,log10K0)* 24 * 60 * 60;

//			lambda = -1.8642 - 0.1317 * horizon.clay * 100d + 0.0067 * horizon.sand * 100d; // Not used in Puhlmann but kept to avoid potential problems

//			tau = 4.4304 - 0.98063 * Math.log(horizon.sand * 100d + 0.1) - 0.004075 * horizon.clay * 100d * horizon.clay * 100d
//					+ 0.030022 * horizon.clay * 100d * horizon.organicCarbon / 10d - 0.00457 * horizon.sand * 100d / (horizon.organicCarbon / 10d) ;

//			virtualWaterContent = horizon.residualWaterContent + (horizon.saturatedWaterContent - horizon.residualWaterContent) * Math.pow(1d + Math.pow(2d * alpha, n),(1d - 1d / n)) ;
//			virtualWaterContent = Math.max(virtualWaterContent , horizon.saturatedWaterContent) ;
//		}

	}

	@Override
	public String toString() {
		return "HydraulicPedotransferParameters (residualWaterContent: " + residualWaterContent
				+ " saturatedWaterContent: " + saturatedWaterContent + " alpha: " + alpha + " n: " + n + " K0: " + K0
				+ " lambda: " + lambda + ")";
	}

}
