/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.io.Serializable;

/**
 * A tool object to calculate for a given tree and delta dbh the biomass and
 * production for all functional compartments (leaf, fine root, mycorrhizae).
 *
 * @author M. Jonard - January 2012
 */
public class HetFunctionalCompartmentsProduction implements Serializable {

	private HetTree tree;
	private HetSpecies species;

	public double newPotentialLeafBiomass_kgC;
	public double newLeafBiomass_kgC;
	public double newLeafBiomassProduction_kgC;
	public double newFineRootBiomass_kgC;
	public double newFineRootBiomassProduction_kgC;
	public double newFineRootLength;
	public double newFineRootVolume;
	public double newFineRootDiameter;
	public double newHyphaLength;
	public double newMycorrhizaeBiomass_kgC;
	public double newMycorrhizaeBiomassProduction_kgC;
	public double newRhizosphereBiomassProduction_kgC;

	public double newDefoliation; // %, kgC/100kgC, fc+mj-9.3.2017

	// fc+mj-12.9.2017 fakeGrowth is now in ip
//	// true: we are in a fake growth process in order to update leaf and fine
//	// root biomass
//	public boolean fakeGrowth;

	private HetInitialParameters ip;

	/**
	 * Constructor
	 */
	public HetFunctionalCompartmentsProduction(HetInitialParameters ip, HetTree tree, double deltaDbh_cm) {

		this.tree = tree;
		this.species = tree.getSpecies();
		this.ip = ip;

		double dbh = tree.getDbh();
		double mean2CrownRadius = tree.getMean2CrownRadius();
		double leafBiomass_kgC = tree.getLeafBiomass_kgC();
		double fineRootBiomass_kgC = tree.getFineRootBiomass_kgC();

		newLeafBiomass_kgC = species.leafBiomassAllometry.result(dbh, dbh + deltaDbh_cm, mean2CrownRadius,
				species.leafRetranslocationRate);

		newPotentialLeafBiomass_kgC = newLeafBiomass_kgC; // fc+mj-9.3.2017

		newLeafBiomassProduction_kgC = species.leafRelativeLossRate * leafBiomass_kgC
				+ (newLeafBiomass_kgC - leafBiomass_kgC);

		// fc+mj-9.12.2016 Error: ratio was changed in refTree (see below)
		double fineRootToFoliageRatio = tree.getFineRootToFoliageRatio();

//		// newFineRootBiomass_kgC
//		double fineRootToFoliageRatio = tree.fineRootSensitivityToNutrientStatus(ip.foliarChemistryThresholds,
//				species.minFineRootToFoliageRatio, species.maxFineRootToFoliageRatio);
//
//		// fc+mj-28.9.2016
//		tree.setFineRootToFoliageRatio(fineRootToFoliageRatio);

		newFineRootBiomass_kgC = fineRootToFoliageRatio * newLeafBiomass_kgC;
		newFineRootBiomassProduction_kgC = species.fineRootRelativeLossRate * fineRootBiomass_kgC
				+ (newFineRootBiomass_kgC - fineRootBiomass_kgC);

//		if (newFineRootBiomassProduction_kgC < 0)
//			System.out.println();

		// newMycorrhizaeBiomass_kgC
		double newFineRootBiomass_gOM = newFineRootBiomass_kgC * 1000 / 0.5;
		newFineRootLength = newFineRootBiomass_gOM * tree.getSRL(); // m

		newFineRootVolume = (newFineRootBiomass_gOM / 1000d) / species.rootVolumetricMass; // m3
		newFineRootDiameter = Math.sqrt(newFineRootVolume / (Math.PI * newFineRootLength)) * 2 * 100; // cm

		newHyphaLength = newFineRootLength * species.hyphaToRootLengthRatio; // m
		double newMycorrhizaeBiomass_kgOM = (newHyphaLength / (species.specificHyphaLength * 1000d)) / 1000d; // kgOM
		newMycorrhizaeBiomass_kgC = newMycorrhizaeBiomass_kgOM * 0.5;

		// newMycorrhizaeBiomassProduction_kgC
		double newFineRootBiomassProduction_gOM = newFineRootBiomassProduction_kgC * 1000 / 0.5;
		double newFineRootLengthProduction = newFineRootBiomassProduction_gOM * tree.getSRL(); // m

		double newHyphaLengthProduction = newFineRootLengthProduction * species.hyphaToRootLengthRatio; // m
		double newMycorrhizaeBiomassProduction_kgOM = (newHyphaLengthProduction / (species.specificHyphaLength * 1000d)) / 1000d; // kgOM
		newMycorrhizaeBiomassProduction_kgC = newMycorrhizaeBiomassProduction_kgOM * 0.5;

		newRhizosphereBiomassProduction_kgC = newFineRootBiomassProduction_kgC + newMycorrhizaeBiomassProduction_kgC;

	}

	public void correction(double netPrimaryProduction_kgC, double retranslocation_kgC) {

		double leafBiomass_kgC = tree.getLeafBiomass_kgC();
		double fineRootBiomass_kgC = tree.getFineRootBiomass_kgC();

		double leafToFunctionalBiomassProductionRatio = newLeafBiomassProduction_kgC
				/ (newLeafBiomassProduction_kgC + newRhizosphereBiomassProduction_kgC);

		if (newLeafBiomassProduction_kgC > leafToFunctionalBiomassProductionRatio
				* (netPrimaryProduction_kgC + retranslocation_kgC)) {

			// fc+mj-9.3.2017 TESTING, added 0.9 *
			newLeafBiomassProduction_kgC = 0.9 * leafToFunctionalBiomassProductionRatio
					* (netPrimaryProduction_kgC + retranslocation_kgC);

			// Special case if fakeGrowth or negative result
			newLeafBiomass_kgC = newLeafBiomassProduction_kgC - species.leafRelativeLossRate * leafBiomass_kgC
					+ leafBiomass_kgC; // added by MJ

			newDefoliation = (newPotentialLeafBiomass_kgC - newLeafBiomass_kgC) / newPotentialLeafBiomass_kgC * 100d;

			if (ip.fakeGrowth || newLeafBiomass_kgC < 0)
				newLeafBiomass_kgC = newLeafBiomassProduction_kgC;

		}
		if (newRhizosphereBiomassProduction_kgC > (1 - leafToFunctionalBiomassProductionRatio)
				* (netPrimaryProduction_kgC + retranslocation_kgC)) {

			double fineRootToRhizosphereBiomassProductionRatio = newFineRootBiomassProduction_kgC
					/ newRhizosphereBiomassProduction_kgC; // added by MJ

			newRhizosphereBiomassProduction_kgC = (1 - leafToFunctionalBiomassProductionRatio)
					* (netPrimaryProduction_kgC + retranslocation_kgC);
			newFineRootBiomassProduction_kgC = fineRootToRhizosphereBiomassProductionRatio
					* newRhizosphereBiomassProduction_kgC; // added by MJ


			newFineRootBiomass_kgC = newFineRootBiomassProduction_kgC - species.fineRootRelativeLossRate
					* fineRootBiomass_kgC; // added by MJ

			// Special case if fakeGrowth or negative result
			if (ip.fakeGrowth || newFineRootBiomass_kgC < 0)
				newFineRootBiomass_kgC = newFineRootBiomassProduction_kgC;

			if (newFineRootBiomass_kgC < 0)
				HetReporter.printInStandardOutput("");

			newMycorrhizaeBiomassProduction_kgC = newRhizosphereBiomassProduction_kgC
					- newFineRootBiomassProduction_kgC;// added by MJ
			newMycorrhizaeBiomass_kgC = newMycorrhizaeBiomassProduction_kgC;// added
																			// by
																			// MJ
		}

	}

}
