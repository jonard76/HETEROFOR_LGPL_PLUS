/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.myscripts;

import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
// import heterofor.model.HetSensor;
import heterofor.model.HetTree;

import java.awt.Rectangle;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.Translator;
import capsis.app.C4Script;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.GTreeIdComparator;
import capsis.lib.samsaralight.SLModel;
import capsis.extension.intervener.*;
import gymnos.extension.intervener.*;
import capsis.extension.memorizer.DefaultMemorizer;


/**
 * A script for Heterofor. The script needs one parameter: a command file name (See
 * CommandFileReader_Test). To run the script from a windows terminal:
 *
 * <pre>
 * capsis -p script heterofor.myscripts.CommandScript <commandFileName>
 * </pre>
 *
 * @author F. Andre, March 2018
 */
public class Castanea_RatioNppGpp_10years {

	public static void main (String[] args) throws Exception {

//		long startCalibTime = System.currentTimeMillis();

		// Check the parameters
		// args[0] is the name of this script: heterofor.myscripts.CommandScript (useless)
		// args[1] is workingDir
		// args[2] is exportReconstructionFileName
		// args[3] is exportSimulationFileName
		// args[4] is turbid medium activated (true or false)
		// args[5] is crownForm (Ec, Ed, Bc, Bd or M)
		// args[6] is ladOption
		// args[7-10] are extinction coefficients for oak, beech, carpinus, others
		// args[11-14] are SLAbottom for oak, beech, carpinus, others
		// args[15-18] are SLAtop for oak, beech, carpinus, others
		// args[19-22] are UFLB for oak, beech, carpinus, others
		// args[23-26] are alpha for oak, beech, carpinus, others
		// args[27-30] are beta for oak, beech, carpinus, others
		// args[31-34] are NppToGppRatio_intercept for oak, beech, carpinus, others for Baileux
		// args[35-38] are NppToGppRatio_slope for oak, beech, carpinus, others for Baileux
		// args[39-42] are NppToGppRatio_intercept for oak, beech, carpinus, others for Chimay
		// args[43-46] are NppToGppRatio_slope for oak, beech, carpinus, others for Chimay
		// args[47-50] are NppToGppRatio_intercept for oak, beech, carpinus, others for LLN
		// args[51-54] are NppToGppRatio_slope for oak, beech, carpinus, others for LLN
		// args[55-58] are NppToGppRatio_intercept for oak, beech, carpinus, others for Virton
		// args[59-62] are NppToGppRatio_slope for oak, beech, carpinus, others for Virton
		// args[63] is reconstruction activated (true or false)
		// args[64] is growthCompetitionAccounted

		String workingDir = args[1];
		String exportReconstructionFileName = args[2];
		String exportSimulationFileName = args[3];

		String inventoryDirectoryName = workingDir + "/data/heterofor/inventories/CalibNPP";
		File[] inventoryFilesInv1 = listInventoryFiles(inventoryDirectoryName, ".inv1"); // Starting inventory files: .inv1
		File[] inventoryFilesInv2 = listInventoryFiles(inventoryDirectoryName, ".inv2"); // Ending inventory files: .inv2

		System.out.println (inventoryDirectoryName);

		// Performs simulation for each inventory file
		int count = 0;
		for(File initInventoryFile : inventoryFilesInv1) {
	        count++;
	        File finalInventoryFile = null;
	        for(File endInventoryFile : inventoryFilesInv2) {
		        if (endInventoryFile.getName().contains(initInventoryFile.getName().substring(0, initInventoryFile.getName().length()-9))) { // look for ending inventory file corresponding to init inventory file (same plot)
		        	finalInventoryFile = endInventoryFile;
		        	break;
		        }
	         }
			runOneSimulation (initInventoryFile, finalInventoryFile, workingDir, exportReconstructionFileName, exportSimulationFileName, count, args);
         }

//		long endCalibTime = System.currentTimeMillis();
//		long elapsedTime = (endCalibTime - startCalibTime) / (long) 1000.0;

//		System.out.println ("heterofor.myscripts.CallibrationRadiationInterception is over, elapsed time: " + elapsedTime + " seconds");
		System.out.println ("heterofor.myscripts.CallibrationRadiationInterception is over");
		System.out.println ("\n");
		System.out.println ("######################################################################################");
		System.out.println ("\n");

	}

	/**
	 * Called for inventory file, runs one simulation and write the sensors in the export file.
	 */
	static private void runOneSimulation (File initInventoryFile, File finalInventoryFile, String workingDir, String exportReconstructionFileName,  String exportSimulationFileName,int count, String[] args) throws Exception {

		System.out.println ("Heterofor CalibrationScript, running simulation " + count
				+ " for the following inventory file:\n " + initInventoryFile);

		String initInventoryFileName = initInventoryFile.getName();
		String finalInventoryFileName = finalInventoryFile.getName();
		String plotName = initInventoryFileName.substring(0,initInventoryFileName.lastIndexOf('_'));
		String siteName = plotName.substring(0,plotName.indexOf("_"));

		// Step1: Initialization
		C4Script s = new C4Script ("heterofor");

		// CrownForm, used to select the appropriate species file
		String crownForm_arg = args[5];

		// Simulation settings
		HetInitialParameters ip0 = new HetInitialParameters ();
		ip0.speciesFileName = workingDir + "/data/heterofor/inventories/CalibNPP/heterofor_species_" + crownForm_arg + ".txt"; // specisFile specific for each crown form
		ip0.castaneaFileName = workingDir + "/data/heterofor/CastaneaSpecies3.txt"; //workingDir + "/" + line.castaneaFileName;
//!\		ip0.inventoryFileName = initInventoryFile.getPath();
		ip0.inventoryFileName = initInventoryFile.getPath();
		ip0.samsaraLightFileName = workingDir + "/data/heterofor/samsaralight/samsaraLight_settings_monthly.txt";
		ip0.soilHorizonsFileName = workingDir + "/data/heterofor/soilHorizons/soilHorizons_" + plotName + ".txt"; // line.soilHorizonsFileName;
//		ip0.soilChemistryFileName = workingDir + "/" + line.soilChemistryFileName;
		ip0.meteorologyFileName = workingDir + "/data/heterofor/meteorology/Meteorology_" + siteName + "_1999_2016.txt"; //line.MeteorologyFileName;
		if (!siteName.equals("Baileux"))
			ip0.fructificationFileName = workingDir + "/data/heterofor/inventories/CalibNPP/" + plotName + "_fruitLitterFall.txt";
		ip0.fineResolutionRadiativeBalanceActivated = false; //line.fineResolutionRadiativeBalanceActivated;
		ip0.radiationCalculationTimeStep = 1; //line.radiationCalculationTimeStep;
		ip0.phenologyActivated = true; //line.phenologyActivated;
		ip0.waterBalanceActivated = true; //line.waterBalanceActivated;
		ip0.waterBalance_treeLevelTranspiration = true; //line.waterBalance_treeLevelTranspiration;
		ip0.castaneaPhotosynthesisActivated = true; //line.castaneaPhotosynthesisActivated;
		ip0.pueEmpiricalMethod = true; //line.pueEmpiricalMethod;
		ip0.constantNppToGppRatio = true; //line.constantNppToGppRatio;
		ip0.mineralHorizonsTemperatureCalculationActivated = false; //line.mineralHorizonsTemperatureCalculationActivated;
		ip0.competitionAccountedForCrownGrowth = Boolean.valueOf(args[64]); // false; //line.competitionAccountedForGrowth;
		ip0.generalNutrientLimitation = false; //line.generalNutrientLimitation;
		ip0.nLimitation = false; //line.nLimitation;
//		if (siteName.equals("Baileux"))
			ip0.heightGrowthOption = "BAILEUX_SITE"; //line.heightGrowthOption; // "IPRFW", "BAILEUX_SITE", "POTENTIAL_MODIFIERS_HEIGHT_GROWTH"
//		else
//			ip0.heightGrowthOption = "IPRFW"; //line.heightGrowthOption; // "IPRFW", "BAILEUX_SITE", "POTENTIAL_MODIFIERS_HEIGHT_GROWTH"
		ip0.mortalityActivated = false; //line.mortalityActivated;

		// Init simulation
//		s.init (i);
		HetModel model = (HetModel) s.getModel ();
		ip0.buildInitScene(model); //  !!!!! crownForm of trees fixed at this stage from value in speciesFile !!!!!

		// Modify settings for optimized parameters
		boolean turbidMediumActivated_arg = Boolean.valueOf(args[4]);
		int LADoption_arg = Integer.valueOf(args[6]);

		ip0.samsaFileLoader.setTurbidMedium(turbidMediumActivated_arg);

		Map<Integer, HetSpecies> speciesMap = ip0.getSpeciesMap();
		for (int speciesId : speciesMap.keySet()) {

			speciesMap.get(speciesId).LADoption = LADoption_arg;
//			speciesMap.get(speciesId).setCrownForm(crownForm_arg); // crownForm is already set previously (buildInitScene), from speciesFile

			double[] extinctionCoefficient_arg = new double[4];
			extinctionCoefficient_arg[0] = Double.valueOf(args[7]);
			extinctionCoefficient_arg[1] = Double.valueOf(args[8]);
			extinctionCoefficient_arg[2] = Double.valueOf(args[9]);
			extinctionCoefficient_arg[3] = Double.valueOf(args[10]);

			double[] slaBottom_arg = new double[4];
			slaBottom_arg[0] = Double.valueOf(args[11]);
			slaBottom_arg[1] = Double.valueOf(args[12]);
			slaBottom_arg[2] = Double.valueOf(args[13]);
			slaBottom_arg[3] = Double.valueOf(args[14]);

			double[] slaTop_arg = new double[4];
			slaTop_arg[0] = Double.valueOf(args[15]);
			slaTop_arg[1] = Double.valueOf(args[16]);
			slaTop_arg[2] = Double.valueOf(args[17]);
			slaTop_arg[3] = Double.valueOf(args[18]);

			double[] UFLB_arg = new double[4];
			UFLB_arg[0] = Double.valueOf(args[19]);
			UFLB_arg[1] = Double.valueOf(args[20]);
			UFLB_arg[2] = Double.valueOf(args[21]);
			UFLB_arg[3] = Double.valueOf(args[22]);

			double[] alpha_arg = new double[4];
			alpha_arg[0] = Double.valueOf(args[23]);
			alpha_arg[1] = Double.valueOf(args[24]);
			alpha_arg[2] = Double.valueOf(args[25]);
			alpha_arg[3] = Double.valueOf(args[26]);

			double[] beta_arg = new double[4];
			beta_arg[0] = Double.valueOf(args[27]);
			beta_arg[1] = Double.valueOf(args[28]);
			beta_arg[2] = Double.valueOf(args[29]);
			beta_arg[3] = Double.valueOf(args[30]);

			double[] NppToGppRatio_intercept_Baileux_arg = new double[4];
			NppToGppRatio_intercept_Baileux_arg[0] = Double.valueOf(args[31]);
			NppToGppRatio_intercept_Baileux_arg[1] = Double.valueOf(args[32]);
			NppToGppRatio_intercept_Baileux_arg[2] = Double.valueOf(args[33]);
			NppToGppRatio_intercept_Baileux_arg[3] = Double.valueOf(args[34]);

			double[] NppToGppRatio_slope_Baileux_arg = new double[4];
			NppToGppRatio_slope_Baileux_arg[0] = Double.valueOf(args[35]);
			NppToGppRatio_slope_Baileux_arg[1] = Double.valueOf(args[36]);
			NppToGppRatio_slope_Baileux_arg[2] = Double.valueOf(args[37]);
			NppToGppRatio_slope_Baileux_arg[3] = Double.valueOf(args[38]);

			double[] NppToGppRatio_intercept_Chimay_arg = new double[4];
			NppToGppRatio_intercept_Chimay_arg[0] = Double.valueOf(args[39]);
			NppToGppRatio_intercept_Chimay_arg[1] = Double.valueOf(args[40]);
			NppToGppRatio_intercept_Chimay_arg[2] = Double.valueOf(args[41]);
			NppToGppRatio_intercept_Chimay_arg[3] = Double.valueOf(args[42]);

			double[] NppToGppRatio_slope_Chimay_arg = new double[4];
			NppToGppRatio_slope_Chimay_arg[0] = Double.valueOf(args[43]);
			NppToGppRatio_slope_Chimay_arg[1] = Double.valueOf(args[44]);
			NppToGppRatio_slope_Chimay_arg[2] = Double.valueOf(args[45]);
			NppToGppRatio_slope_Chimay_arg[3] = Double.valueOf(args[46]);

			double[] NppToGppRatio_intercept_LLN_arg = new double[4];
			NppToGppRatio_intercept_LLN_arg[0] = Double.valueOf(args[47]);
			NppToGppRatio_intercept_LLN_arg[1] = Double.valueOf(args[48]);
			NppToGppRatio_intercept_LLN_arg[2] = Double.valueOf(args[49]);
			NppToGppRatio_intercept_LLN_arg[3] = Double.valueOf(args[50]);

			double[] NppToGppRatio_slope_LLN_arg = new double[4];
			NppToGppRatio_slope_LLN_arg[0] = Double.valueOf(args[51]);
			NppToGppRatio_slope_LLN_arg[1] = Double.valueOf(args[52]);
			NppToGppRatio_slope_LLN_arg[2] = Double.valueOf(args[53]);
			NppToGppRatio_slope_LLN_arg[3] = Double.valueOf(args[54]);

			double[] NppToGppRatio_intercept_Virton_arg = new double[4];
			NppToGppRatio_intercept_Virton_arg[0] = Double.valueOf(args[55]);
			NppToGppRatio_intercept_Virton_arg[1] = Double.valueOf(args[56]);
			NppToGppRatio_intercept_Virton_arg[2] = Double.valueOf(args[57]);
			NppToGppRatio_intercept_Virton_arg[3] = Double.valueOf(args[58]);

			double[] NppToGppRatio_slope_Virton_arg = new double[4];
			NppToGppRatio_slope_Virton_arg[0] = Double.valueOf(args[59]);
			NppToGppRatio_slope_Virton_arg[1] = Double.valueOf(args[60]);
			NppToGppRatio_slope_Virton_arg[2] = Double.valueOf(args[61]);
			NppToGppRatio_slope_Virton_arg[3] = Double.valueOf(args[62]);


			if (speciesId == 1) { // oak
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[0];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[0];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[0];
				speciesMap.get(speciesId).UFLB = UFLB_arg[0];
				speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[0];
				speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[0];
				speciesMap.get(speciesId).leafBiomassAllometry.gamma = beta_arg[0]; // gamma = beta for oak
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[0];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[0];
				}
				else if (siteName.equals("LLN")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[0];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[0];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}

			} else if (speciesId == 2) { // beech
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[1];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[1];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[1];
				speciesMap.get(speciesId).UFLB = UFLB_arg[1];
				speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[1];
				speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[1];
				speciesMap.get(speciesId).leafBiomassAllometry.gamma = 0d;
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[1];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[1];
				}
				else if (siteName.equals("LLN")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[1];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[1];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}

			} else if (speciesId == 3) { // carpinus
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[2];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[2];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[2];
				speciesMap.get(speciesId).UFLB = UFLB_arg[2];
				speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[2];
				speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[2];
				speciesMap.get(speciesId).leafBiomassAllometry.gamma = 0d;
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[2];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[2];
				}
				else if (siteName.equals("LLN")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[2];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[2];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}

			} else { // others
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[3];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[3];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[3];
				speciesMap.get(speciesId).UFLB = UFLB_arg[3];
//				if (speciesId == 2) { // other species not optimized for leaf biomass allometry parameters
					speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[3];
					speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[3];
					speciesMap.get(speciesId).leafBiomassAllometry.gamma = beta_arg[3]; // gamma = beta for others
//				}
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[3];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[3];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[3];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[3];
				}
				else if (siteName.equals("LLN")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[3];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[3];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[3];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[3];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}
			}
		}

		// Update tree leaf biomass & NppToGppRatio
		HetScene initScene1 = (HetScene) ip0.getInitScene();
		List treesInitScene1 = new ArrayList(initScene1.getTrees());
//		for (Iterator t = initScene1.getTrees().iterator(); t.hasNext();) {
		treesInitScene1.parallelStream().forEach((t) -> {
			HetTree tree = (HetTree) t;

			HetSpecies species = tree.getSpecies();

			double leafBiomass = species.leafBiomassAllometry.result(tree.getDbh(), tree.getDbh(), tree.getMean2CrownRadius(),
					species.leafRetranslocationRate);
			tree.setLeafBiomass(leafBiomass);
			tree.updateStemAndLitters(tree.getLeafCarbonConcentration());
		});
//		}

		boolean reconstructionActivated_arg = Boolean.valueOf(args[63]);

		String trueThinningFileName = workingDir + "/data/heterofor/inventories/CalibNPP/" + plotName + "_thinning.txt";

		// Create project
		String projectName = s.getClass ().getName ();
		Project project = s.createProject (projectName, model, ip0);
		try {
			s.setMemorizer (project, new DefaultMemorizer ());
		} catch (Exception e) {
			Log.println (Log.ERROR, "GScript2.init ()", "Memorizer error", e);
			throw new Exception ("Memorizer error", e);
		}

		Step initStep = s.getRoot ();
		HetScene initScene = (HetScene) initStep.getScene ();
		int initYear = initScene.getDate();
		int finalYear = Integer.valueOf(finalInventoryFileName.substring(finalInventoryFileName.lastIndexOf('_')+1, finalInventoryFileName.lastIndexOf('_')+5));

		// Central scene area, without the buffer zone
		Rectangle.Double innerZone = setInnerZone (initScene);
		System.out.println ("Heterofor CalibrationScript, loaded " + initScene.getTrees ().size () + " trees");


		// Step2: Evolution
		// Determine evolution length
		int evolutionLength = 10;
		System.out.println ("EvolutionLength = " + evolutionLength + ", initYear = " + initYear + ", finalYear = " + finalYear);

		HetEvolutionParameters ep = new HetEvolutionParameters (evolutionLength, trueThinningFileName);
		Step evolutionFinalStep = model.processEvolution(s.getRoot(),ep);
//!\ 31.10.2018: added for detecting thinned trees for export
		Map<Integer, Integer> trueThinningMap = ep.getTrueThinningMap(ep.trueThinningFileName);

		// Interventions
//		Intervener thinner;
/*
		// 1. Diameter, height or age class thinner
		int context = 2; //2: DBH, 3: Height, 4: Age
		float min = 20;
		float max = 50;
		thinner = new DHAThinner(context, min, max);
		step = s.runIntervener(thinner, step);
*/
/*
		// 2. Target basal area
		double targetGHA = 15; // m�/ha
		double type = 0.5; // [0,1], 0 for a from below thinning - 1 for a from above thinning
		boolean excludeTargetTrees = true;
		thinner = new GymnoGHAThinner2 (targetGHA, type, excludeTargetTrees);
		step = s.runIntervener(thinner, step);
*/
		// Export evolution results
		Vector<Step> stepVector = new Vector<Step>(); // list of steps
		// From step to root (backwards)
		Step step = evolutionFinalStep;
		while (!step.isRoot()) { // root not included (NPP=0)
			stepVector.add(step);
			step = (Step) step.getFather();
		}
		// Reverse the list
		Collections.reverse(stepVector);

		// Exports results in text file
		try {
			File f = new File(exportSimulationFileName);
			if(f.exists() && count == 1) // delete existing exportFile if first simulation
				f.delete();

			BufferedWriter out = new BufferedWriter(new FileWriter(exportSimulationFileName, true)); // true to append at the end if file already exists

			if(count == 1){
//				out.write("plotName" + "\t" + "year" + "\t" + "treeId" + "\t" + "deltaD2H");
				out.write("plotName" + "\t" + "year" + "\t" + "treeId" + "\t" + "deltaD2H" + "\t" + "NppGppRatio" + "\t" + "species" + "\t" + "DBH" + "\t" + "Htot" + "\t" + "deltaDBH" + "\t" + "deltatHtot" + "\t" + "deltaG" + "\t" + "GPP" + "\t" + "NPP" + "\t" + "LCI");
				out.newLine();
			}

			for (Step st : stepVector) {
				HetScene sc = (HetScene) st.getScene();
				int year = sc.getDate();

				Set sortedTrees = new TreeSet(new GTreeIdComparator());
				sortedTrees.addAll(sc.getTrees());

				for (Iterator t = sortedTrees.iterator(); t.hasNext();) {
					HetTree tree = (HetTree) t.next();

//!\ Skip trees thinned during reconstruction period (bad estimate of dbh and height increments)
					if (trueThinningMap.containsKey(tree.getId())) {
						if (siteName.equals("Baileux") && trueThinningMap.get(tree.getId()) <= 2011) // reconstruction period from 2001 to 2011 for Baileux plots
							continue;
						else if (trueThinningMap.get(tree.getId()) <= 2009) // reconstruction period from 1999 to 2009 for ICP plots
							continue;
					}

					if (tree.isVirtual())
						continue;

					if (!innerZone.contains(tree.getX(), tree.getY()))
						continue;

//					out.write(plotName + "\t" + year + "\t" + tree.getId() + "\t" + tree.getDeltaDbh2Height());
					out.write(plotName + "\t" + year + "\t" + tree.getId() + "\t" + tree.getDeltaDbh2Height() + "\t" + tree.getNppToGppRatio() + "\t" + tree.getSpecies().getName() + "\t" + tree.getDbh() + "\t" + tree.getHeight() + "\t" + tree.getDeltaDbh_cm() + "\t" + tree.getDeltaHeight() + "\t" + tree.getDeltaG() + "\t" + tree.getGrossPrimaryProduction_kgC() + "\t" + tree.getNetPrimaryProduction_kgC() + "\t" + tree.getLightCompetitionIndex());
					out.newLine();
				}
			}

			out.close();
			System.out.println ("wrote tree GPP values in: " + exportSimulationFileName);
			System.out.println ("\n");
		} catch (Exception e) {
			Log.println(Log.ERROR, "CalibrationRadiationInterception.runOneSimulation", "Could not write in file: " + exportSimulationFileName, e);
		}


//		HetScene finalScene = (HetScene) step.getScene();

//		System.out.println("Heterofor CalibrationScript_Test, final scene has " + finalScene.getTrees().size() + " trees");

		// Close the project
		s.closeProject ();


		// Step3: Reconstruction (optional, if not already processed before)
		if (reconstructionActivated_arg) {
			try {
				// Create project for observations (final inventory)
				C4Script sObs = new C4Script("heterofor");

//!\ 31.10.2018: added as evolution inventory file date is set to 2003
				ip0.inventoryFileName = initInventoryFile.getPath();

				HetInitialParameters ipObs = new HetInitialParameters(ip0);
				ipObs.inventoryFileName = finalInventoryFile.getPath();
				sObs.init(ipObs);
				HetScene obsScene = (HetScene) sObs.getRoot().getScene();
				int obsYear = obsScene.getDate();
				if (obsYear < initYear)
					throw new Exception("ERROR: observation date must be greater than root step date: " + initYear);
				sObs.closeProject();

				// Create project for reconstruction (inverse growth)
				C4Script sRec = new C4Script("heterofor");
				sRec.init(ip0);
				HetEvolutionParameters epRec = new HetEvolutionParameters(obsScene, trueThinningFileName);
				Step reconstructionFinalStep = sRec.evolve(epRec);

				// Export reconstruction results
				Vector<Step> stepVectorRec = new Vector<Step>(); // list of steps
				// From step to root (backwards)
				Step stepRec = reconstructionFinalStep;
				while (!stepRec.isRoot()) { // root not included (NPP=0)
					stepVectorRec.add(stepRec);
					stepRec = (Step) stepRec.getFather();
				}
				// Reverse the list
				Collections.reverse(stepVectorRec);

				// Write in file
				try {
					File f = new File(exportReconstructionFileName);
					if(f.exists() && count == 1) // delete existing exportFile if first simulation
						f.delete();

					BufferedWriter out = new BufferedWriter(new FileWriter(exportReconstructionFileName, true)); // true to append at the end if file already exists

					if(count == 1){
//						out.write("plotName" + "\t" + "year" + "\t" + "treeId" + "\t" + "deltaD2H");
						out.write("plotName" + "\t" + "year" + "\t" + "treeId" + "\t" + "deltaD2H" + "\t" + "NppGppRatio" + "\t" + "species" + "\t" + "DBH" + "\t" + "Htot" + "\t" + "deltaDBH" + "\t" + "deltatHtot" + "\t" + "deltaG" + "\t" + "GPP" + "\t" + "NPP" + "\t" + "LCI");
						out.newLine();
					}

					int cpt = 0;
					for (Step st : stepVectorRec) {
//						while (cpt < 1) { // first year only
							HetScene sc = (HetScene) st.getScene();
							int year = sc.getDate();

							Set sortedTrees = new TreeSet(new GTreeIdComparator());
							sortedTrees.addAll(sc.getTrees());

							for (Iterator t = sortedTrees.iterator(); t.hasNext();) {
								HetTree tree = (HetTree) t.next();

//!\ Skip trees thinned during reconstruction period (bad estimate of dbh and height increments)
								if (trueThinningMap.containsKey(tree.getId())) {
									if (siteName.equals("Baileux") && trueThinningMap.get(tree.getId()) <= 2011) // reconstruction period from 2001 to 2011 for Baileux plots
										continue;
									else if (trueThinningMap.get(tree.getId()) <= 2009) // reconstruction period from 1999 to 2009 for ICP plots
										continue;
								}

								if (tree.isVirtual())
									continue;

								if (!innerZone.contains(tree.getX(), tree.getY()))
									continue;

//								out.write(plotName + "\t" + year+ "\t" + tree.getId() + "\t" + tree.getDeltaDbh2Height());
								out.write(plotName + "\t" + year + "\t" + tree.getId() + "\t" + tree.getDeltaDbh2Height() + "\t" + tree.getNppToGppRatio() + "\t" + tree.getSpecies().getName() + "\t" + tree.getDbh() + "\t" + tree.getHeight() + "\t" + tree.getDeltaDbh_cm() + "\t" + tree.getDeltaHeight() + "\t" + tree.getDeltaG() + "\t" + tree.getGrossPrimaryProduction_kgC() + "\t" + tree.getNetPrimaryProduction_kgC() + "\t" + tree.getLightCompetitionIndex());
								out.newLine();
							}
							cpt++;
						}
//					}
					out.close();
					System.out.println ("wrote tree NPP values in: " + exportReconstructionFileName);
					System.out.println ("\n");
				} catch (Exception e) {
					Log.println(Log.ERROR, "CalibrationRadiationInterception.runOneSimulation", "Could not write in file: " + exportReconstructionFileName, e);
				}
				// Close the project
				sRec.closeProject ();
			} catch(Exception e) {
				Log.println(Log.ERROR, "CalibrationRadiationInterception.runOneSimulation", "Trouble in recontruction:" + "\n" + e.getMessage());
			}
		}


	}

	static private File[] listInventoryFiles(String directoryPath, String nameExtension) {
		File directory = null;
		File[] filePaths = null;
		try {
			directory = new File(directoryPath);

			// File name filter
			FilenameFilter fileNameFilter = new FilenameFilter() {

	            @Override
	            public boolean accept(File dir, String name) {
	               if(name.lastIndexOf('.')>0) {

	                  // get last index for '.' char
	                  int lastIndex = name.lastIndexOf('.');

	                  // get extension
	                  String str = name.substring(lastIndex);

	                  // match path name extension
	                  if(str.equals(nameExtension)) {
	                     return true;
	                  }
	               }

	               return false;
	            }
			};


			// returns pathnames for files and directory
	        filePaths = directory.listFiles(fileNameFilter);

		}
		catch(Exception e) {
			// if any error occurs
			e.printStackTrace();
		}
		return filePaths;

	}

	private static Rectangle.Double setInnerZone (HetScene scene) throws Exception{

		double bufferWidth = 15; //m

		double x0 = scene.getOrigin().x;
		double y0 = scene.getOrigin().y;
		double w = scene.getXSize();
		double h = scene.getYSize();

		Rectangle.Double innerZone = new Rectangle.Double (x0 + bufferWidth, y0 + bufferWidth, w - 2 * bufferWidth, h - 2 * bufferWidth);

		return innerZone;
	}

}