/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.myscripts;

import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetReporter;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
// import heterofor.model.HetSensor;
import heterofor.model.HetTree;

import java.awt.Rectangle;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import jeeb.lib.util.Log;
import capsis.app.C4Script;
import capsis.extension.memorizer.DefaultMemorizer;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.GTreeIdComparator;


/**
 * A script for Heterofor parameter calibration.
 * To run the script from a windows terminal:
 *
 * <pre>
 * capsis -p script heterofor.myscripts.HetCalibrationScript_LADopt2 <arguments(see below)>
 * </pre>
 *
 * @author F. Andre, March 2018
 */
public class HetCalibrationScript_LADopt2 {




	public static void main (String[] args) throws Exception {

//		long startCalibTime = System.currentTimeMillis();

		// args[0] is the name of this script: heterofor.myscripts.CommandScript
		// args[1] is workingDir
		// args[2] is exportReconstructionFileName
		// args[3] is exportSimulationFileName
		// args[4] is turbid medium activated (true or false)
		// args[5] is crownForm (Ec, Ed, Bc, Bd or M)
		// args[6] is ladOption
		// args[7-9] are extinction coefficients for oak, beech, carpinus
		// args[10-12] are SLAbottom for oak, beech, carpinus
		// args[13-15] are SLAtop for oak, beech, carpinus
		// args[16-18] are UFLB for oak, beech, carpinus
		// args[19-21] are alpha for oak, beech, carpinus
		// args[22-24] are beta for oak, beech, carpinus
		// args[25-27] are NppToGppRatio_intercept for oak, beech, carpinus for Baileux
		// args[28-30] are NppToGppRatio_slope for oak, beech, carpinus for Baileux
		// args[31-33] are NppToGppRatio_intercept for oak, beech, carpinus for Chimay
		// args[34-36] are NppToGppRatio_slope for oak, beech, carpinus for Chimay
		// args[37-39] are NppToGppRatio_intercept for oak, beech, carpinus for LLN
		// args[40-42] are NppToGppRatio_slope for oak, beech, carpinus for LLN
		// args[43-45] are NppToGppRatio_intercept for oak, beech, carpinus for Virton
		// args[46-48] are NppToGppRatio_slope for oak, beech, carpinus for Virton
		// args[49] is reconstruction activated (true or false)

		String workingDir = args[1];
		String exportReconstructionFileName = args[2];
		String exportSimulationFileName = args[3];

		// Modification Nicolas Beudez: a "/" in excess
		String inventoryDirectoryName = workingDir + "data/heterofor/inventories/CalibNPP";
		File[] inventoryFilesInv1 = listInventoryFiles(inventoryDirectoryName, ".inv1"); // Starting inventory files: .inv1
		File[] inventoryFilesInv2 = listInventoryFiles(inventoryDirectoryName, ".inv2"); // Ending inventory files: .inv2

		HetReporter.printInStandardOutput(inventoryDirectoryName);

		// Performs simulation for each inventory file
		int count = 0;
		for(File initInventoryFile : inventoryFilesInv1) {
	        count++;
	        File finalInventoryFile = null;
	        for(File endInventoryFile : inventoryFilesInv2) {
		        if (endInventoryFile.getName().contains(initInventoryFile.getName().substring(0, initInventoryFile.getName().length()-9))) { // look for ending inventory file corresponding to init inventory file (same plot)
		        	finalInventoryFile = endInventoryFile;
		        	break;
		        }
	         }
			runOneSimulation (initInventoryFile, finalInventoryFile, workingDir, exportReconstructionFileName, exportSimulationFileName, count, args);
         }

		HetReporter.printInStandardOutput("count: " + count);

//		long endCalibTime = System.currentTimeMillis();
//		long elapsedTime = (endCalibTime - startCalibTime) / (long) 1000.0;

//		System.out.println ("heterofor.myscripts.CallibrationRadiationInterception is over, elapsed time: " + elapsedTime + " seconds");
		HetReporter.printInStandardOutput(args[0] + " is over");
		HetReporter.printInStandardOutput("\n");
		HetReporter.printInStandardOutput("######################################################################################");
		HetReporter.printInStandardOutput("\n");

	}

	/**
	 * Called for each inventory file, runs one simulation (evolution, and reconstruction if requested ) and write tree NPP in export text file(s).
	 */
	static private void runOneSimulation (File initInventoryFile, File finalInventoryFile, String workingDir, String exportReconstructionFileName,  String exportSimulationFileName,int count, String[] args) throws Exception {

		double totalWritingFilesTime = 0;

		HetReporter.printInStandardOutput("Heterofor CalibrationScript, running simulation " + count + " for the following inventory file:\n " + initInventoryFile);

		String initInventoryFileName = initInventoryFile.getName();
		String finalInventoryFileName = finalInventoryFile.getName();
		String plotName = initInventoryFileName.substring(0,initInventoryFileName.lastIndexOf('_'));
		String siteName = plotName.substring(0,plotName.indexOf("_"));

		// Step1: Initialization
		C4Script s = new C4Script ("heterofor");

		// CrownForm, used to select the appropriate species file
		String crownForm_arg = args[5];

		// Simulation settings
		HetInitialParameters ip0 = new HetInitialParameters ();
		ip0.speciesFileName = workingDir + "/data/heterofor/inventories/CalibNPP/heterofor_species_" + crownForm_arg + ".txt"; // speciesFile specific for each crown form
		ip0.castaneaFileName = workingDir + "/data/heterofor/CastaneaSpecies3.txt";
		ip0.inventoryFileName = initInventoryFile.getPath();
		ip0.samsaraLightFileName = workingDir + "/data/heterofor/samsaralight/samsaraLight_settings_monthly.txt";
		ip0.soilHorizonsFileName = workingDir + "/data/heterofor/soilHorizons/soilHorizons_" + plotName + ".txt";
//		ip0.soilChemistryFileName = workingDir + "/" + line.soilChemistryFileName;
		ip0.meteorologyFileName = workingDir + "/data/heterofor/meteorology/Meteorology_" + siteName + "_1999_2016.txt";
		if (!siteName.equals("Baileux"))
			ip0.fructificationFileName = workingDir + "/data/heterofor/inventories/CalibNPP/" + plotName + "_fruitLitterFall.txt";
		ip0.fineResolutionRadiativeBalanceActivated = false;
		ip0.radiationCalculationTimeStep = 1;
		ip0.phenologyActivated = true;
		ip0.waterBalanceActivated = true;
		ip0.waterBalance_treeLevelTranspiration = false;
		ip0.castaneaPhotosynthesisActivated = true;
		ip0.pueEmpiricalMethod = true;
		ip0.constantNppToGppRatio = true;
		ip0.mineralHorizonsTemperatureCalculationActivated = false;
		ip0.competitionAccountedForCrownGrowth = false;
		ip0.generalNutrientLimitation = false;
		ip0.nLimitation = false;
//		if (siteName.equals("Baileux"))
			ip0.heightGrowthOption = "BAILEUX_SITE"; // "IPRFW", "BAILEUX_SITE", "POTENTIAL_MODIFIERS_HEIGHT_GROWTH"
//		else
//			ip0.heightGrowthOption = "IPRFW"; // "IPRFW", "BAILEUX_SITE", "POTENTIAL_MODIFIERS_HEIGHT_GROWTH"
		ip0.mortalityActivated = false;

		// Init simulation
//		s.init (i);
		HetModel model = (HetModel) s.getModel ();
		ip0.buildInitScene(model); //  !!!!! crownForm of trees fixed at this stage from value in speciesFile !!!!!

		// Modify settings for optimized parameters
		boolean turbidMediumActivated_arg = Boolean.valueOf(args[4]);
		int LADoption_arg = Integer.valueOf(args[6]);

		ip0.samsaFileLoader.setTurbidMedium(turbidMediumActivated_arg);

		Map<Integer, HetSpecies> speciesMap = ip0.getSpeciesMap();
		for (int speciesId : speciesMap.keySet()) {

			speciesMap.get(speciesId).LADoption = LADoption_arg;
//			speciesMap.get(speciesId).setCrownForm(crownForm_arg); // crownForm is already set previously (buildInitScene), from speciesFile

			double[] extinctionCoefficient_arg = new double[3];
			extinctionCoefficient_arg[0] = Double.valueOf(args[7]);
			extinctionCoefficient_arg[1] = Double.valueOf(args[8]);
			extinctionCoefficient_arg[2] = Double.valueOf(args[9]);

			double[] slaBottom_arg = new double[3];
			slaBottom_arg[0] = Double.valueOf(args[10]);
			slaBottom_arg[1] = Double.valueOf(args[11]);
			slaBottom_arg[2] = Double.valueOf(args[12]);

			double[] slaTop_arg = new double[3];
			slaTop_arg[0] = Double.valueOf(args[13]);
			slaTop_arg[1] = Double.valueOf(args[14]);
			slaTop_arg[2] = Double.valueOf(args[15]);

			double[] UFLB_arg = new double[3];
			UFLB_arg[0] = Double.valueOf(args[16]);
			UFLB_arg[1] = Double.valueOf(args[17]);
			UFLB_arg[2] = Double.valueOf(args[18]);

			double[] alpha_arg = new double[3];
			alpha_arg[0] = Double.valueOf(args[19]);
			alpha_arg[1] = Double.valueOf(args[20]);
			alpha_arg[2] = Double.valueOf(args[21]);

			double[] beta_arg = new double[3];
			beta_arg[0] = Double.valueOf(args[22]);
			beta_arg[1] = Double.valueOf(args[23]);
			beta_arg[2] = Double.valueOf(args[24]);

			double[] NppToGppRatio_intercept_Baileux_arg = new double[3];
			NppToGppRatio_intercept_Baileux_arg[0] = Double.valueOf(args[25]);
			NppToGppRatio_intercept_Baileux_arg[1] = Double.valueOf(args[26]);
			NppToGppRatio_intercept_Baileux_arg[2] = Double.valueOf(args[27]);

			double[] NppToGppRatio_slope_Baileux_arg = new double[3];
			NppToGppRatio_slope_Baileux_arg[0] = Double.valueOf(args[28]);
			NppToGppRatio_slope_Baileux_arg[1] = Double.valueOf(args[29]);
			NppToGppRatio_slope_Baileux_arg[2] = Double.valueOf(args[30]);

			double[] NppToGppRatio_intercept_Chimay_arg = new double[3];
			NppToGppRatio_intercept_Chimay_arg[0] = Double.valueOf(args[31]);
			NppToGppRatio_intercept_Chimay_arg[1] = Double.valueOf(args[32]);
			NppToGppRatio_intercept_Chimay_arg[2] = Double.valueOf(args[33]);

			double[] NppToGppRatio_slope_Chimay_arg = new double[3];
			NppToGppRatio_slope_Chimay_arg[0] = Double.valueOf(args[34]);
			NppToGppRatio_slope_Chimay_arg[1] = Double.valueOf(args[35]);
			NppToGppRatio_slope_Chimay_arg[2] = Double.valueOf(args[36]);

			double[] NppToGppRatio_intercept_LLN_arg = new double[3];
			NppToGppRatio_intercept_LLN_arg[0] = Double.valueOf(args[37]);
			NppToGppRatio_intercept_LLN_arg[1] = Double.valueOf(args[38]);
			NppToGppRatio_intercept_LLN_arg[2] = Double.valueOf(args[39]);

			double[] NppToGppRatio_slope_LLN_arg = new double[3];
			NppToGppRatio_slope_LLN_arg[0] = Double.valueOf(args[40]);
			NppToGppRatio_slope_LLN_arg[1] = Double.valueOf(args[41]);
			NppToGppRatio_slope_LLN_arg[2] = Double.valueOf(args[42]);

			double[] NppToGppRatio_intercept_Virton_arg = new double[3];
			NppToGppRatio_intercept_Virton_arg[0] = Double.valueOf(args[43]);
			NppToGppRatio_intercept_Virton_arg[1] = Double.valueOf(args[44]);
			NppToGppRatio_intercept_Virton_arg[2] = Double.valueOf(args[45]);

			double[] NppToGppRatio_slope_Virton_arg = new double[3];
			NppToGppRatio_slope_Virton_arg[0] = Double.valueOf(args[46]);
			NppToGppRatio_slope_Virton_arg[1] = Double.valueOf(args[47]);
			NppToGppRatio_slope_Virton_arg[2] = Double.valueOf(args[48]);

			if (speciesId == 1) { // oak
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[0];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[0];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[0];
				speciesMap.get(speciesId).UFLB = UFLB_arg[0];
				speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[0];
				speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[0];
				speciesMap.get(speciesId).leafBiomassAllometry.gamma = beta_arg[0]; // gamma = beta for oak
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[0];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[0];
				}
				else if (siteName.equals("LLN")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[0];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[0];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[0];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}

			} else if (speciesId == 3) { // carpinus
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[2];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[2];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[2];
				speciesMap.get(speciesId).UFLB = UFLB_arg[2];
				speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[2];
				speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[2];
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[2];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[2];
				}
				else if (siteName.equals("LLN")){
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[2];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[2];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[2];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}

			} else { // beech and others
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[1];
				speciesMap.get(speciesId).SLAbottom = slaBottom_arg[1];
				speciesMap.get(speciesId).SLAtop = slaTop_arg[1];
				speciesMap.get(speciesId).UFLB = UFLB_arg[1];
				if (speciesId == 2) { // other species not optimized for leaf biomass allometry parameters
					speciesMap.get(speciesId).leafBiomassAllometry.alpha = alpha_arg[1];
					speciesMap.get(speciesId).leafBiomassAllometry.beta = beta_arg[1];
				}
				if (siteName.equals("Baileux")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Baileux_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Baileux_arg[1];
				}
				else if (siteName.equals("Chimay")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Chimay_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Chimay_arg[1];
				}
				else if (siteName.equals("LLN")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_LLN_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_LLN_arg[1];
				}
				else if (siteName.equals("Virton")) {
					speciesMap.get(speciesId).nppToGppRatio_intercept = NppToGppRatio_intercept_Virton_arg[1];
					speciesMap.get(speciesId).nppToGppRatio_slope = NppToGppRatio_slope_Virton_arg[1];
				}
				else {
					System.out.println ("Error in CalibrationRadiationInterception.runOneSimulation: site " + siteName + " is not recognized");
					System.exit(1);
				}
			}
		}

		// Update tree leaf biomass & NppToGppRatio
		HetScene initScene1 = (HetScene) ip0.getInitScene();
		List treesInitScene1 = new ArrayList(initScene1.getTrees());
//		for (Iterator t = initScene1.getTrees().iterator(); t.hasNext();) { // sequential processing
		treesInitScene1.parallelStream().forEach((t) -> { // parallel processing
			HetTree tree = (HetTree) t;

			HetSpecies species = tree.getSpecies();

			double leafBiomass = species.leafBiomassAllometry.result(tree.getDbh(), tree.getDbh(), tree.getMean2CrownRadius(),
					species.leafRetranslocationRate);
			tree.setLeafBiomass(leafBiomass);
			tree.updateStemAndLitters(tree.getLeafCarbonConcentration());
		});
//		}

		boolean reconstructionActivated_arg = Boolean.valueOf(args[49]);

		String trueThinningFileName = workingDir + "/data/heterofor/inventories/CalibNPP/" + plotName + "_thinning.txt";

		// Create project
		String projectName = s.getClass ().getName ();
		Project project = s.createProject (projectName, model, ip0);
		try {
			s.setMemorizer (project, new DefaultMemorizer ());
		} catch (Exception e) {
			Log.println (Log.ERROR, "GScript2.init ()", "Memorizer error", e);
			throw new Exception ("Memorizer error", e);
		}

		Step initStep = s.getRoot ();
		HetScene initScene = (HetScene) initStep.getScene ();
		int initYear = initScene.getDate();
		int finalYear = Integer.valueOf(finalInventoryFileName.substring(finalInventoryFileName.lastIndexOf('_')+1, finalInventoryFileName.lastIndexOf('_')+5));

		// Central scene area, without the buffer zone
		Rectangle.Double innerZone = setInnerZone (initScene);
		HetReporter.printInStandardOutput("Heterofor CalibrationScript, loaded " + initScene.getTrees ().size () + " trees");


		// Step2: Evolution
		// Determine evolution length
		int evolutionLength = 1; //finalYear - initYear;
		//HetReporter.printInStandardOutput("EvolutionLength = " + evolutionLength + ", initYear = " + initYear + ", finalYear = " + finalYear);
		HetReporter.printInStandardOutput("EvolutionLength = " + evolutionLength + ", initYear = " + initYear + ", finalYear = " + initYear+evolutionLength);

		HetEvolutionParameters ep = new HetEvolutionParameters (evolutionLength, trueThinningFileName);
		Step evolutionFinalStep = model.processEvolution(s.getRoot(),ep);

		// Interventions
//		Intervener thinner;
/*
		// 1. Diameter, height or age class thinner
		int context = 2; //2: DBH, 3: Height, 4: Age
		float min = 20;
		float max = 50;
		thinner = new DHAThinner(context, min, max);
		step = s.runIntervener(thinner, step);
*/
/*
		// 2. Target basal area
		double targetGHA = 15; // m�/ha
		double type = 0.5; // [0,1], 0 for a from below thinning - 1 for a from above thinning
		boolean excludeTargetTrees = true;
		thinner = new GymnoGHAThinner2 (targetGHA, type, excludeTargetTrees);
		step = s.runIntervener(thinner, step);
*/
		// Export evolution results
		Vector<Step> stepVector = new Vector<Step>(); // list of steps
		// From step to root (backwards)
		Step step = evolutionFinalStep;
		while (!step.isRoot()) { // root not included (NPP=0)
			stepVector.add(step);
			step = (Step) step.getFather();
		}
		// Reverse the list
		Collections.reverse(stepVector);

		long startTime_1 = System.currentTimeMillis();

		// Exports results in text file
		try {
			File f = new File(exportSimulationFileName);
			if(f.exists() && count == 1) // delete existing exportFile if first simulation
				f.delete();

			BufferedWriter out = new BufferedWriter(new FileWriter(exportSimulationFileName, true)); // true to append at the end if file already exists

			if(count == 1){
				out.write("plotName" + "\t" + "year" + "\t" + "treeId" + "\t" + "NPP");
				out.newLine();
			}

			for (Step st : stepVector) {
				HetScene sc = (HetScene) st.getScene();
				int year = sc.getDate();

				Set sortedTrees = new TreeSet(new GTreeIdComparator());
				sortedTrees.addAll(sc.getTrees());

				for (Iterator t = sortedTrees.iterator(); t.hasNext();) {
					HetTree tree = (HetTree) t.next();

//					if (tree.isVirtual())
//						continue;
//
//					if (!innerZone.contains(tree.getX(), tree.getY()))
//						continue;

					out.write(plotName + "\t" + year+ "\t" + tree.getId() + "\t" + tree.getNetPrimaryProduction_kgC());
					out.newLine();
				}
			}

			out.close();
			HetReporter.printInStandardOutput("wrote tree NPP values in: " + exportSimulationFileName);
			HetReporter.printInStandardOutput("\n");
		} catch (Exception e) {
			Log.println(Log.ERROR, "CalibrationRadiationInterception.runOneSimulation", "Could not write in file: " + exportSimulationFileName, e);
		}

		long endTime_1 = System.currentTimeMillis();
		double time_1 = ((endTime_1-startTime_1)/1000.0);
		System.out.println("Capsis script --> time writing in file (simulation): " + time_1 + " s");

		totalWritingFilesTime += time_1;

//		HetScene finalScene = (HetScene) step.getScene();

//		System.out.println("Heterofor CalibrationScript_Test, final scene has " + finalScene.getTrees().size() + " trees");

		// Close the project
		s.closeProject ();

		// Step3: Reconstruction (optional)
		if (reconstructionActivated_arg) {
			try {
				// Create project for observations (final inventory)
				C4Script sObs = new C4Script("heterofor");
				HetInitialParameters ipObs = new HetInitialParameters(ip0);
				ipObs.inventoryFileName = finalInventoryFile.getPath();
				sObs.init(ipObs);
				HetScene obsScene = (HetScene) sObs.getRoot().getScene();
				int obsYear = obsScene.getDate();
				if (obsYear < initYear)
					throw new Exception("ERROR: observation date must be greater than root step date: " + initYear);
				sObs.closeProject();

				// Create project for reconstruction (inverse growth)
				C4Script sRec = new C4Script("heterofor");
				sRec.init(ip0);
				HetEvolutionParameters epRec = new HetEvolutionParameters(obsScene, trueThinningFileName);
				Step reconstructionFinalStep = sRec.evolve(epRec);

				// Export reconstruction results
				Vector<Step> stepVectorRec = new Vector<Step>(); // list of steps
				// From step to root (backwards)
				Step stepRec = reconstructionFinalStep;
				while (!stepRec.isRoot()) { // root not included (NPP=0)
					stepVectorRec.add(stepRec);
					stepRec = (Step) stepRec.getFather();
				}
				// Reverse the list
				Collections.reverse(stepVectorRec);

				long startTime_2 = System.currentTimeMillis();

				// Write in file
				try {
					File f = new File(exportReconstructionFileName);
					if(f.exists() && count == 1) // delete existing exportFile if first simulation
						f.delete();

					BufferedWriter out = new BufferedWriter(new FileWriter(exportReconstructionFileName, true)); // true to append at the end if file already exists

					if(count == 1){
						out.write("plotName" + "\t" + "year" + "\t" + "treeId" + "\t" + "NPP");
						out.newLine();
					}

					int cpt = 0;
					for (Step st : stepVectorRec) {
						while (cpt < 1) { // first year only
							HetScene sc = (HetScene) st.getScene();
							int year = sc.getDate();

							Set sortedTrees = new TreeSet(new GTreeIdComparator());
							sortedTrees.addAll(sc.getTrees());

							for (Iterator t = sortedTrees.iterator(); t.hasNext();) {
								HetTree tree = (HetTree) t.next();

//								if (tree.isVirtual())
//									continue;
//
//								if (!innerZone.contains(tree.getX(), tree.getY()))
//									continue;

								out.write(plotName + "\t" + year+ "\t" + tree.getId() + "\t" + tree.getNetPrimaryProduction_kgC());
								out.newLine();
							}
							cpt++;
						}
					}
					out.close();
					HetReporter.printInStandardOutput("wrote tree NPP values in: " + exportReconstructionFileName);
					HetReporter.printInStandardOutput("\n");
				} catch (Exception e) {
					Log.println(Log.ERROR, "CalibrationRadiationInterception.runOneSimulation", "Could not write in file: " + exportReconstructionFileName, e);
				}

				long endTime_2 = System.currentTimeMillis();
				double time_2 = (endTime_2-startTime_2)/1000.0;
				System.out.println("Capsis script --> time writing in file (reconstruction): " + time_2 + " s");

				totalWritingFilesTime += time_2;

				// Close the project
				sRec.closeProject ();
			} catch(Exception e) {
				Log.println(Log.ERROR, "CalibrationRadiationInterception.runOneSimulation", "Trouble in recontruction:" + "\n" + e.getMessage());
			}
		}

		System.out.println("Capsis script --> totalWritingFilesTime: " + totalWritingFilesTime);
	}

	static private File[] listInventoryFiles(String directoryPath, String nameExtension) {
		File directory = null;
		File[] filePaths = null;
		try {
			directory = new File(directoryPath);

			// File name filter
			FilenameFilter fileNameFilter = new FilenameFilter() {

	            @Override
	            public boolean accept(File dir, String name) {
	               if(name.lastIndexOf('.')>0) {

	                  // get last index for '.' char
	                  int lastIndex = name.lastIndexOf('.');

	                  // get extension
	                  String str = name.substring(lastIndex);

	                  // match path name extension
	                  if(str.equals(nameExtension)) {
	                     return true;
	                  }
	               }

	               return false;
	            }
			};


			// returns pathnames for files and directory
	        filePaths = directory.listFiles(fileNameFilter);

		}
		catch(Exception e) {
			// if any error occurs
			e.printStackTrace();
		}
		return filePaths;

	}

	private static Rectangle.Double setInnerZone (HetScene scene) throws Exception{

		double bufferWidth = 15; //m

		double x0 = scene.getOrigin().x;
		double y0 = scene.getOrigin().y;
		double w = scene.getXSize();
		double h = scene.getYSize();

		Rectangle.Double innerZone = new Rectangle.Double (x0 + bufferWidth, y0 + bufferWidth, w - 2 * bufferWidth, h - 2 * bufferWidth);

		return innerZone;
	}

}