/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.myscripts;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
//import heterofor.model.HetSensor;
import capsis.app.C4Script;
import jeeb.lib.util.PathManager;

/**
 * An example script for Heterofor. To run the script from a windows terminal:
 *
 * <pre>
 * capsis -p script heterofor.myscripts.SimpleScript
 * </pre>
 *
 * @author M. Jonard, F. de Coligny, November 2012
 */
public class SimpleScript {

	public static void main(String[] args) throws Exception {

		C4Script s = new C4Script("heterofor");

		// HetInitialParameters i = new HetInitialParameters (PathManager.getDir
		// ("data")
		// + "/heterofor/heterofor-inventory_v2_GL.txt", PathManager.getDir
		// ("data")
		// + "/heterofor/samsaralight/samsaraLight_settings_monthly.txt");

		// fc-26.11.2013 changed the inventory file name to use the new nov 2013
		// file format
		HetInitialParameters i = new HetInitialParameters(PathManager.getDir("data")
				+ "/heterofor/heterofor_species.txt", PathManager.getDir("data")
				+ "/heterofor/inventaire_chênaie-nov-2013.txt", PathManager.getDir("data")
				+ "/heterofor/samsaralight/samsaraLight_settings_monthly.txt");

		// i.sensorHeight = 3;
		// i.LADoption = HetInitialParameters.MEAN_LAD;
		// i.LADoption = HetInitialParameters.MEAN_SLA;
		// i.LADoption = HetInitialParameters.SLA_MODEL;
		// i.LADNeighbourhoodDistance = 14;
		// i.fillGaps = false;

		s.init(i);

		HetScene initScene = (HetScene) s.getRoot().getScene();
		HetModel model = (HetModel) s.getModel();

		System.out.println("Heterofor SimpleScript, loaded " + initScene.getTrees().size() + " trees");

		// Create the writer and write the sensors energy in its file
		String exportFileName = PathManager.getDir("tmp") + "/SimpleScript.export";

		SensorEnergyWriter writer = new SensorEnergyWriter(exportFileName);
		writer.exportSensorsEnergy(model, initScene, i.inventoryFileName, i.samsaraLightFileName, i.speciesFileName, i.sensorHeight /* ,
				i.LADoption, i.Toption */);
		writer.close();

		System.out.println("heterofor.myscripts.SimpleScript is over, wrote sensors energy in: " + exportFileName);
	}

}