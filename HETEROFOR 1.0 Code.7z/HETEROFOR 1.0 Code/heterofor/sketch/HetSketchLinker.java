/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.sketch;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.vecmath.Point3f;

import capsis.kernel.GModel;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;
import capsis.lib.regeneration.RGSpecies;
import capsis.lib.regeneration.RGVegetationLayer;
import capsis.lib.samsaralight.SLEllipsoidalCrownFraction;
import capsis.lib.samsaralight.SLCrownPart;
import capsis.lib.samsaralight.SLEllipsoidalCrownPart;
import capsis.lib.samsaralight.SLParaboloidalCrownPart;
import capsis.lib.samsaralight.SLParaboloidalCrownFraction;
import capsis.lib.samsaralight.SLConicalCrownPart;
import capsis.lib.samsaralight.SLConicalCrownFraction;
import capsis.lib.samsaralight.SLTrunk;
import heterofor.model.HetCell;
import heterofor.model.HetModel;
import heterofor.model.HetPlot;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;
import jeeb.lib.defaulttype.Item;
import jeeb.lib.defaulttype.Type;
import jeeb.lib.sketch.item.Grid;
import jeeb.lib.sketch.kernel.AddInfo;
import jeeb.lib.sketch.kernel.BuiltinType;
import jeeb.lib.sketch.kernel.SimpleAddInfo;
import jeeb.lib.sketch.kernel.SketchEvent;
import jeeb.lib.sketch.kernel.SketchFacade;
import jeeb.lib.sketch.kernel.SketchLinker;
import jeeb.lib.sketch.scene.item.MeshItem;
import jeeb.lib.sketch.scene.item.Polygon;
import jeeb.lib.sketch.scene.kernel.SceneModel;
import jeeb.lib.sketch.scene.terrain.DigitalElevationModel;
import jeeb.lib.structure.geometry.mesh.SimpleMesh;
import jeeb.lib.structure.geometry.mesh.SimpleMeshFactory;
import jeeb.lib.util.SetMap;
import jeeb.lib.util.Translator;
import jeeb.lib.util.Vertex3d;
import jeeb.lib.util.heightmap.HeightMap;

/**
 * Makes the link with a Sketch SceneModel (Sketchy 3D editors / viewers).
 * Contains a method to update the SketchModel from a Scene object of Heterofor.
 * Listens to the SketchModel to update the Scene (if editable) when items are
 * added / removed in the SketchModel.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetSketchLinker implements SketchLinker<HetScene, SceneModel> {

	private boolean initialized;

	private Set<Type> availableTypes;

	private HetModel userModel;
	private HetScene userScene;
	private SceneModel sceneModel;

	private Collection updatedUserObjects;
	private Collection updatedItems;

	/**
	 * Constructor. It is possible to add extensions to the sketch extension
	 * manager here.
	 */
	public HetSketchLinker(GModel userModel) {
		this.userModel = (HetModel) userModel;
	}

	/**
	 * The list of item types the linked module knows and handles.
	 */
	public Set<Type> getAvailableTypes() {
		return availableTypes;
	}

	/**
	 * This must be called when updateSketch is called for the first time on a
	 * SceneModel.
	 */
	private void init(SketchFacade facade) {
		ClassLoader classLoader = this.getClass().getClassLoader();

		availableTypes = new HashSet<Type>();

		initialized = true;
	}

	/**
	 * Adds items for ALL the userObjects of the given userScene into the given
	 * sketchModel. At first time, registers to the SketchModel to know about
	 * sketchHappenings. To 'copy' the user scene into the given sketchModel: 1.
	 * sketchModel.setSketchLinker (null); // temporary, to avoid loops 2. set
	 * the SketchModel empty (leave the grid...) and create / add items for ALL
	 * the user objects in the user scene (terrain, trees...) 4.
	 * sketchModel.setSketchLinker (this); // restore
	 */
	public void updateSketch(HetScene userScene, SceneModel sceneModel) throws Exception {
		this.userScene = userScene;
		this.sceneModel = sceneModel;

		// Add all the trees of the scene into the sceneModel
		updateSketch(userScene, userScene.getTrees(), sceneModel);

	}

	/**
	 * Adds items for ONLY the given userObjects into the given sketchModel. The
	 * given userObjects are part of the given userScene. This can be used when
	 * we want to see only a selection in 3D. To add the entire scene in the
	 * sketchModel, see updateSketch (S userScene, M sketchModel). Note: a
	 * userScene should be composed of XYZBBox elements, the Collection should
	 * contain such elements.
	 */
	public void updateSketch(HetScene uScene, Collection userObjects, SceneModel sceneModel) throws Exception {

		// ENHANCEMENT NEEDED: init if this sceneModel is 'new' (first time we
		// update in it)
		if (!initialized) {
			init(sceneModel.getFacade());
		}

		// Unconnect sketchModel
		sceneModel.setSketchLinker(this, null); // controller, linker

		this.userScene = uScene; // may be null at this stage, see below
		this.sceneModel = sceneModel;

		double minAltitude = Double.MAX_VALUE;

		Collection<HetTree> trees = new ArrayList<HetTree>();
		Collection<HetCell> cells = new ArrayList<HetCell>();
		for (Object o : userObjects) {
			if (o instanceof HetTree) {
				HetTree t = (HetTree) o;
				trees.add(t);
				minAltitude = Math.min(minAltitude, t.getZ());
				if (userScene == null)
					userScene = (HetScene) t.getScene();
			}
			if (o instanceof HetCell) {
				HetCell c = (HetCell) o;
				cells.add(c);
				minAltitude = Math.min(minAltitude, c.getZ());
				minAltitude = Math.min(minAltitude, c.getZCenter());
				if (userScene == null)
					userScene = (HetScene) c.getPlot().getScene();
			}
		}

		System.out.println();
		System.out.println("Het Linker - update Sketch");
		System.out.println("HetStand...   " + userScene);
		System.out.println("trees...      " + trees.size());
		System.out.println("cells...      " + cells.size());
		System.out.println("SceneModel... " + sceneModel);

		// clear the scene
		// boolean includingTechnicalItems = false;
		// sceneModel.getUndoManager ().undoableRemoveAllItems (this,
		// includingTechnicalItems);
		sceneModel.clearModel(this);

		System.out.println("Cleared the sceneModel");
		System.out.println(sceneModel.toString2());

		// Terrain
		// Based on the plot heightMap // fc-14.6.2013
		HetPlot plot = (HetPlot) userScene.getPlot();
		HeightMap heightMap = plot.getHeightMap();

		DigitalElevationModel dem = new DigitalElevationModel(heightMap, new ArrayList<Vertex3d>(plot.getVertices()));
		sceneModel.setTerrain(this, dem);

		// Show the cells -> Polygons
		Type polygonType = new BuiltinType("Cells", jeeb.lib.sketch.scene.extension.sketcher.ContourSketcher.class);

		// + Understorey: vegetation layers and cohort size classes
		Type vegetationLayerType = new BuiltinType("Vegetation layer",
				jeeb.lib.sketch.extension.sketcher.MeshItemSketcher.class);
		Type cohortSizeClassType = new BuiltinType("Cohort size class",
				jeeb.lib.sketch.extension.sketcher.MeshItemSketcher.class);

		Collection<Item> cellItems = new ArrayList<Item>();
		Collection<Item> vegetationLayerItems = new ArrayList<Item>();
		Collection<Item> cohortSizeClassItems = new ArrayList<Item>();

		Color vLayerColor = new Color (111, 161, 104);

		for (HetCell c : cells) {

			Polygon p = new Polygon(new ArrayList(c.getVertices()));
			p.setRGB(c.getRGB());
			cellItems.add(p);

			Vertex3d anchor = new Vertex3d(c.getX(), c.getY(), c.getZ()); // fc-14.6.2013
			// added anchor
			// in MeshItem

			List<RGVegetationLayer> us = c.getVegetationLayers();
			if (us != null) {
				for (RGVegetationLayer u : us) {
					SimpleMesh m = createCobbleStone((float) c.getX(), (float) c.getY(), (float) c.getZ(),
							(float) c.getWidth(), (float) c.getWidth(), (float) u.getHeight_m());
					vegetationLayerItems.add(new MeshItem(vegetationLayerType, -1, m, anchor, vLayerColor));

				}
			}

			SetMap<RGSpecies,RGCohort> cs = c.getCohorts ();
			if (cs != null) {
				double x0 = c.getOrigin ().x;
				double y0 = c.getOrigin ().y;
				double z0 = c.getZCenter ();
				double w0 = c.getWidth ();

				for (RGCohort c1 : cs.allValues ()) {

					HetSpecies sp = (HetSpecies) c1.getSpecies();
					Color cohortColor = sp.color;

					List<RGCohortSizeClass> classes = c1.getSizeClasses ();
					if (classes != null) {
						for (RGCohortSizeClass klass : classes) {
							int i1 = klass.getId ();
							double h1 = klass.getHeight_m ();
							double n1 = klass.getNumber () / 30d;

							Random r = new Random (i1 * 1000);

							double x1 = x0 + r.nextDouble () * w0;
							double y1 = y0 + r.nextDouble () * w0;

							anchor = new Vertex3d (x1, y1, z0); // fc-14.6.2013 added anchor in
																// MeshItem
							SimpleMesh m = createCobbleStone ((float) x1, (float) y1, (float) z0, (float) n1, (float) n1, (float) h1);
							cohortSizeClassItems.add (new MeshItem (cohortSizeClassType, -1, m, anchor, cohortColor));
						}
					}
				}

			}


		}

		AddInfo addInfo = new SimpleAddInfo(polygonType, cellItems);
		sceneModel.getUndoManager().undoableAddItems(this, addInfo);


		addInfo = new SimpleAddInfo (vegetationLayerType, vegetationLayerItems);
		sceneModel.getUndoManager ().undoableAddItems (this, addInfo);

		addInfo = new SimpleAddInfo (cohortSizeClassType, cohortSizeClassItems);
		sceneModel.getUndoManager ().undoableAddItems (this, addInfo);



		updatedUserObjects = new ArrayList(cells);
		updatedItems = new ArrayList(cellItems);

		// HetTree instances
		Type crownMeshType = new BuiltinType(Translator.swap("BuiltinType.MESH_ITEM") + "-crowns",
				jeeb.lib.sketch.extension.sketcher.MeshItemSketcher.class); // preferred
																			// sketcher
		Type trunkMeshType = new BuiltinType(Translator.swap("BuiltinType.MESH_ITEM") + "-trunks",
				jeeb.lib.sketch.extension.sketcher.MeshItemSketcher.class); // preferred
																			// sketcher

		updatedUserObjects.addAll(trees);

		// System.out.println ("...#trees "+trees.size ());

		// These trees are made of crownParts (SLCrownPart)
		Collection<Item> crownItems = new ArrayList<Item>();
		Collection<Item> trunkItems = new ArrayList<Item>();
		int nSectors = 3;
		int nSlices = 4;
		for (HetTree t : trees) {

			Vertex3d anchor = new Vertex3d(t.getX(), t.getY(), t.getZ()); // fc-14.6.2013
																			// added
																			// anchor
																			// in
																			// MeshItem

			// One single tree may have several mesh for its crown
			for (SLCrownPart cp : t.getCrownParts()) {
				if (cp instanceof SLEllipsoidalCrownFraction) { // 8ths of ellipsoid
					SLEllipsoidalCrownFraction cf = (SLEllipsoidalCrownFraction) cp;
					SimpleMesh mesh = SimpleMeshFactory.createEllipsoid8th(cf.x0, cf.y0, cf.z0, cf.a, cf.b, cf.c,
							nSectors, nSlices);
					crownItems.add(new MeshItem(crownMeshType, -1, mesh, anchor, t.getSpecies().color));

				} else if (cp instanceof SLEllipsoidalCrownPart) { // ellipsoids
																	// (full,
																	// half or 2
																	// halves)
					SLEllipsoidalCrownPart p = (SLEllipsoidalCrownPart) cp;

					if (!p.isHalfEllipsoid()) { // full
						SimpleMesh mesh = SimpleMeshFactory.createEllipsoid(p.x, p.y, p.z, p.a, p.b, p.c, nSectors,
								nSlices);
						crownItems.add(new MeshItem(crownMeshType, -1, mesh, anchor, t.getSpecies().color));
					} else {
						SimpleMesh mesh1 = SimpleMeshFactory.createEllipsoidHalf(p.x, p.y, p.z, p.a, p.b, p.c,
								p.isHalfTopPart(), nSectors, nSlices);
						crownItems.add(new MeshItem(crownMeshType, -1, mesh1, anchor, t.getSpecies().color));

					}

				} else if (cp instanceof SLParaboloidalCrownPart) { // fa-07.05.2019: Full paraboloid
					SLParaboloidalCrownPart p = (SLParaboloidalCrownPart) cp;
					SimpleMesh mesh = SimpleMeshFactory.createParaboloid(p.x, p.y, p.z, p.a, p.b, p.h,
							nSectors, nSlices);
					crownItems.add(new MeshItem(crownMeshType, -1, mesh, anchor, t.getSpecies().color));

				} else if (cp instanceof SLParaboloidalCrownFraction) { // fa-08.05.2019: 4ths of paraboloid
					SLParaboloidalCrownFraction cf = (SLParaboloidalCrownFraction) cp;
					SimpleMesh mesh = SimpleMeshFactory.createParaboloid4th(cf.x0, cf.y0, cf.z0, cf.a, cf.b, cf.h,
							nSectors, nSlices);
					crownItems.add(new MeshItem(crownMeshType, -1, mesh, anchor, t.getSpecies().color));

				} else if (cp instanceof SLConicalCrownPart) { // fa-09.05.2019: Full cone
					SLConicalCrownPart p = (SLConicalCrownPart) cp;
					SimpleMesh mesh = SimpleMeshFactory.createCone(p.x, p.y, p.z, p.a, p.b, p.h,
							nSectors, nSlices);
					crownItems.add(new MeshItem(crownMeshType, -1, mesh, anchor, t.getSpecies().color));
				} else if (cp instanceof SLConicalCrownFraction) { // fa-09.05.2019: 4ths of cone
					SLConicalCrownFraction cf = (SLConicalCrownFraction) cp;
					SimpleMesh mesh = SimpleMeshFactory.createCone4th(cf.x0, cf.y0, cf.z0, cf.a, cf.b, cf.h,
							nSectors, nSlices);
					crownItems.add(new MeshItem(crownMeshType, -1, mesh, anchor, t.getSpecies().color));
				}
			}

			// Trees also have a trunk (optional)
			if (t.getTrunk() != null) {
				int nTrunkSectors = 3;
				int nTrunkSlices = 2;
				SLTrunk trunk = t.getTrunk();
				SimpleMesh mesh2 = SimpleMeshFactory.createCylinder(trunk.getX(), trunk.getY(), trunk.getZ(),
						trunk.getRadius(), trunk.getCrownBase(), nTrunkSectors, nTrunkSlices);
				trunkItems.add(new MeshItem(trunkMeshType, -1, mesh2, anchor, new Color(127, 117, 98)));
			}

		}
		updatedItems.addAll(crownItems);
		updatedItems.addAll(trunkItems);

		addInfo = new SimpleAddInfo(crownMeshType, crownItems);
		sceneModel.addItems(this, addInfo);

		addInfo = new SimpleAddInfo(trunkMeshType, trunkItems);
		sceneModel.addItems(this, addInfo);

		System.out.println("Added the terrain and trees");
		System.out.println(sceneModel.toString2());

		// Check if the grid altitude can be changed
		Type gridType = new Grid().getType();
		Collection<Item> grids = sceneModel.getItems(gridType);
		for (Item item : grids) { // maybe several grids
			try {
				Grid g = (Grid) item;
				g.setZ(minAltitude); // fc-20.3.2015
				// g.setAltitude (minAltitude);
				sceneModel.updateItem(this, g);
				System.out.println("The grid altitude was set to: " + minAltitude);
			} catch (Exception e) {
			}
		}

		// fc - 21.10.2008 - reset selection / clear undo stack
		sceneModel.getUndoManager().undoableResetSelection(this);
		sceneModel.getUndoManager().clearMemory(); // fc - 4.3.2008 - clear
													// undo/redo stacks

		System.out.println("Reset selection and memory ");
		System.out.println();

		// Cconnect sketchModel
		sceneModel.setSketchLinker(this, this); // controller, linker

	}

	// 'Un pavé' - to be moved to SimpleMeshFactory
	private SimpleMesh createCobbleStone(float x, float y, float z, float dx, float dy, float dz) {
		Point3f[] points = new Point3f[8];
		int[][] paths = new int[6][4];

		points[0] = new Point3f(x, y, z);
		points[1] = new Point3f(x + dx, y, z);
		points[2] = new Point3f(x + dx, y + dy, z);
		points[3] = new Point3f(x, y + dy, z);

		points[4] = new Point3f(x, y, z + dz);
		points[5] = new Point3f(x + dx, y, z + dz);
		points[6] = new Point3f(x + dx, y + dy, z + dz);
		points[7] = new Point3f(x, y + dy, z + dz);

		paths = new int[][] { { 0, 3, 2, 1 }, { 0, 1, 5, 4 }, { 0, 4, 7, 3 }, { 1, 2, 6, 5 }, { 2, 3, 7, 6 },
				{ 4, 5, 6, 7 } };

		return new SimpleMesh(points, paths);
	}

	/**
	 * Returns the userObjects turned into items during the last updateSketch
	 * ().
	 */
	public Collection getUpdatedUserObjects() {
		return updatedUserObjects;
	}

	/**
	 * Returns the items added into the sketchModel during the last updateSketch
	 * ().
	 */
	public Collection getUpdatedItems() {
		return updatedItems;
	}

	/**
	 * SketchListener interface Called by the SketchModel when items are added,
	 * removed, updated or when selection changed. Also service messages. See
	 * SketchEvent for details.
	 */
	public void sketchHappening(SketchEvent e) {
		this.sceneModel = (SceneModel) e.getModel();

		// ~ if (e.getType ().equals (SketchEvent.ITEMS_ADDED)) {
		// ~ Set<AbstractItem> items = (Set<AbstractItem>) e.getParameter ();
		// ~ itemsAdded (sceneModel, items);

		// ~ } else if (e.getType ().equals (SketchEvent.ITEMS_REMOVED)) {
		// ~ Set<AbstractItem> items = (Set<AbstractItem>) e.getParameter ();
		// ~ itemsRemoved (sceneModel, items);

		// ~ } else if (e.getType ().equals (SketchEvent.ITEMS_UPDATED)) {
		// ~ Set<AbstractItem> items = (Set<AbstractItem>) e.getParameter ();
		// ~ itemsUpdated (sceneModel, items);

		// ~ } else if (e.getType ().equals (SketchEvent.SELECTION_CHANGED)) {
		// ~ Set[] t = (Set[]) e.getParameter ();
		// ~ selectionChanged (sceneModel, t[0], t[1]); // selectedItems,
		// deselectedItems
		// ~ }
		// ~ System.out.println (userScene.getState ());
	}

	/**
	 * Returns the userModel, subclass of GModel. Was given to the constructor.
	 */
	public HetModel getUserModel() {
		return userModel;
	}

	/**
	 * Returns the current userScene, subclass of GStand. This is the last
	 * userScene given to one of the updateSketch () methods.
	 */
	public HetScene getUserScene() {
		return userScene;
	}

	/**
	 * Returns the SketchModel this linker talks to, i.e. SceneModel or
	 * ArchiModel. This is the last sketchModel given to one of the updateSketch
	 * () methods.
	 */
	public SceneModel getSketchModel() {
		return sceneModel;
	}

	/**
	 * Ensures deregistration to the SketchModel
	 */
	public void destroy() {
		// maybe not needed, see setSketchLinker () in SceneModel (named
		// setSketchLinker () temporarily)
	}

	// /**
	// * Returns true if the given scene is editable.
	// */
	// @Override
	// public boolean isEditable (HetScene userScene) {
	// return false;
	// }

}
